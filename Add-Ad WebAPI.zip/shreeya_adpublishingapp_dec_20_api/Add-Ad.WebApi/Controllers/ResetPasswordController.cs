﻿using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResetPasswordController : ControllerBase
    {
        private readonly ICustomerUserServices _customerUserServices;
        public ResetPasswordController(ICustomerUserServices customerUserServices)
        {
            _customerUserServices = customerUserServices;
        }
        [HttpPost]
        public async Task<IActionResult> UpdatePassword(CustomerUserDTO userVal)
        {

            
            try
            {
                int? newCustomerId = await _customerUserServices.UpdatePassword(userVal);
                if (newCustomerId == 0)
                    return BadRequest("Your Entered email is not registered");
                return Ok(newCustomerId);
            }
            catch (SqlException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
