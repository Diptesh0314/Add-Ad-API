﻿using Add_Ad.Entity;
using Add_Ad.Repositories;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    /// <summary>
    /// Class used to Handle all the operations on Tv Channel
    /// </summary>
    public class TvChannelServices:ITvChannelServices
    {
        private readonly ITvChannelRepository _tvChannelRepository;

        public TvChannelServices(ITvChannelRepository tvChannelRepository)
        {
            _tvChannelRepository = tvChannelRepository;
        }

        public async Task<object> GetAllChannels()
        {
            return await _tvChannelRepository.GetAllChannels();
        }

        

        public async Task<object> SearchGenre(string genre)
        {
            return await _tvChannelRepository.SearchGenre(genre);
        }

        public async Task<object> SearchRating(int rating)
        {
            return await _tvChannelRepository.SearchRating(rating);
        }
        //RegisterChanel function Adds the TvChannel object to database
        //Returns number of rows affected
        public async Task<int> RegisterChanel(TvChannel channel)
        {
            int rowsAffected =await _tvChannelRepository.RegisterChanel(channel);
            return rowsAffected;
        }

        /// <summary>
        /// Method Used to Get List of Top Tv Channels by Rating
        /// </summary>
        /// <returns>List<TopTvChannel></returns>
        public async Task<List<TopTvChannel>> ShowTopTvChannels() {

            return await _tvChannelRepository.ShowTopTvChannels();

        }

        public async Task<object> GetActiveTvChannel()
        {
            return await _tvChannelRepository.GetActiveTvChannel();
        }

        public async Task<bool> UpdateTvChannel(int tvChannelid)
        {
            return await _tvChannelRepository.UpdateTvChannel(tvChannelid);
        }

        public async Task<List<SearchChannelDTO>> GetNotApprovedTvChannels()
        {
            return await _tvChannelRepository.GetNotApprovedTvChannels();
        }

        public async Task<List<SearchChannelDTO>> GetBlockedTvChannels()
        {
            return await _tvChannelRepository.GetBlockedTvChannels();
        }

        public async Task<bool> UnblockTvChannel(int tvChannelid)
        {
            return await _tvChannelRepository.UnblockTvChannel(tvChannelid);
        }

        public async Task<bool> ApproveTvChannel(int tvChannelId)
        {
            return await _tvChannelRepository.ApproveTvChannel(tvChannelId);
        }

        public async Task<bool> RejectTvChannel(int tvChannelId) {
            return await _tvChannelRepository.RejectTvChannel(tvChannelId);
        }

        public async Task<int> UpdateChannelPrice(TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO)
        {
            int rowsAffected;
            rowsAffected =await _tvChannelRepository.UpdateChannelPrice(tvChannelPriceUpdateDTO);
            return rowsAffected;
        }

        public async Task<TvChannel> GetByEmail(string email)
        {
            return await _tvChannelRepository.GetByEmail(email);
        }

        public Task<string> GetEmailTvChannel(int tvChannelId)
        {
            return _tvChannelRepository.GetEmailTvChannel(tvChannelId);
        }

        public async Task<int?> TransactionStatusConfirmation(Transaction transaction)
        {
            return await _tvChannelRepository.TransactionStatusConfirmation(transaction);
        }

        public async Task<List<TransactionDTO>> GetPendingTransactionRequests(string email)
        {
            return await _tvChannelRepository.GetPendingTransactionRequests(email);
        }

        public async Task<string> GetEmailById(int id)
        {
            return await _tvChannelRepository.GetEmailById(id);
        }
    }
}
