﻿using Add_Ad.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public interface IRoleServices
    {
        public Task<int> AddRoles(Role role);
    }
}
