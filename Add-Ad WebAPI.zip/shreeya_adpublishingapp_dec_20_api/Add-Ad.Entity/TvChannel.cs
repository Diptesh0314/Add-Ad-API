﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Add_Ad.Entity
{
    public class TvChannel
    {
        [Key]
        public int? TvChannelId { get; set; }
        public int? CustomerUserId { get; set; }
        public string Genre { get; set; }
        public string Language { get; set; }
        public bool IsApproved { get; set; }
        public bool IsBlocked { get; set; }

        //Cost is calculated rupees per second ads
        public double Cost { get; set; }
        public int Rating { get; set; }

        //[ForeignKey("CustomerUserId")]
        //public CustomerUser CustomerUser { get; set; }
    }
}
