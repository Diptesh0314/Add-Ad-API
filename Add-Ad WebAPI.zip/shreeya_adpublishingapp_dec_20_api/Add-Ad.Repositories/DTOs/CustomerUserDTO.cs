﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
   public class CustomerUserDTO
    {
        public int Token { get; set; }
        public string UserName { get; set; }
        [StringLength(50)]
        public string EmailId { get; set; }
        public int? RoleId { get; set; }
        public string PassWord { get; set; }
    }
}
