﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NewspaperController : ControllerBase
    {
        private readonly INewspaperServices _newspaperServices;

        public NewspaperController(INewspaperServices newspaperServices)
        {
            _newspaperServices = newspaperServices;
        }

        [HttpGet]
        public async Task<ActionResult> GetAllNewspapers()
        {
            try
            {
                return Ok(await _newspaperServices.GetAllNewsPapers());
            }
            catch (NoNewspaperFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{name}")]
        public async Task<ActionResult> SearchChannel(string name)
        {
            try
            {
                return Ok(await _newspaperServices.SearchNewspaper(name));
            }
            catch (NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("SearchRating/{rating}")]
        public async Task<ActionResult> SearchRating(int rating)
        {
            try
            {
                return Ok(await _newspaperServices.SearchRating(rating));
            }
            catch (NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> RegisterNewspaper(NewspaperssDTO newspaperDTO)
        {
            try
            {
                int rateCalculation;
                rateCalculation = (int)(newspaperDTO.Rating / 20000);
                if (rateCalculation == 0)
                    rateCalculation = 1;
                Newspaper newspaper = new Newspaper();
                newspaper.CustomerUserId = newspaperDTO.CustomerUserId;
                newspaper.Language = newspaperDTO.Language;
                newspaper.Rating = rateCalculation;
                int rowsAffected = 0;
                rowsAffected = await _newspaperServices.RegisterNewspaper(newspaper);
                if (rowsAffected == 0)
                    return BadRequest();
                else
                    return Ok();
            }
            catch (NewspaperInsertionException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("ShowTopNewspapers")]
        public async Task<IActionResult> ShowTopNewspapers()
        {
            try
            {
                return Ok(await _newspaperServices.ShowTopNewspapers());
            }
            catch (NoNewspaperFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetActiveNewspaper")]
        public async Task<IActionResult> GetActiveAllNewspaper() {

            try
            {
                return Ok(await _newspaperServices.GetActiveAllNewspapers());
            }
            catch (NoNewspaperFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("UpdateNewspaper")]
        public async Task<IActionResult> UpdateNewspaper(SearchNewspaperDTO newspaper) {
            try
            {
                return Ok(await _newspaperServices.UpdateNewspaper(Convert.ToInt32(newspaper.NewsPaperId)));
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetNotApprovedNewspapers")]

        public async Task<IActionResult> GetNotApprovedNewspapers() {

            try
            {
                return Ok(await _newspaperServices.GetNotApprovedNewspapers());
            }
            catch(Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetBlockedNewspapers")]

        public async Task<IActionResult> GetBlockedNewspapers()
        {
            try
            {
                return Ok(await _newspaperServices.GetBlockNewspapers());
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("UnblockNewspaper")]
        public async Task<IActionResult> UnblockNewspaper(SearchNewspaperDTO newspaper)
        {
            try
            {
                return Ok(await _newspaperServices.UnblockNewspaper(Convert.ToInt32(newspaper.NewsPaperId)));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("ApproveNewspaper")]
        public async Task<IActionResult> ApproveNewspaper(SearchNewspaperDTO newspaper) {

            try
            {
                return Ok(await _newspaperServices.ApproveNewspaper(Convert.ToInt32(newspaper.NewsPaperId)));
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        
        }

        [HttpPut("RejectNewspaper")]
        public async Task<IActionResult> RejectNewspaper(SearchNewspaperDTO newspaper) {

            try
            {
                return Ok(await _newspaperServices.RejectNewspaper(Convert.ToInt32(newspaper.NewsPaperId)));
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("GetEmailNewspaper")]
        public async Task<IActionResult> GetEmailNewspaper(SearchNewspaperDTO newspaper)
        {
            try
            {
                string email = await _newspaperServices.GetEmailNewspaper(Convert.ToInt32(newspaper.NewsPaperId));
                EmailDTO newspaperEmail = new EmailDTO();
                newspaperEmail.Email = email;
                return Ok(newspaperEmail);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
     
    }
}