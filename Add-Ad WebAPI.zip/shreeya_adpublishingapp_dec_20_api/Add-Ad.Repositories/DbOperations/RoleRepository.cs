﻿using Add_Ad.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories.DbOperations
{
    public class RoleRepository : IRoleRepository
    {
        private readonly Add_AdContext _add_AdContext;
        public RoleRepository(Add_AdContext add_AdContext)
        {
            _add_AdContext = add_AdContext;
        }
        
        public async Task<int> AddRoles(Role role)
        {
            if (role == null)
                throw new ArgumentNullException("Value is null");
            else
            {
                int rowsAffected;
                _add_AdContext.Roles.Add(role);
                rowsAffected = await _add_AdContext.SaveChangesAsync();
                return rowsAffected;

            }
          
        }
    }
}
