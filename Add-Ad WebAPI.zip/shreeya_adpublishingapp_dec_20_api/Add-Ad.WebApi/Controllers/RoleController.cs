﻿using Add_Ad.Entity;
using Add_Ad.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleServices _roleServices;
        public RoleController(IRoleServices roleServices)
        {
            _roleServices = roleServices;
        }

        [HttpPost]
        public async Task<IActionResult> AddRoles(Role role)
        {
            try
            {
                int rowsAffected;
                rowsAffected = await _roleServices.AddRoles(role);
                if (rowsAffected == 0)
                    return BadRequest("Something went wrong");
                else
                    return Ok(rowsAffected);
            }
            catch(ArgumentNullException ex)
            {
                return BadRequest(ex.Message);
            }
            
        }
    }
}
