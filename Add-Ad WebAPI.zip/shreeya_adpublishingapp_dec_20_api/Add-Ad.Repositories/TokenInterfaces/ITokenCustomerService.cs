﻿using Add_Ad.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.TokenInterfaces
{
    public interface ITokenCustomerService
    {
        public string CreateToken(CustomerUser user);
    }
}
