﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class NewspaperPriceUpdateDTO
    {
        public string Email { get; set; }
        public double Cost { get; set; }
    }
}
