﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.CustomExceptions
{
    public class TvChannelInsertionException:Exception
    {
        public TvChannelInsertionException():base()
        {

        }
        public TvChannelInsertionException(string message):base(message)
        {

        }
        public TvChannelInsertionException(string message,Exception innerException) : base(message,innerException)
        {

        }

    }
}
