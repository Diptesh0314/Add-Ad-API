﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories
{
    public interface ITvChannelRepository
    {
        Task<object> GetAllChannels();
        Task<object> SearchGenre(string genre);
        Task<object> SearchRating(int rating);
        public Task<int> RegisterChanel(TvChannel channel);
        public Task<List<TopTvChannel>> ShowTopTvChannels();
        public Task<int> UpdateChannelPrice(TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO);
        public Task<TvChannel> GetByEmail(string email);

        Task<object> GetActiveTvChannel();

        Task<bool> UpdateTvChannel(int tvChannelId);

        Task<List<SearchChannelDTO>> GetNotApprovedTvChannels();

        Task<List<SearchChannelDTO>> GetBlockedTvChannels();

        Task<bool> UnblockTvChannel(int tvChannelId);

        Task<bool> ApproveTvChannel(int tvChannelId);

        Task<bool> RejectTvChannel(int tvChannelId);

        public Task<string> GetEmailTvChannel(int tvChannelId);
        public Task<int?> TransactionStatusConfirmation(Transaction transaction);
        public Task<List<TransactionDTO>> GetPendingTransactionRequests(string email);
        Task<string> GetEmailById(int id);
    }
}
