﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.CustomExceptions
{
    public class NoNewspaperFound:Exception
    {
        public NoNewspaperFound()
        {

        }

        public NoNewspaperFound(string msg) : base(msg)
        {
        }
    }
}
