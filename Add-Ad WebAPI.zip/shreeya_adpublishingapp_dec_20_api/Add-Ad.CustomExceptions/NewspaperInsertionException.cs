﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.CustomExceptions
{
    public class NewspaperInsertionException:Exception
    {
        public NewspaperInsertionException():base()
        {

        }
        public NewspaperInsertionException(string message) : base(message)
        {

        }
        public NewspaperInsertionException(string message,Exception innerException) : base(message,innerException)
        {

        }
    }
}
