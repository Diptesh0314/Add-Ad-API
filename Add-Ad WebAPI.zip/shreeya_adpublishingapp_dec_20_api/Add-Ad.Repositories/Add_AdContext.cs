﻿using Microsoft.EntityFrameworkCore;
using System;
using Add_Ad.Entity;
using System.Linq;

namespace Add_Ad.Repositories
{
    public class Add_AdContext:DbContext
    {
        
        public Add_AdContext(DbContextOptions<Add_AdContext> options) : base(options)
        {

        }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerUser>().HasIndex(p => new { p.EmailId }).IsUnique(true);
            

        }
       
        public DbSet<CustomerUser> CustomerUsers { get; set; }
        public DbSet<Newspaper> Newspapers { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<TvChannel> TvChannels { get; set; }
    }
}
