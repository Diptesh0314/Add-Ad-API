﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmailService;
namespace Add_Ad.Repositories
{
    /// <summary>
    /// This Class is Responsible for Tv Channel Operations
    /// </summary>
    public class TvChannelRepository : ITvChannelRepository
    {
        private readonly Add_AdContext _add_AdContext;

        public TvChannelRepository(Add_AdContext add_AdContext)
        {
            _add_AdContext = add_AdContext;
        }

        /// <summary>
        /// Method used to Return Top Tv Channel by Ratings.
        /// </summary>
        /// <returns>List<TopTvChannel></returns>
        public async Task<List<TopTvChannel>> ShowTopTvChannels()
        {
            List<TopTvChannel> topTvChannels = new List<TopTvChannel>();
            try
            {
                //Linq query for getting top tv Channels
                var topTvChannelsData = await Task.Run(() => (from TvChannels in _add_AdContext.TvChannels
                                                              join CustomerUser in _add_AdContext.CustomerUsers
                                                                  on TvChannels.CustomerUserId equals CustomerUser.CustomerUserId
                                                              where (TvChannels.IsApproved==true && TvChannels.IsBlocked==false)
                                                              orderby TvChannels.Rating descending
                                                              select new
                                                              {
                                                                  CustomerUser.UserName,
                                                                  TvChannels.Rating,
                                                                  TvChannels.Genre,
                                                                  TvChannels.Language
                                                              }).Take(4).ToListAsync());

                if (topTvChannelsData.Count == 0)
                {
                    throw new NoTvChannelFound("No Newspaper Found");
                }

                foreach (var topTvChannelIterator in topTvChannelsData)
                {
                    TopTvChannel tvChannel = new TopTvChannel();

                    tvChannel.UserName = topTvChannelIterator.UserName;
                    tvChannel.Rating = topTvChannelIterator.Rating;
                    tvChannel.Language = topTvChannelIterator.Language;
                    tvChannel.Genre = topTvChannelIterator.Genre;

                    topTvChannels.Add(tvChannel);
                }
            }
            //
            catch (NoTvChannelFound ex)
            {
                throw new NoTvChannelFound(ex.Message);
            }

            return topTvChannels;
        }

        /// <summary>
        /// Method to Return
        /// </summary>
        /// <returns></returns>
        public async Task<object> GetAllChannels()
        {
            try
            {
                List<SearchChannelDTO> allChannels = new List<SearchChannelDTO>();
                var channelList = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where (channels.IsApproved==true && channels.IsBlocked==false && channels.Cost>0)  orderby channels.Rating descending select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();
                allChannels = EntityToDto(allChannels, channelList);
                if (channelList == null)
                {
                    throw new NoTvChannelFound("No TV Channel is Present");
                }
                return allChannels;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This Method is reponsible for Search Channels on the basis of Search String
        /// </summary>
        /// <param name="name">Search by Name</param>
        /// <returns>List of Object</returns>
        

        /// <summary>
        /// This Method is used to Get Tv Channels by Genre
        /// </summary>
        /// <param name="genre"></param>
        /// <returns>List of Object</returns>
        public async Task<object> SearchGenre(string genre)
        {
            List<SearchChannelDTO> genreChannel = new List<SearchChannelDTO>();

            try
            {
                var searchGenre = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where (channels.Genre == genre && channels.IsApproved==true && channels.IsBlocked==false && channels.Cost>0) select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();
                genreChannel = EntityToDto(genreChannel, searchGenre);
                if (searchGenre == null)
                {
                    throw new NoTvChannelFound("No TV Channel is Present");
                }
                return genreChannel;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This Method is used to Get Tv Channel by Rating
        /// </summary>
        /// <param name="rating">Integer</param>
        /// <returns></returns>
        public async Task<object> SearchRating(int rating)
        {
            try
            {
                List<SearchChannelDTO> searchRatingChannel = new List<SearchChannelDTO>();
                var searchRating = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where channels.Rating == rating select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();
                searchRatingChannel = EntityToDto(searchRatingChannel, searchRating);
                if (searchRating == null)
                {
                    throw new NoTvChannelFound("No TV Channel is Present");
                }
                return searchRatingChannel;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This Method is responsible for Registering Channel
        /// </summary>
        /// <param name="channel">Object of TvChannel</param>
        /// <returns>Integer</returns>
        public async Task<int> RegisterChanel(TvChannel channel)
        {
            try
            {
                int rowsAffected = 0;
                _add_AdContext.TvChannels.Add(channel);
                rowsAffected = await _add_AdContext.SaveChangesAsync();
                if (rowsAffected == 0)
                    throw new TvChannelInsertionException("Insertion failed,something went wrong");
                return rowsAffected;
            }
            catch (TvChannelInsertionException ex)
            {
                throw new TvChannelInsertionException(ex.Message);
            }
        }

        /// <summary>
        /// Return a list of TvChannel object containing all TvChannels
        /// </summary>
        /// <returns></returns>
        public async Task<List<TvChannel>> AllChannels()
        {
            List<TvChannel> tvChannels = await _add_AdContext.TvChannels.ToListAsync();
            return tvChannels;
        }
        /// <summary>
        /// UpdateChannelPrice functon updates the price of tvchannel
        /// </summary>
        /// <param name="tvChannelPriceUpdateDTO"></param>
        /// <returns>Number of rows affected</returns>
        public async Task<int> UpdateChannelPrice(TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO)
        {
            int rowsAffected;
            CustomerUser user = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(u => u.EmailId == tvChannelPriceUpdateDTO.Email);
            TvChannel tvChannel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(t => t.CustomerUserId == user.CustomerUserId);
            if (tvChannel == null)
                throw new NoTvChannelFound("Invalid TvChannel");
            try
            {
                tvChannel.Cost = Math.Round((double)tvChannelPriceUpdateDTO.Cost, 2);
                _add_AdContext.TvChannels.Update(tvChannel);
                rowsAffected = await _add_AdContext.SaveChangesAsync();
                if (rowsAffected == 0)
                    throw new TvChannelInsertionException("Cost Updation failed");
                return rowsAffected;
            }
            catch
            {
                throw new Exception("Something went wrong");
            }
            
        }
        /// <summary>
        /// GetByEmail function returns the TvChannel object according to the mail it take as input
        /// </summary>
        /// <param name="email"></param>
        /// <returns>TvChannel Object</returns>
        public async Task<TvChannel> GetByEmail(string email)
        {
            try
            {
                CustomerUser customerUser = new CustomerUser();
                TvChannel tvChannel = new TvChannel();
                customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(e => e.EmailId == email);
                tvChannel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(t => t.CustomerUserId == customerUser.CustomerUserId);
                return tvChannel;
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);
            }
        }

        public async Task<object> GetActiveTvChannel()
        {
            try
            {
                List<SearchChannelDTO> tvChannels = new List<SearchChannelDTO>();

                var tvChannelsList = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where(channels.IsApproved==true && channels.IsBlocked==false) select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();

                tvChannels = EntityToDto(tvChannels, tvChannelsList);

                if (tvChannels.Count == 0)
                {
                    throw new NoTvChannelFound("No Tv Channel Found");
                }

                return tvChannels;
            }
            catch (NoTvChannelFound)
            {
                throw new NoTvChannelFound("No Tv Channel Found");
            }
        }

        public async Task<bool> UpdateTvChannel(int tvChannelId)
        {
            try
            {
                var tvChannel = await (from channel in _add_AdContext.TvChannels where channel.TvChannelId == tvChannelId select channel).SingleOrDefaultAsync();

                tvChannel.IsBlocked = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }

        public async Task<List<SearchChannelDTO>> GetBlockedTvChannels()
        {
            try
            {
                List<SearchChannelDTO> allChannels = new List<SearchChannelDTO>();
                var channelList = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where (channels.IsBlocked == true && channels.IsApproved==true) orderby channels.Rating descending select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();
                allChannels = EntityToDto(allChannels, channelList);
                if (channelList == null)
                {
                    throw new NoTvChannelFound("No TV Channel is Present");
                }
                return allChannels;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<SearchChannelDTO>> GetNotApprovedTvChannels()
        {
            try
            {
                List<SearchChannelDTO> allChannels = new List<SearchChannelDTO>();
                var channelList = await(from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where (channels.IsApproved == false && channels.IsBlocked==false) orderby channels.Rating descending select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();
                allChannels = EntityToDto(allChannels, channelList);
                if (channelList == null)
                {
                    throw new NoTvChannelFound("No TV Channel is Present");
                }
                return allChannels;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public async Task<bool> UnblockTvChannel(int tvChannelId)
        {
            try
            {
                var tvChannel = await (from channel in _add_AdContext.TvChannels where channel.TvChannelId == tvChannelId select channel).SingleOrDefaultAsync();

                tvChannel.IsBlocked = false;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }

        public async Task<bool> ApproveTvChannel(int tvChannelId) {

            try
            {
                var tvChannel = await (from channel in _add_AdContext.TvChannels where channel.TvChannelId == tvChannelId select channel).SingleOrDefaultAsync();

                tvChannel.IsApproved = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;

        }

        public async Task<bool> RejectTvChannel(int tvChannelId) {

            try
            {
                var tvChannel = await (from channel in _add_AdContext.TvChannels where channel.TvChannelId == tvChannelId select channel).SingleOrDefaultAsync();

                tvChannel.IsBlocked = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }

        public async Task<string> GetEmailTvChannel(int tvChannelId)
        {
            try
            {
                TvChannel tvChannel = await _add_AdContext.TvChannels.FindAsync(tvChannelId);
                CustomerUser customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(t => t.CustomerUserId == tvChannel.CustomerUserId);
                return customerUser.EmailId;
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);
            }
        }

        public async Task<int?> TransactionStatusConfirmation(Transaction transaction)
        {
           
            var dataBaseTransaction = await _add_AdContext.Transactions.FirstAsync(a => a.TransactionId == transaction.TransactionId);
            dataBaseTransaction.IsApproved = transaction.IsApproved;

            await _add_AdContext.SaveChangesAsync();

            return dataBaseTransaction.TransactionId;
         
        }

        public async Task<List<TransactionDTO>> GetPendingTransactionRequests(string email)
        {
            var customer = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(c => c.EmailId == email);
            var channel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(t => t.CustomerUserId == customer.CustomerUserId);

            var transactionsList = await _add_AdContext.Transactions.Where(t => t.TvChannelId == channel.TvChannelId && t.IsApproved == 0).ToListAsync();
            transactionsList.AddRange(await _add_AdContext.Transactions.Where(t => t.TvChannelId == channel.TvChannelId && t.IsApproved == 1).ToListAsync());
            transactionsList.AddRange(await _add_AdContext.Transactions.Where(t => t.TvChannelId == channel.TvChannelId && t.IsApproved == -1).ToListAsync());

            List<TransactionDTO> transactionDTOs = new List<TransactionDTO>();
            foreach (var transaction in transactionsList)
            {
                TransactionDTO transactionDTO = new TransactionDTO
                {
                    TransactionId = transaction.TransactionId,
                    customerUserId = transaction.CustomerUserId,
                    Cost = transaction.Cost,
                    TransactionDate = transaction.TransactionDate,
                    ServiceDate = transaction.ServiceDate,
                    AdDurationInPaper = transaction.AdDurationInPaper ?? 0,
                    NumberOfDays = transaction.NumberOfDays ?? 0,
                    IsApproved = transaction.IsApproved,
                };
                if(transaction.CustomerUserId != null)
                {
                    var user = await _add_AdContext.CustomerUsers.FindAsync(transaction.CustomerUserId);
                    transactionDTO.UserName = user.UserName;
                    transactionDTOs.Add(transactionDTO);
                }
            }

            return transactionDTOs;
        }

        public async Task<string> GetEmailById(int id)
        {
            var customer = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(c => c.CustomerUserId == id);
            return customer.EmailId;
        }

        public List<SearchChannelDTO> EntityToDto(List<SearchChannelDTO> ChannelDto, dynamic channelsList)
        {
            foreach (var channel in channelsList)
            {
                SearchChannelDTO channelDTO = new SearchChannelDTO();
                channelDTO.UserName = channel.UserName;
                channelDTO.TvChannelId = channel.TvChannelId;
                channelDTO.Rating = channel.Rating;
                channelDTO.Language = channel.Language;
                channelDTO.Genre = channel.Genre;
                channelDTO.Cost = channel.Cost;
                ChannelDto.Add(channelDTO);
            }
            return ChannelDto;
        }
    }
}