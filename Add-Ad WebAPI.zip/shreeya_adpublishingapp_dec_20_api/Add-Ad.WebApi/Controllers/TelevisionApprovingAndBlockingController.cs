﻿using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TelevisionApprovingAndBlockingController : ControllerBase
    {

        private readonly ITvChannelServices _tvChannelServices;
        public TelevisionApprovingAndBlockingController(ITvChannelServices tvChannelServices)
        {
            _tvChannelServices = tvChannelServices;
        }
       /* [HttpPost("Approve")]
        public async Task<IActionResult> ApproveTelevision(NewspaperTransactionDTO newspaperTransactionDTO)
        {
           *//* try
            {
                int? transactionId = await _tvChannelServices.ApproveTelevision(newspaperTransactionDTO);
                if (transactionId == 0)
                    return BadRequest("Some error occured");
                return Ok();
            }
            catch (SqlException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }*//*
        }
        [HttpGet("GetPendingNewspapers")]
        public async Task<ActionResult> GetPendingTelevisionChannels()
        {
            *//*try
            {
                return Ok(await _tvChannelServices.GetPendingTelevisionChannels());
            }
            catch (NoNewspaperFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }*//*
        }*/
    }
}
