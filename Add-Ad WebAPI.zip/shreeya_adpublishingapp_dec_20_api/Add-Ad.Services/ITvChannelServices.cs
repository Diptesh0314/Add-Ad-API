﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public interface ITvChannelServices
    {
        public Task<int> RegisterChanel(TvChannel channel);
        Task<object> GetAllChannels();
        Task<object> SearchGenre(string genre);
        Task<object> SearchRating(int rating);
        //To Show Top Tv Channels
        Task<List<TopTvChannel>> ShowTopTvChannels();
        public Task<int> UpdateChannelPrice(TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO);
        public Task<TvChannel> GetByEmail(string email);
        public Task<string> GetEmailTvChannel(int tvChannelId);
        Task<object> GetActiveTvChannel();

        Task<bool> UpdateTvChannel(int tvChannelid);

        Task<List<SearchChannelDTO>> GetNotApprovedTvChannels();

        Task<List<SearchChannelDTO>> GetBlockedTvChannels();

        Task<bool> UnblockTvChannel(int tvChannelid);

        Task<bool> ApproveTvChannel(int tvChannelId);

        Task<bool> RejectTvChannel(int tvChannelId);

        public Task<int?> TransactionStatusConfirmation(Transaction transaction);
        public Task<List<TransactionDTO>> GetPendingTransactionRequests(string email);
        public Task<string> GetEmailById(int id);
    }
}
