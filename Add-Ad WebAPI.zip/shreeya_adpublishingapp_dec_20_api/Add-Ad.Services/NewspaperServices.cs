﻿using Add_Ad.Entity;
using Add_Ad.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;

namespace Add_Ad.Services
{
    /// <summary>
    /// Class is used to handle operations on Newspaper
    /// </summary>
    public class NewspaperServices: INewspaperServices
    {
        private readonly INewspaperRepository _newspaperRepository;

        public NewspaperServices(INewspaperRepository newspaperRepository)
        {
            _newspaperRepository = newspaperRepository;
        }
        /// <summary>
        /// RegisterNewspaper function sends the newspaper object to the NewspaperRepository's RegisterNewspaper
        /// </summary>
        /// <param name="newspaper">Type=Newspaper</param>
        /// <returns>Returns number of rows affected(int)</returns>
     
        public async Task<int> RegisterNewspaper(Newspaper newspaper)
        {
            int rowsAffected = 0;
            rowsAffected =await _newspaperRepository.RegisterNewspaper(newspaper);
            return rowsAffected;
        }
        
        public async Task<object> GetAllNewsPapers()
        {
            try
            {
                return await _newspaperRepository.GetAllNewsPapers();
            }
            catch (NoNewspaperFound e)
            {
                throw new NoNewspaperFound(e.Message);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<object> SearchNewspaper(string name)
        {
            return await _newspaperRepository.SearchNewspaper(name);
        }

        public async Task<object> SearchRating(int rating)
        {

            return await _newspaperRepository.SearchRating(rating);
        }

        public async Task<List<TopNewspaper>> ShowTopNewspapers()
        {
             return await _newspaperRepository.ShowTopNewspapers();
        }

        public async Task<int?> ApproveNewspaper(TransactionDTO newspaperTransactionDTO)
        {
            return await _newspaperRepository.ApproveNewspaper(newspaperTransactionDTO);
        }
        
        public async Task<int?> BlockNewspaper(TransactionDTO newspaperTransactionDTO)
        {
            return await _newspaperRepository.BlockNewspaper(newspaperTransactionDTO);
        }
        public async Task<object> GetPendingNewspapers(string email)
        {
            return await _newspaperRepository.GetPendingNewspapers(email);
        }

        public async Task<object> GetActiveAllNewspapers() {

            return await _newspaperRepository.GetActiveAllNewspapers();
        }

        public async Task<bool> UpdateNewspaper(int newspaperId)
        {
            return await _newspaperRepository.UpdateNewspaper(newspaperId);
        }

        public async Task<List<SearchNewspaperDTO>> GetNotApprovedNewspapers()
        {
            return await _newspaperRepository.GetNotApprovedNewspapers();
        }

        public async Task<List<SearchNewspaperDTO>> GetBlockNewspapers()
        {
            return await _newspaperRepository.GetBlockedNewspapers();
        }

        public async Task<bool> UnblockNewspaper(int newspaperId)
        {
            return await _newspaperRepository.UnblockNewspaper(newspaperId);

        }

        public async Task<bool> ApproveNewspaper(int newspaperId)
        {
            return await _newspaperRepository.ApproveNewspaper(newspaperId);
        }

        public async Task<bool> RejectNewspaper(int newspaperId)
        {
            return await _newspaperRepository.RejectNewspaper(newspaperId);
        }

        public async Task<string> GetEmailNewspaper(int newspaperId)
        {
            return await _newspaperRepository.GetEmailNewspaper(newspaperId);
        }
        public async Task<int> UpdateNewspapersPrice(NewspaperPriceUpdateDTO newspaperPriceUpdateDTO)
        {
            int rowsAffected;
            rowsAffected = await _newspaperRepository.UpdateChannelPrice(newspaperPriceUpdateDTO);
            return rowsAffected;
        }
        public async Task<Newspaper> GetByEmail(string email)
        {
            return await _newspaperRepository.GetByEmail(email);
        }
        public async Task<string> GetEmailOfNewspaper(int customerUserId)
        {
            return await _newspaperRepository.GetEmailOfNewspaper(customerUserId);
        }
    }
}
