﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories
{
    public interface ICustomerUserRepository
    {
        public Task<int?> RegisterUser(CustomerUserDTO userDTO);
        public Task<CustomerUserTokenDTO> AuthenticateUser(CustomerUserDTO userDTO);
        public Task<int?> CheckEmailIfExist(ForgotPasswordDto forgotPasswordDto);
        Task<int?> UpdateUser(CustomerUserDTO userDTO);
        public Task<int?> UpdatePassword(CustomerUserDTO userVal);
        public Task<CustomerUser> UserExists(string EmailId);
    }
}
