﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class SearchNewspaperDTO
    {
        public string UserName { get; set; }

        public double Cost { get; set; }
        public string Language { get; set; }
        public int Rating { get; set; }
        public int? NewsPaperId { get; set; }
       
    }
}
