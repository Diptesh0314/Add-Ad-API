﻿using System;
using System.ComponentModel.DataAnnotations;
namespace Add_Ad.Entity
{
    public class Role
    {
        [Key]
        public int RoleId { get; set; }
        public string RoleType { get; set; }
    }
}
