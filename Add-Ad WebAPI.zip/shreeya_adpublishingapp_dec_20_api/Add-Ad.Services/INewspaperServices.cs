﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public interface INewspaperServices
    {
        public Task<int> RegisterNewspaper(Newspaper newspaper);
        public Task<object> GetAllNewsPapers();
        Task<object> SearchNewspaper(string name);
        Task<object> SearchRating(int rating);
        public Task<List<TopNewspaper>> ShowTopNewspapers();
        
        public Task<int?> ApproveNewspaper(TransactionDTO newspaperTransactionDTO);
        public Task<int?> BlockNewspaper(TransactionDTO newspaperTransactionDTO);
        public Task<object> GetPendingNewspapers(string email);
        Task<object> GetActiveAllNewspapers();

        Task<bool> UpdateNewspaper(int newspaperId);

        Task<List<SearchNewspaperDTO>> GetNotApprovedNewspapers();
        Task<List<SearchNewspaperDTO>> GetBlockNewspapers();

        Task<bool> UnblockNewspaper(int newspaperId);

        Task<bool> ApproveNewspaper(int newspaperId);

        Task<bool> RejectNewspaper(int newspaperId);

        Task<string> GetEmailNewspaper(int newspaperId);
        Task<int> UpdateNewspapersPrice(NewspaperPriceUpdateDTO newspaperPriceUpdateDTO);
        Task<Newspaper> GetByEmail(string email);
        Task<string> GetEmailOfNewspaper(int customerUserId);
    }
}
