﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionServices _transactionServices;

        public TransactionController(ITransactionServices transactionServices)
        {
            _transactionServices = transactionServices;
        }

        [HttpGet("GetId/{name}")]
        public async Task<ActionResult> GetUserId(string name)
        {
            try
            {
                return Ok(await _transactionServices.GetUserId(name));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{email}")]
        public async Task<ActionResult> GetTransaction(string email)
        {
            List<TransactionDTO> transactionDTOs; 
            try
            {
                transactionDTOs = await _transactionServices.GetTransaction(email);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            if (transactionDTOs.Count != 0)
                return Ok(transactionDTOs);
            else
                return Ok(null);
        }

        [HttpPost("calculatecost")]
        public IActionResult CalculateCost(Transaction transaction)
        {
            try
            {
                transaction = _transactionServices.CalculateCost(transaction);
            }
            catch (Exception)
            {
                return BadRequest("Some error occured try again");
            }
            
            return Ok(transaction);
        }

        [HttpPost("AddTransaction")]
        public async Task<IActionResult> AddTransaction(Transaction transaction)
        {
            TransactionDTO transactionDTO;
            try
            {
                transactionDTO = await _transactionServices.AddTransaction(transaction);
            }
            catch (Exception )
            {
                return BadRequest("Some error occured try again");
            }
            if (transactionDTO.TransactionId != 0)
            {
                return Ok(transactionDTO);
            }
            else
            {
                return BadRequest("Transaction not successful try again");
            }
        }
    }
}
        
        
