﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Add_Ad.Entity
{
    public class CustomerUser
    {
        [Key]
        public int? CustomerUserId { get; set; }
        public string UserName { get; set; }
        [StringLength(50)]
        public string EmailId{ get; set; }
        public byte[] PasswordHash{ get; set; }
        public byte[] PasswordSalt { get; set; }

        public int? RoleId { get; set; }

        [ForeignKey("RoleId")]
        public Role Role { get; set; }

    }
}
