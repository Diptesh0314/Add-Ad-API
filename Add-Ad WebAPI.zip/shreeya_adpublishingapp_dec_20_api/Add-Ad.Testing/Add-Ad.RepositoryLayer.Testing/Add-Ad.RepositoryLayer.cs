﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Repositories.TokenInterfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Testing.Add_Ad.RepositoryLayer.Testing
{
    [TestClass]
    public class Add_Ad
    {
        [TestMethod]
        public async Task TestGetAllNews_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.SaveChanges();
                context.Newspapers.Add(new Newspaper { CustomerUserId = 210, Language = "English", Cost = 500, Rating = 3, IsApproved = false, IsBlocked = true });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 210, UserName = "aaj tak" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var newspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetAllNewsPapers();
                Assert.AreNotEqual(1, newspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetAllNews_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.Add(new Newspaper { CustomerUserId = 120, Language = "English", Cost = 500, Rating = 3, IsApproved = true, IsBlocked = false });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 120, UserName = "aaj tak" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var newspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetAllNewsPapers();
                Assert.AreEqual(3, newspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetAllChannels_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 101, IsBlocked = true, CustomerUserId = 212, Genre = "Kids", Language = "English", Cost = 100, IsApproved = true, Rating = 3 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 212, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.GetAllChannels();
                Assert.AreNotEqual(0 ,tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestGetAllChannels_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 100, IsBlocked = false, CustomerUserId = 211, Genre = "Kids", Language = "English", Cost = 100, IsApproved = true, Rating = 3 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 211, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.GetAllChannels();
                Assert.AreEqual(2, tvChannels.Count);
            }
        }

        //[TestMethod]
        //public async Task TestSearchNewsPaper()
        //{
        //    var options = new DbContextOptionsBuilder<Add_AdContext>()
        //        .UseInMemoryDatabase(databaseName: "Orchard1")
        //        .Options;

        //    using (var context = new Add_AdContext(options))
        //    {
        //        context.Newspapers.Add(new Newspaper { NewsPaperId = 3, CustomerUserId = 123, Language = "English", Cost = 0, Rating = 3 });
        //        context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 123, UserName = "TheHindu" });
        //        context.SaveChanges();
        //    }
        //    using (var context = new Add_AdContext(options))
        //    {
        //        NewspaperRepository newspaperRepository = new NewspaperRepository(context);
        //        List<SearchNewspaperDTO> newspapers = (List<SearchNewspaperDTO>)await newspaperRepository.SearchNewspaper("TheHindu");
        //        Assert.AreEqual(1, newspapers.Count);
        //    }
        //}
        [TestMethod]
        public async Task TestRatingNewsPaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.Add(new Newspaper { NewsPaperId = 4, CustomerUserId = 124, IsApproved = true, Language = "English", Cost = 0, Rating = 5 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 124, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> newspapers = (List<SearchNewspaperDTO>)await newspaperRepository.SearchRating(5);
                Assert.AreEqual(1, newspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestRatingNewsPaper_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.Add(new Newspaper { NewsPaperId = 40, CustomerUserId = 224, IsApproved = true, Language = "English", Cost = 0, Rating = 5 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 224, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> newspapers = (List<SearchNewspaperDTO>)await newspaperRepository.SearchRating(10);
                Assert.AreNotEqual(1, newspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestRatingChannel_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 5, CustomerUserId = 125, Genre = "Kids", Language = "English", Cost = 0, Rating = 5 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 125, UserName = "CN" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.SearchRating(5);
                Assert.AreEqual(1, tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestRatingChannel_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 50, CustomerUserId = 225, Genre = "Kids", Language = "English", Cost = 0, Rating = 5 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 225, UserName = "CN" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.SearchRating(10);
                Assert.AreNotEqual(1, tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestGenreChannel_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 6, CustomerUserId = 126, Genre = "Sports", Language = "English", Cost = 200, IsApproved = true, IsBlocked = false, Rating = 3 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 126, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.SearchGenre("Sports");
                Assert.AreEqual(1, tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestGenreChannel_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 60, CustomerUserId = 226, Genre = "Sports", Language = "English", Cost = 200, IsApproved = true, IsBlocked = false, Rating = 3 });
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 226, UserName = "Hungama" });
                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepository.SearchGenre("xyz");
                Assert.AreNotEqual(1, tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestAllRoles()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Roles.Add(new Role { RoleId = 5, RoleType = "ABC" });
                context.SaveChanges();
                List<Role> roles = await context.Roles.ToListAsync();
                Assert.AreEqual(1, roles.Count);
            }
        }

        [TestMethod]
        public void TestGetAllNewsPaper_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
              .UseInMemoryDatabase(databaseName: "Orchard1")
              .Options;

            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);

                Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperRepository.GetAllNewsPapers());
            }
        }

        [TestMethod]
        public void TestSearchNewspaper_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);

                Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperRepository.SearchNewspaper("Hindustan Times"));
            }
        }

        [TestMethod]
        public void TestSearchRating_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);

                Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperRepository.SearchRating(9));
            }
        }

        [TestMethod]
        public void TestGetAllChannel_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository channelRepository = new TvChannelRepository(context);

                Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelRepository.GetAllChannels());
            }
        }

        [TestMethod]
        public void TestSearchChannelRating_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository channelRepository = new TvChannelRepository(context);

                Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelRepository.SearchRating(12));
            }
        }

        [TestMethod]
        public void TestSearchGenre_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository channelRepository = new TvChannelRepository(context);

                Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelRepository.SearchGenre("Music"));
            }
        }

        [TestMethod]
        public async Task TestUserExists_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 128, UserName = "Hungama", EmailId = "anushr405@gmail.com" });
                context.SaveChanges();
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                var userId = await userRepo.UserExists("anushr405@gmail.com");
                Assert.AreEqual(128, userId.CustomerUserId);
            }
        }

        [TestMethod]
        public async Task TestUserExists_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                CustomerUserRepository customerUserRepository = new CustomerUserRepository(context);
                var userId = await customerUserRepository.UserExists("anushr4055@gmail.com");
                Assert.AreEqual(null, userId);
            }
        }

        [TestMethod]
        public async Task TestCheckEmailIfExist_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 129, UserName = "Hungama", EmailId = "thanushr405@gmail.com" });
                context.SaveChanges();
                ForgotPasswordDto forgotDto = new ForgotPasswordDto();
                forgotDto.Email = "thanushr405@gmail.com";
                CustomerUserRepository userRepo = new CustomerUserRepository(context);

                int? exist = await userRepo.CheckEmailIfExist(forgotDto);

                context.SaveChanges();
                Assert.AreEqual(129, exist);
            }
        }

        [TestMethod]
        public async Task TestCheckEmailIfExist_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                ForgotPasswordDto forgotDto = new ForgotPasswordDto();
                forgotDto.Email = "abd40555@gmail.com";
                CustomerUserRepository userRepo = new CustomerUserRepository(context);

                int? exist = await userRepo.CheckEmailIfExist(forgotDto);

                context.SaveChanges();
                Assert.AreEqual(1, exist);
            }
        }

        [TestMethod]
        public async Task TestCheckEmailIfExist_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    ForgotPasswordDto forgotDto = new ForgotPasswordDto();
                    CustomerUserRepository userRepo = new CustomerUserRepository(context);

                    int? exist = await userRepo.CheckEmailIfExist(forgotDto);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        [TestMethod]
        public async Task TestUsernameExists_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 12, UserName = "thanushokay", EmailId = "thanr405@gmail.com" });
                context.SaveChanges();
                CustomerUserRepository userRepo = new CustomerUserRepository(context);

                var userId = await userRepo.UsernameExists("thanushokay");

                context.SaveChanges();
                Assert.AreEqual(12, userId.CustomerUserId);
            }
        }

        [TestMethod]
        public async Task TestUsernameExists_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                CustomerUserRepository userRepo = new CustomerUserRepository(context);

                var userId = await userRepo.UsernameExists("klklkll");

                Assert.AreEqual(null, userId);
            }
        }

        //Login with valid password and mail
        //[TestMethod]
        //public async Task TestAuthenticateUser_happy()
        //{
        //    var options = new DbContextOptionsBuilder<Add_AdContext>()
        //        .UseInMemoryDatabase(databaseName: "Orchard1")
        //        .Options;

        //    using (var context = new Add_AdContext(options))
        //    {
        //        using var hmac = new HMACSHA512();
        //        var pass = "Hello@123";
        //        Byte[] PasswordHash = new Byte[128 / 8];
        //        PasswordHash=hmac.ComputeHash(Encoding.UTF8.GetBytes(pass));
        //        Byte[] PasswordSalt = new Byte[128 / 8];
        //        PasswordSalt= hmac.Key;

        //        var customerUser = new CustomerUser { CustomerUserId = 137,RoleId=1, UserName = "thanush", EmailId = "thanushr405@gmail.com", PasswordHash = PasswordHash, PasswordSalt = PasswordSalt };
        //        context.CustomerUsers.Add(customerUser);
        //        context.SaveChanges();

        //        var mock = new Mock<ITokenCustomerService>();
        //        mock.Setup(p => p.CreateToken(customerUser)).Returns("bhim");
        //        CustomerUserRepository userRepo = new CustomerUserRepository(context, mock.Object);
        //        CustomerUserDTO userDto = new CustomerUserDTO();

        //        userDto.EmailId = "thanushr405@gmail.com";
        //        userDto.PassWord = "Hello@123";

        //        var userId = await userRepo.AuthenticateUser(userDto);
        //        userId.Token = "bhim";
        //        context.SaveChanges();
        //        Assert.AreEqual("thanushr405@gmail.com", userId.EmailId);
        //        Assert.AreEqual("bhim", userId.Token);
        //    }
        //}

        //login with valid mail and invalid password
        //[TestMethod]
        //public async Task TestAuthenticateUser_sad_invalidPassword()
        //{
        //    var options = new DbContextOptionsBuilder<Add_AdContext>()
        //       .UseInMemoryDatabase(databaseName: "Orchard1")
        //       .Options;

        //    using (var context = new Add_AdContext(options))
        //    {
        //        using var hmac = new HMACSHA512();
        //        var pass = "Hello@123";
        //        Byte[] PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(pass));
        //        Byte[] PasswordSalt = hmac.Key;

        //        /* var customerUser = new CustomerUser { CustomerUserId = 130, UserName = "thanush", EmailId = "thanushr405@gmail.com", PasswordHash = PasswordHash, PasswordSalt = PasswordSalt };
        //         context.CustomerUsers.Add(customerUser);
        //         context.SaveChanges();*//*

        //         CustomerUserRepository userRepo = new CustomerUserRepository(context);
        //         CustomerUserDTO userDto = new CustomerUserDTO();

        //         userDto.EmailId = "thanushr405@gmail.com";
        //         userDto.PassWord = "Hello";

        //         var returnValue = await userRepo.AuthenticateUser(userDto);

        //         context.SaveChanges();
        //         Assert.AreEqual(null, returnValue);
        //     }
        // }*/

        //login with invalid mail
       
        //login with invalid mail
[TestMethod]
public async Task TestAuthenticateUser_sad()
{
    var options = new DbContextOptionsBuilder<Add_AdContext>()
        .UseInMemoryDatabase(databaseName: "Orchard1")
        .Options;

            using (var context = new Add_AdContext(options))
            {
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                CustomerUserDTO userDTO = new CustomerUserDTO();
                userDTO.EmailId = "aaa@gmail.com";
                var userIdNullValue = await userRepo.AuthenticateUser(userDTO);
                context.SaveChanges();
                Assert.AreEqual(null, userIdNullValue);
            }
        }

        //UpdatePassword
        [TestMethod]
        public async Task TestUpdatePassword_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                using var hmac = new HMACSHA512();
                var pass = "Hello@123";
                Byte[] PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(pass));
                Byte[] PasswordSalt = hmac.Key;
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 139, UserName = "thanush", EmailId = "thanushrmm405@gmail.com", PasswordHash = PasswordHash, PasswordSalt = PasswordSalt });
                context.SaveChanges();
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                CustomerUserDTO userDto = new CustomerUserDTO();
                userDto.Token = 139;
                userDto.EmailId = "thanushrmm405@gmail.com";
                userDto.PassWord = "Hello@123";
                var userId = await userRepo.UpdatePassword(userDto);
                Assert.AreEqual(139, userId);
            }
        }

        [TestMethod]
        public async Task TestUpdatePassword_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                ///
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                CustomerUserDTO userDTO = new CustomerUserDTO();
                userDTO.EmailId = "aaa@gmail.com";
                var userIdNullValue = await userRepo.UpdatePassword(userDTO);
                context.SaveChanges();
                Assert.AreEqual(0, userIdNullValue);
            }
        }

        [TestMethod]
        public async Task TestUpdatePassword_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    CustomerUserRepository userRepo = new CustomerUserRepository(context);
                    CustomerUserDTO userDto = new CustomerUserDTO();
                    var userIdNullValue = await userRepo.UpdatePassword(userDto);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        //Update user
        [TestMethod]
        public async Task TestUpdateUser_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                using var hmac = new HMACSHA512();
                var pass = "Hello@123";
                Byte[] PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(pass));
                Byte[] PasswordSalt = hmac.Key;
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 133, UserName = "thanush", EmailId = "thanushl405@gmail.com", PasswordHash = PasswordHash, PasswordSalt = PasswordSalt });
                context.SaveChanges();
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                CustomerUserDTO userDto = new CustomerUserDTO();

                userDto.EmailId = "thanushl405@gmail.com";
                userDto.PassWord = "Hello123";
                var userId = await userRepo.UpdateUser(userDto);
                Assert.AreEqual(133, userId);
            }
        }

        [TestMethod]
        public async Task TestUpdateUser_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                var userId = await context.CustomerUsers.FirstOrDefaultAsync(x => x.EmailId == "thanushj@gmail.com");

                context.SaveChanges();
                Assert.AreEqual(null, userId);
                ///
                CustomerUserRepository userRepo = new CustomerUserRepository(context);
                CustomerUserDTO userDTO = new CustomerUserDTO();
                userDTO.EmailId = "aaa@gmail.com";
                var userIdNullValue = await userRepo.UpdateUser(userDTO);
                context.SaveChanges();
                Assert.AreEqual(0, userIdNullValue);
            }
        }

        [TestMethod]
        public async Task TestUpdateUser_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    CustomerUserRepository userRepo = new CustomerUserRepository(context);
                    CustomerUserDTO userDto = new CustomerUserDTO();
                    var userIdNullValue = await userRepo.UpdateUser(userDto);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        //RegisterUser
        [TestMethod]
        public async Task TestRegisterUser_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser
                {
                    CustomerUserId = 16,
                    UserName = "thanush",
                    EmailId = "thanusq@gmail.com",
                    PasswordHash = new byte[] { 0x20, 0x20 },
                    PasswordSalt = new byte[] { 0x20, 0x20 }
                });
                context.SaveChanges();
                CustomerUserDTO userDto = new CustomerUserDTO();
                userDto.EmailId = "ruhi@gmail.com";
                userDto.PassWord = "Hello@111";
                userDto.RoleId = 2;
                userDto.UserName = "ruhi";
                CustomerUserRepository userRepo = new CustomerUserRepository(context);

                var userId = await userRepo.RegisterUser(userDto);

                Assert.AreEqual(184505, userId);
            }
        }

        [TestMethod]
        public async Task TestRegisterUser_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    CustomerUserRepository userRepo = new CustomerUserRepository(context);
                    CustomerUserDTO userDto = new CustomerUserDTO();
                    var userId = await userRepo.RegisterUser(userDto);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        //[TestMethod]
        [TestMethod]
        public async Task TestTopTvChannels_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.AddRange(new TvChannel { TvChannelId = 1200, CustomerUserId = 200, Genre = "Kids", Language = "English", Cost = 20, Rating = 3, IsApproved = true, IsBlocked = false },
                    new TvChannel { TvChannelId = 1201, CustomerUserId = 201, Genre = "Kids", Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false },
                    new TvChannel { TvChannelId = 1202, CustomerUserId = 202, Genre = "Sports", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new TvChannel { TvChannelId = 1203, CustomerUserId = 203, Genre = "Music", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 200, UserName = "P" },
                   new CustomerUser { CustomerUserId = 201, UserName = "Q" },
                   new CustomerUser { CustomerUserId = 202, UserName = "R" },
                   new CustomerUser { CustomerUserId = 203, UserName = "S" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<TopTvChannel> topTvChannels = (List<TopTvChannel>)await tvChannelRepository.ShowTopTvChannels();
                Assert.AreEqual(4, topTvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestTopNewspapers_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.AddRange(new Newspaper { NewsPaperId = 3000, CustomerUserId = 4000, Language = "English", Cost = 20, Rating = 3, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 3001, CustomerUserId = 4001, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 3002, CustomerUserId = 4002, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 3003, CustomerUserId = 4003, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 4000, UserName = "O" },
                   new CustomerUser { CustomerUserId = 4001, UserName = "I" },
                   new CustomerUser { CustomerUserId = 4002, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 4003, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<TopNewspaper> topNewspapers = (List<TopNewspaper>)await newspaperRepository.ShowTopNewspapers();
                Assert.AreEqual(4, topNewspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetActiveNewspapers_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.AddRange(new Newspaper { NewsPaperId = 800, CustomerUserId = 7001, Language = "English", Cost = 20, Rating = 3, IsApproved = false, IsBlocked = false },
                    new Newspaper { NewsPaperId = 801, CustomerUserId = 7002, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 803, CustomerUserId = 7002, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 804, CustomerUserId = 7003, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 7000, UserName = "O" },
                   new CustomerUser { CustomerUserId = 7001, UserName = "I" },
                   new CustomerUser { CustomerUserId = 7002, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 7003, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> topNewspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetActiveAllNewspapers();
                Assert.AreEqual(12, topNewspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetActiveTvChannels_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.AddRange(new TvChannel { TvChannelId = 8000, CustomerUserId = 70010, Language = "English", Cost = 20, Rating = 3, IsApproved = true, IsBlocked = false, Genre = "Kids" },
                    new TvChannel { TvChannelId = 8010, CustomerUserId = 70020, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false, Genre = "Kids" },
                    new TvChannel { TvChannelId = 8030, CustomerUserId = 70020, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false, Genre = "Kids" },
                    new TvChannel { TvChannelId = 8040, CustomerUserId = 70030, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false, Genre = "Kids" });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 70010, UserName = "O" },
                   new CustomerUser { CustomerUserId = 70020, UserName = "I" },
                   new CustomerUser { CustomerUserId = 70030, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 70040, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepo = new TvChannelRepository(context);
                List<SearchChannelDTO> tvChannels = (List<SearchChannelDTO>)await tvChannelRepo.GetActiveTvChannel();
                Assert.AreEqual(12, tvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestGetBlockNewspapers_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.AddRange(new Newspaper { NewsPaperId = 350, CustomerUserId = 410, Language = "English", Cost = 20, Rating = 3, IsApproved = false, IsBlocked = true },
                    new Newspaper { NewsPaperId = 351, CustomerUserId = 411, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = true },
                    new Newspaper { NewsPaperId = 352, CustomerUserId = 412, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 353, CustomerUserId = 413, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 410, UserName = "O" },
                   new CustomerUser { CustomerUserId = 411, UserName = "I" },
                   new CustomerUser { CustomerUserId = 412, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 413, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> topNewspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetBlockedNewspapers();
                Assert.AreEqual(4, topNewspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetNotApprovedNewspapers_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.AddRange(new Newspaper { NewsPaperId = 6250, CustomerUserId = 3269, Language = "English", Cost = 20, Rating = 3, IsApproved = false, IsBlocked = false },
                    new Newspaper { NewsPaperId = 6261, CustomerUserId = 3527, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = true },
                    new Newspaper { NewsPaperId = 6227, CustomerUserId = 3828, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 6248, CustomerUserId = 3529, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 3269, UserName = "O" },
                   new CustomerUser { CustomerUserId = 3527, UserName = "I" },
                   new CustomerUser { CustomerUserId = 3828, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 3529, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> topNewspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetNotApprovedNewspapers();
                Assert.AreEqual(2, topNewspapers.Count);
            }
        }

        [TestMethod]
        public async Task TestGetBlockTvChannels_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.AddRange(new TvChannel { TvChannelId = 5625, CustomerUserId = 2365, Language = "English", Cost = 20, Rating = 3, IsApproved = false, IsBlocked = false },
                    new TvChannel { TvChannelId = 6221, CustomerUserId = 3527, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = true },
                    new TvChannel { TvChannelId = 6224, CustomerUserId = 3828, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new TvChannel { TvChannelId = 6249, CustomerUserId = 3529, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 7785, UserName = "O" },
                   new CustomerUser { CustomerUserId = 5623, UserName = "I" },
                   new CustomerUser { CustomerUserId = 4758, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 5698, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> topTvChannels = (List<SearchChannelDTO>)await tvChannelRepository.GetBlockedTvChannels();
                Assert.AreEqual(3, topTvChannels.Count);
            }
        }

        [TestMethod]
        public async Task TestGetNotApprovedTvChannels_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.AddRange(new TvChannel { TvChannelId = 13265, CustomerUserId = 2365, Language = "English", Cost = 20, Rating = 3, IsApproved = false, IsBlocked = false },
                    new TvChannel { TvChannelId = 13266, CustomerUserId = 3527, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = true },
                    new TvChannel { TvChannelId = 13267, CustomerUserId = 3828, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new TvChannel { TvChannelId = 13268, CustomerUserId = 3529, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = false, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 1256, UserName = "O" },
                   new CustomerUser { CustomerUserId = 1896, UserName = "I" },
                   new CustomerUser { CustomerUserId = 7485, UserName = "ZZ" },
                   new CustomerUser { CustomerUserId = 12349, UserName = "LL" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<SearchChannelDTO> topTvChannels = (List<SearchChannelDTO>)await tvChannelRepository.GetNotApprovedTvChannels();
                Assert.AreEqual(3, topTvChannels.Count);
            }

           
        }

        [TestMethod]
        public async Task TestActiveAllNewspapers_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Newspapers.AddRange(new Newspaper { NewsPaperId = 300, CustomerUserId = 400, Language = "English", Cost = 20, Rating = 3, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 301, CustomerUserId = 401, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 302, CustomerUserId = 402, Language = "Hindi", Cost = 102, Rating = 5, IsApproved = true, IsBlocked = false },
                    new Newspaper { NewsPaperId = 303, CustomerUserId = 403, Language = "Hindi", Cost = 100, Rating = 5, IsApproved = true, IsBlocked = false });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 400, UserName = "India Today" },
                   new CustomerUser { CustomerUserId = 401, UserName = "Dainik Jagran" },
                   new CustomerUser { CustomerUserId = 402, UserName = "Umar Ujala" },
                   new CustomerUser { CustomerUserId = 403, UserName = "Econmic Times" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                List<SearchNewspaperDTO> activeNewspapers = (List<SearchNewspaperDTO>)await newspaperRepository.GetActiveAllNewspapers();
                Assert.AreEqual(20, activeNewspapers.Count);
            }
        }

        [TestMethod]
        public async Task TvChannelInsertionExceptionTest()
        {
            TvChannelInsertionException tvChannelInsertionException = new TvChannelInsertionException();
            TvChannelInsertionException tvChannelInsertionExceptionMsg = new TvChannelInsertionException("This");
            TvChannelInsertionException tvChannelInsertionExceptionInner = new TvChannelInsertionException("This", new Exception());
        }

        [TestMethod]
        public async Task UserAlreadyExistsExceptionTest()
        {
            UserAlreadyExistsException tvChannelInsertionException = new UserAlreadyExistsException();
            UserAlreadyExistsException tvChannelInsertionExceptionMsg = new UserAlreadyExistsException("This");
            UserAlreadyExistsException tvChannelInsertionExceptionInner = new UserAlreadyExistsException("This", new Exception());
        }

        [TestMethod]
        public async Task NoTvChannelFoundTest()
        {
            NoTvChannelFound tvChannelInsertionException = new NoTvChannelFound();
            NoTvChannelFound tvChannelInsertionExceptionMsg = new NoTvChannelFound("This");
        }

        [TestMethod]
        public async Task NoNewspaperFoundTest()
        {
            NoNewspaperFound tvChannelInsertionException = new NoNewspaperFound();
            NoNewspaperFound tvChannelInsertionExceptionMsg = new NoNewspaperFound("This");
        }

        [TestMethod]
        public async Task NewspaperInsertionExceptionTest()
        {
            NewspaperInsertionException newspaperInsertionException = new NewspaperInsertionException();
            NewspaperInsertionException newspaperInsertionExceptionMsg = new NewspaperInsertionException("This");
            NewspaperInsertionException newspaperInsertionExceptionInner = new NewspaperInsertionException("This", new Exception());
        }

        [TestMethod]
        public async Task SqlExceptionTest()
        {
            SqlException sqlExceptionMsg = new SqlException("This");
            SqlException sqlExceptionInner = new SqlException("This", new Exception());
        }

        /*[TestMethod]
        public async Task GetTransactionTest()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 01, UserName = "Ruhi" });
                context.SaveChanges();

        context.Transactions.Add(new Entity.Transaction { CustomerUserId=01, Cost=200 });
        context.SaveChanges();

                context.SaveChanges();
                TransactionRepository transactionRepository = new TransactionRepository(context);
                List<TransactionHistoryDTO> transactions = (List<TransactionHistoryDTO>)await transactionRepository.GetTransaction("Ruhi");
                Assert.AreEqual(1, transactions.Count);
            }
            using (var context = new Add_AdContext(options))
            {
            }
        }*/

        [TestMethod]
        public async Task TestGetByEmail_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.AddRange(new TvChannel { CustomerUserId = 1505, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 501 });

                context.CustomerUsers.AddRange(new CustomerUser { CustomerUserId = 1505, UserName = "India Today", EmailId = "diptesh3081@outlook.com" });

                context.SaveChanges();
            }
            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                TvChannel tvChannel = await tvChannelRepository.GetByEmail("diptesh3081@outlook.com");
                Assert.AreEqual(1600, tvChannel.Cost);
            }
        }

        [TestMethod]
        public async Task TestGetByEmail_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
                    var newspaper = await newspaperRepository.GetByEmail("aaa@gmail.com");
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);

                //        context.SaveChanges();

                //    }
                //    using (var context = new Add_AdContext(options))
                //    {
                //        TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                //        TvChannel tvChannel = await tvChannelRepository.GetByEmail("diptesh308@outlook.com");
                //        Assert.AreEqual(1600, tvChannel.Cost);
                //    }
                //}
            }
        }

        [TestMethod]
        public async Task TestUpdateNewspaperPrice_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1504, UserName = "thanush", EmailId = "deccanherald2@gmail.com" });
                context.Newspapers.Add(new Newspaper { NewsPaperId = 1125, CustomerUserId = 1504, Cost = 141 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
                newspaperPriceUpdateDTO.Cost = 141;
                newspaperPriceUpdateDTO.Email = "deccanherald2@gmail.com";
                var rowCount = await newspaperRepository.UpdateChannelPrice(newspaperPriceUpdateDTO);
                Assert.AreEqual(1, rowCount);
            }
        }

        [TestMethod]
        public async Task TestUpdateNewspaperPrice_sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1503, UserName = "thanush", EmailId = "deccanherald1@gmail.com" });
                //context.Newspapers.Add(new Newspaper { NewsPaperId = 112, CustomerUserId = 1503, Cost = 139 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
                newspaperPriceUpdateDTO.Cost = 140;
                newspaperPriceUpdateDTO.Email = "deccanherald1@gmail.com";
                var rowCount = await newspaperRepository.UpdateChannelPrice(newspaperPriceUpdateDTO);
                Assert.AreEqual(-1, rowCount);
            }
        }

        [TestMethod]
        public async Task TestUpdateNewspaperPrice_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
                    var newspaper = await newspaperRepository.UpdateChannelPrice(newspaperPriceUpdateDTO);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        //GetByEmail
        [TestMethod]
        public async Task GetByEmail_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1501, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.Newspapers.Add(new Newspaper { NewsPaperId = 1123, CustomerUserId = 1501, Cost = 139 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var newspaper = await newspaperRepository.GetByEmail("deccanherald@gmail.com");
                Assert.AreEqual(1501, newspaper.CustomerUserId);
            }
        }

        [TestMethod]
        public async Task GetByEmail_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    var newspaper = await newspaperRepository.GetByEmail("deccanherald@gmail.com");
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        //GetEmailOfNewspaper
        [TestMethod]
        public async Task GetEmailOfNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1499, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.Transactions.Add(new Entity.Transaction { CustomerUserId = 1499 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var newspaper = await newspaperRepository.GetEmailOfNewspaper(1499);
                Assert.AreEqual("deccanherald@gmail.com", newspaper);
            }
        }

        [TestMethod]
        public async Task GetEmailOfNewspaper_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1500, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { NewsPaperId = 1122, CustomerUserId = 1500, Cost = 139 });
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    var newspaper = await newspaperRepository.GetEmailOfNewspaper(1233);
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }

        [TestMethod]
        public void TestTransactionToTransactionDTO_Happy()
        {
            Entity.Transaction transac = new Entity.Transaction();
            TransactionDTO transactionDTO = new TransactionDTO();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                transac = new Entity.Transaction
                {
                    TransactionId = 65,
                    Cost = 5000,
                    IsApproved = 0,
                    NumberOfDays = 5
                };

                context.SaveChanges();
                transactionDTO = new TransactionDTO { TransactionId = 65, Cost = 5000, IsApproved = 0, NumberOfDays = 5, PageNumber = 2 };

                TransactionRepository transactionRepo = new TransactionRepository(context);

                TransactionDTO transaction = transactionRepo.TransactionToTransactionDTO(transac, transactionDTO);
                Assert.AreEqual(65, transaction.TransactionId);
            }
        }

        [TestMethod]
        public void TestEntityToDto_Happy()
        {
            List<SearchChannelDTO> searchChannels = new List<SearchChannelDTO>();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                List<SearchChannelDTO> channel = new List<SearchChannelDTO>
                {
                    new SearchChannelDTO{UserName="abc",Cost=50}
                };

                NewspaperRepository newspaperRepo = new NewspaperRepository(context);

                List<SearchChannelDTO> searchChannelDTOs = newspaperRepo.EntityToDto(searchChannels, channel);
                Assert.AreEqual("abc", searchChannelDTOs[0].UserName);
            }
        }

        [TestMethod]
        public void TestEntityToDtoNewspaper_Happy()
        {
            List<SearchNewspaperDTO> searchNewspapers = new List<SearchNewspaperDTO>();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                List<SearchNewspaperDTO> newspaper = new List<SearchNewspaperDTO>
                {
                    new SearchNewspaperDTO{NewsPaperId=5,UserName="abc",Cost=15,Rating=3,Language="Hindi"}
                };

                NewspaperRepository newspaperRepo = new NewspaperRepository(context);


                List<SearchNewspaperDTO> searchNewsDTOs = newspaperRepo.EntityToDto(searchNewspapers, newspaper);
                Assert.AreEqual("abc", searchNewsDTOs[0].UserName);



            }



        }

        [TestMethod]
        public async Task TestUpdateNewspricePrice_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 157, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.SaveChanges();
                context.Newspapers.Add(new Newspaper { NewsPaperId = 111, CustomerUserId = 157, Cost = 139 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO
                {
                    Cost = 139,
                    Email = "deccanherald@gmail.com"
                };
                var rowCount = await newspaperRepository.UpdateChannelPrice(newspaperPriceUpdateDTO);
                Assert.AreEqual(1, rowCount);
            }
        }

        [TestMethod]
        public void TestUpdateNewspricePrice_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 179, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.SaveChanges();
                context.Newspapers.Add(new Newspaper { NewsPaperId = 112, CustomerUserId = 179, Cost = 139 });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO
                {
                    Cost = 139,
                    Email = "deccanherald@gmail.com"
                };
                Assert.ThrowsExceptionAsync<Exception>(async () => await newspaperRepository.UpdateChannelPrice(null));
            }
        }

        [TestMethod]
        public async Task TestUpdateTvChannel_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 257, CustomerUserId = 193, Cost = 5700, IsApproved = false, IsBlocked = false });
                context.SaveChanges();
                TvChannelRepository tvChannel = new TvChannelRepository(context);
                bool value = await tvChannel.UpdateTvChannel(257);
                Assert.AreEqual(true, value);
            }
        }

        [TestMethod]
        public void TestUpdateTvChannel_Bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 259, CustomerUserId = 193, Cost = 5700, IsApproved = false, IsBlocked = false });
                context.SaveChanges();
                TvChannelRepository tvChannel = new TvChannelRepository(context);
                Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannel.UpdateTvChannel(0));
            }
        }

        [TestMethod]
        public void TestEntityToDtoChannel_Happy()
        {
            List<SearchChannelDTO> searchChannels = new List<SearchChannelDTO>();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                List<SearchChannelDTO> channel = new List<SearchChannelDTO>
        {
            new SearchChannelDTO{TvChannelId=393,Cost=5600,Genre="Cartoon",Rating=2,UserName="abc",Language="English" }
        };

                TvChannelRepository channelRepo = new TvChannelRepository(context);

                List<SearchChannelDTO> searchChannelDTOs = channelRepo.EntityToDto(searchChannels, channel);
                Assert.AreEqual("abc", searchChannelDTOs[0].UserName);
            }
        }

        [TestMethod]
        public async Task GetPendingTransactionRequests_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1520, UserName = "thanush", EmailId = "deccanherald6@gmail.com" });
                context.TvChannels.Add(new TvChannel { CustomerUserId = 1520, TvChannelId = 1100 });
                context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                List<TransactionDTO> transactionDTO1 = new List<TransactionDTO>();
                TransactionDTO transactionDTO = new TransactionDTO
                {
                    TransactionId = 1100,
                    customerUserId = 1520,
                    Cost = 1400,
                    UserName = "okay7",
                    IsApproved = 1
                };
                transactionDTO1.Add(transactionDTO);
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                List<TransactionDTO> newspaper = await tvChannelRepository.GetPendingTransactionRequests("deccanherald6@gmail.com");
                Assert.AreEqual(transactionDTO1.Count, newspaper.Count);
            }
        }

        [TestMethod]
        public async Task GetPendingNewspapers_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                context.Transactions.Add(new Entity.Transaction { NewsPaperId = 1101, CustomerUserId = 1521 });
                List<TransactionDTO> transactionDTO1 = new List<TransactionDTO>();
                TransactionDTO transactionDTO = new TransactionDTO
                {
                    TransactionId = 1101,
                    customerUserId = 1521,
                    Cost = 1400,
                    UserName = "okay7",
                    IsApproved = 1
                };
                transactionDTO1.Add(transactionDTO);
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var newspaper = await newspaperRepository.GetPendingNewspapers("deccanherald7@gmail.com");
                Assert.IsNotNull(newspaper);
            }
        }

        [TestMethod]
        public async Task GetPendingNewspapers_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                    context.Transactions.Add(new Entity.Transaction { NewsPaperId = 1101, CustomerUserId = 1521 });
                    List<TransactionDTO> transactionDTO1 = new List<TransactionDTO>();
                    TransactionDTO transactionDTO = new TransactionDTO
                    {
                        TransactionId = 1101,
                        customerUserId = 1521,
                        Cost = 1400,
                        UserName = "okay7",
                        IsApproved = 1
                    };
                    transactionDTO1.Add(transactionDTO);
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    var newspaper = await newspaperRepository.GetPendingNewspapers("deccanherald7@gmail.com");
                }
                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }        
        public async Task TestAddTransactionChannel_Happy()
        {
            Entity.Transaction transac = new Entity.Transaction();
            TransactionDTO transactionDTO = new TransactionDTO();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {

                transac = new Entity.Transaction
                {
                    TransactionId = 65,Cost = 5000,IsApproved = 0,NumberOfDays = 5,AdDurationInPaper=15,CustomerUserId=71,
                    TvChannelId=31,
                    NewsPaperId=0,
                };
                CustomerUser customerUser = new CustomerUser { CustomerUserId = 71, EmailId = "diptesh308@gmail.com", UserName = "abc" };
                context.CustomerUsers.Add(customerUser);
                await context.SaveChangesAsync();
                TvChannel tvChannel = new TvChannel { TvChannelId = 31, Cost = 5000, CustomerUserId = 71 };
                context.TvChannels.Add(tvChannel);
                await context.SaveChangesAsync();
                TransactionRepository transactionRepo = new TransactionRepository(context);


                TransactionDTO transaction =await transactionRepo.AddTransaction(transac);
                Assert.AreEqual(65, transaction.TransactionId);
            }
        }


        [TestMethod]
        public async Task TestAddTransactionNewspaper_Happy()
        {

            Entity.Transaction transac = new Entity.Transaction();
            TransactionDTO transactionDTO = new TransactionDTO();
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {

                transac = new Entity.Transaction
                {
                    TransactionId = 69,
                    Cost = 12,
                    IsApproved = 0,
                    AdSizeInPaper=12,
                    CustomerUserId = 189,
                    TvChannelId = 0,
                    NewsPaperId = 157,
                };

                CustomerUser customerUser = new CustomerUser { CustomerUserId = 189, EmailId = "diptesh308@gmail.com", UserName = "abc" };
                context.CustomerUsers.Add(customerUser);
                await context.SaveChangesAsync();
                Newspaper newspaper = new Newspaper { NewsPaperId=157, Cost = 12, CustomerUserId = 189};
                context.Newspapers.Add(newspaper);
                await context.SaveChangesAsync();
                TransactionRepository transactionRepo = new TransactionRepository(context);


                TransactionDTO transaction = await transactionRepo.AddTransaction(transac);
                Assert.AreEqual(69, transaction.TransactionId);
            }
        }


        [TestMethod]
        public async Task TestGetUserId_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {

                CustomerUser customerUser = new CustomerUser { CustomerUserId = 391, EmailId = "dipteshhh@gmail.com", UserName = "mno" };
                context.CustomerUsers.Add(customerUser);
                await context.SaveChangesAsync();
                TransactionRepository transactionRepo = new TransactionRepository(context);
                int? value = await transactionRepo.GetUserId("mno");
                Assert.AreEqual(391, value);
            }
        }


        
        [TestMethod]
        public async Task GetActiveTvChannel_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1523, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                    context.TvChannels.Add(new TvChannel { CustomerUserId = 1523, TvChannelId = 1100 });
                    context.Transactions.Add(new Entity.Transaction { NewsPaperId = 1101, CustomerUserId = 1521 });
                    List<SearchChannelDTO> tvChannels = new List<SearchChannelDTO>();
                    SearchChannelDTO tvChannel = new SearchChannelDTO
                    {
                        TvChannelId = 1312,
                        Cost = 1400,
                        UserName = "okay7"
                    };
                    tvChannels.Add(tvChannel);
                    context.SaveChanges();
                    TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                    var newspaper = await tvChannelRepository.GetActiveTvChannel();
                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }
        [TestMethod]
        public async Task GetTransactionNewspaperTest()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 01, UserName = "Ruhi", EmailId = "rr@gmail.com" });
                context.SaveChanges();
                context.Transactions.Add(new Transaction { CustomerUserId = 01, TvChannelId = 140, NewsPaperId = 150, AdSizeInPaper = 10, AdDurationInPaper = 20
                });
                context.SaveChanges();
                context.Newspapers.Add(new Newspaper
                {
                    CustomerUserId = 01,
                    NewsPaperId = 150
                });
                context.SaveChanges();
                context.TvChannels.Add(new TvChannel
                {
                    CustomerUserId = 01,
                    TvChannelId = 140
                });
                context.SaveChanges();
                List<Transaction> transactions = new List<Transaction>();
                Transaction transaction = new Transaction
                {
                    CustomerUserId = 01,
                    Cost = 200
                };
                transactions.Add(transaction);
                context.SaveChanges();
                List<TransactionDTO> transactionDTO1 = new List<TransactionDTO>();
                TransactionDTO transactionDTO = new TransactionDTO
                {
                    TvChannelId = 140,
                    NewsPaperId = 150,

                    TransactionId = 1101,
                    customerUserId = 01,
                    Cost = 1400,
                    UserName = "okay7",
                    IsApproved = 1
                };
                transactionDTO1.Add(transactionDTO);
                context.SaveChanges();
            }
        }


        [TestMethod]
        public async Task TestGetEmailById_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1658, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.SaveChanges();
                context.TvChannels.Add(new TvChannel { TvChannelId = 2321, CustomerUserId = 1658, Cost = 139 ,Genre="Music"});
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                string email = await tvChannelRepository.GetEmailById(1658);

           
                TransactionRepository transactionRepository = new TransactionRepository(context);
                List<TransactionDTO> list=await transactionRepository.GetTransaction("rr@gmail.com");
                Assert.AreEqual(1, list.Count);
            }
        }


        [TestMethod]
        public async Task GetTransactionTvChannelTest()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;
            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 2501, UserName = "Ruhi", EmailId = "rr@gmail.com" });
                context.SaveChanges();
                context.Transactions.Add(new Transaction
                {
                    CustomerUserId = 2501,
                    TvChannelId = 1321,
                    AdSizeInPaper = 10,
                    AdDurationInPaper = 20
                });
                context.SaveChanges();

                context.TvChannels.Add(new TvChannel
                {
                    CustomerUserId = 2501,
                    TvChannelId = 1321
                });
                context.SaveChanges();
                List<Transaction> transactions = new List<Transaction>();
                Transaction transaction = new Transaction
                {
                    CustomerUserId = 2501,
                    Cost = 200
                };
                transactions.Add(transaction);
                context.SaveChanges();
                List<TransactionDTO> transactionDTO1 = new List<TransactionDTO>();
                TransactionDTO transactionDTO = new TransactionDTO
                {
                    TvChannelId = 1321,
                    NewsPaperId = 150,
                    TransactionId = 1101,
                    customerUserId = 2501,
                    Cost = 1400,
                    UserName = "okay7",
                    IsApproved = 1
                };
                context.SaveChanges();
                transactionDTO1.Add(transactionDTO);
                TransactionRepository transactionRepository = new TransactionRepository(context);
                List<TransactionDTO> list = await transactionRepository.GetTransaction("rr@gmail.com");
                Assert.AreEqual(1, list.Count);

            }
        }
            
        [TestMethod]
        public async Task TestGetEmailTvChannel_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

                   
            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 8954, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.SaveChanges();
                context.TvChannels.Add(new TvChannel { TvChannelId = 56231, CustomerUserId = 8954, Cost = 139, Genre = "Music" });
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                string email = await tvChannelRepository.GetEmailTvChannel(56231);

                Assert.AreEqual(email, "deccanherald@gmail.com");
            }
        }

               
        [TestMethod]
        public async Task ApproveNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;
            using (var context = new Add_AdContext(options))
            {
                //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                //context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                context.Transactions.Add(new Entity.Transaction { TransactionId = 1315, NewsPaperId = 1101, CustomerUserId = 1521 });
                TransactionDTO newspaperTransactionDTO = new TransactionDTO()
                {
                    TransactionId = 1315,
                    IsApproved = 1

                };
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                int? newspaper = await newspaperRepository.ApproveNewspaper(newspaperTransactionDTO);
                Assert.AreEqual(1315, newspaper);
            }
        }

        [TestMethod]
        public async Task TestGetEmailNewspaper_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 9987, UserName = "thanush", EmailId = "deccanherald@gmail.com" });
                context.SaveChanges();
                context.Newspapers.Add(new Newspaper { NewsPaperId = 95847, CustomerUserId = 9987, Cost = 139});
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                string email = await newspaperRepository.GetEmailNewspaper(95847);

                Assert.AreEqual(email, "deccanherald@gmail.com");
            }
        }
            
        [TestMethod]
        public async Task ApproveNewspaper_bad()
        {
            
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                    //context.Transactions.Add(new Entity.Transaction { TransactionId = 123, NewsPaperId = 1101, CustomerUserId = 1521 });
                    TransactionDTO newspaperTransactionDTO = new TransactionDTO()
                    {
                        TransactionId = 123,
                        IsApproved = 1
                    };
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    int? newspaper = await newspaperRepository.ApproveNewspaper(newspaperTransactionDTO);
                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }



        [TestMethod]
        public async Task TestRegisterChannel_Happy()
        {

        var options = new DbContextOptionsBuilder<Add_AdContext>()
        .UseInMemoryDatabase(databaseName: "Orchard1")
        .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannel tvChannel = new TvChannel { TvChannelId = 189, CustomerUserId = 1975, Genre = "Sports", Language = "English", Cost = 200, IsApproved = true, IsBlocked = false, Rating = 3 };
                 
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                int value = await tvChannelRepository.RegisterChanel(tvChannel);
                Assert.AreEqual(1, value);
            }

        }

        [TestMethod]
        public void TestRegisterChanel_Bad()
        {

            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannel tvChannel = new TvChannel { TvChannelId = 189, CustomerUserId = 1975, Genre = "Sports", Language = "English", Cost = 200, IsApproved = true, IsBlocked = false, Rating = 3 };

                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                Assert.ThrowsExceptionAsync<TvChannelInsertionException>(async () => await tvChannelRepository.RegisterChanel(tvChannel));
            }

        }

        [TestMethod]
        public async Task TestUpdateChannelPrice_Happy()
        {

            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1791, UserName = "Diptesh", EmailId = "diptesh@gmail.com" });
                context.TvChannels.Add(new TvChannel { TvChannelId = 1879, CustomerUserId = 1791, Genre = "Sports", Language = "English", Cost = 2000, IsApproved = true, IsBlocked = false, Rating = 3 });
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO = new TvChannelPriceUpdateDTO { Cost = 2000, Email = "diptesh@gmail.com" };

                int value = await tvChannelRepository.UpdateChannelPrice(tvChannelPriceUpdateDTO);
                Assert.AreEqual(1, value);
            }

        }




        [TestMethod]
        public void TestUpdateChannelPrice_Bad()
        {

            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1997, UserName = "Diptesh", EmailId = "diptesh@gmail.com" });
                context.TvChannels.Add(new TvChannel { TvChannelId = 199, CustomerUserId = 1997, Genre = "Sports", Language = "English", Cost = 2000, IsApproved = true, IsBlocked = false, Rating = 3 });
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await tvChannelRepository.UpdateChannelPrice(null));


            }

        }


        [TestMethod]
        public async Task TestTransactionStatusConfirmation_Happy()
        {

            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.Transactions.Add( new Entity.Transaction
                {
                    TransactionId = 369,
                    Cost = 12,
                    IsApproved = 0,
                    AdSizeInPaper = 12,
                    CustomerUserId = 189,
                    TvChannelId = 259,
                    NewsPaperId = 0
                });
                await context.SaveChangesAsync();
                Transaction transaction = new Transaction
                {
                    TransactionId = 369,
                    Cost = 12,
                    IsApproved = 1,
                    AdSizeInPaper = 12,
                    CustomerUserId = 189,
                    TvChannelId = 259,
                    NewsPaperId = 0
                };
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                int? value = await tvChannelRepository.TransactionStatusConfirmation(transaction);
                Assert.AreEqual(369, value);



            }
              
        }

        [TestMethod]
        public async Task TestBlockNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;



            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 188504, UserName = "thanush", EmailId = "deccanherald2@gmail.com" });
                context.Newspapers.Add(new Newspaper { NewsPaperId = 2236, CustomerUserId = 188504, Cost = 141, IsApproved = false, IsBlocked = false });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var rowCount = await newspaperRepository.UpdateNewspaper(2236);
                Assert.AreEqual(true, rowCount);
            }
        }
        [TestMethod]
        public async Task TestApproveTvChannel_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 1757, Cost = 5000, CustomerUserId = 193, IsApproved = false, IsBlocked = false, Genre = "Kids" });
                await context.SaveChangesAsync();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                bool value =await tvChannelRepository.ApproveTvChannel(1757);
                Assert.AreEqual(true, value);


            }



        }

        [TestMethod]
        public void TestApproveTvChannel_Sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 1759, Cost = 5000, CustomerUserId = 194, IsApproved = false, IsBlocked = false, Genre = "Kids" });
                context.SaveChangesAsync();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelRepository.ApproveTvChannel(0));


            }



        }


        [TestMethod]
        public async Task TestUnblockTvChannel_Happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 1767, Cost = 5000, CustomerUserId = 193, IsApproved = false, IsBlocked = true, Genre = "Kids" });
                await context.SaveChangesAsync();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                bool value = await tvChannelRepository.UnblockTvChannel(1767);
                Assert.AreEqual(true, value);


            }



        }

        [TestMethod]
        public void TestUnblockTvChannel_Sad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
            .UseInMemoryDatabase(databaseName: "Orchard1")
            .Options;

            using (var context = new Add_AdContext(options))
            {
                context.TvChannels.Add(new TvChannel { TvChannelId = 2059, Cost = 5000, CustomerUserId = 194, IsApproved = false, IsBlocked = false, Genre = "Kids" });
                context.SaveChangesAsync();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelRepository.UnblockTvChannel(0));


            }



        }




           

        [TestMethod]
        public async Task TestApproveNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 184504, UserName = "thanush", EmailId = "deccanherald2@gmail.com" });
                context.Newspapers.Add(new Newspaper { NewsPaperId = 22361, CustomerUserId = 184504, Cost = 141, IsApproved = false, IsBlocked = false });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var rowCount = await newspaperRepository.ApproveNewspaper(22361);
                Assert.AreEqual(true, rowCount);
            }
        }

        [TestMethod]
        public async Task TestRejectNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 128504, UserName = "thanush", EmailId = "deccanherald2@gmail.com" });
                context.Newspapers.Add(new Newspaper { NewsPaperId = 22236, CustomerUserId = 128504, Cost = 141, IsApproved = false, IsBlocked = false });
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                var rowCount = await newspaperRepository.RejectNewspaper(22236);
                Assert.AreEqual(true, rowCount);
            }
        }


        //Block
        [TestMethod]
        public async Task BlockNewspaper_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                //context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                context.Transactions.Add(new Entity.Transaction { TransactionId = 116, NewsPaperId = 1101, CustomerUserId = 1521 });
                TransactionDTO newspaperTransactionDTO = new TransactionDTO()
                {
                    TransactionId = 116,
                    IsApproved = 1

                };
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                int? newspaper = await newspaperRepository.BlockNewspaper(newspaperTransactionDTO);
                Assert.AreEqual(116, newspaper);
            }
        }
        [TestMethod]
        public async Task BlockNewspaper_bad()
        {

            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 1521, UserName = "thanush", EmailId = "deccanherald7@gmail.com" });
                    //context.Newspapers.Add(new Newspaper { CustomerUserId = 1521, NewsPaperId = 1101 });
                    //context.Transactions.Add(new Entity.Transaction { TransactionId = 123, NewsPaperId = 1101, CustomerUserId = 1521 });
                    TransactionDTO newspaperTransactionDTO = new TransactionDTO()
                    {
                        TransactionId = 117,
                        IsApproved = 1

                    };
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    int? newspaper = await newspaperRepository.BlockNewspaper(newspaperTransactionDTO);
                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }
        [TestMethod]
        public async Task SearchNewspaperPart1_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { RoleId=2,CustomerUserId = 1530, UserName = "thanush", EmailId = "deccanherald9@gmail.com" });
                context.Newspapers.Add(new Newspaper{ CustomerUserId = 1530, IsBlocked =false, IsApproved = true,Cost=30});
                //context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                List<SearchNewspaperDTO> searchNewspaperDTOs = new List<SearchNewspaperDTO>();
                SearchNewspaperDTO searchNewspaperDTO = new SearchNewspaperDTO
                {
                    Cost = 1400,
                    UserName = "okay7"
                };
                searchNewspaperDTOs.Add(searchNewspaperDTO);
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                Object newspaper = await newspaperRepository.SearchNewspaper("thanush");
                Assert.IsNotNull( newspaper);
            }
        }
        [TestMethod]
        public async Task SearchNewspaperPart2_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { RoleId = 3, CustomerUserId = 1531, UserName = "thanush", EmailId = "deccanherald9@gmail.com" });
                context.TvChannels.Add(new TvChannel{ CustomerUserId = 1531, IsBlocked = false, IsApproved = true, Cost = 30 });
                //context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                List<SearchNewspaperDTO> searchNewspaperDTOs = new List<SearchNewspaperDTO>();
                SearchNewspaperDTO searchNewspaperDTO = new SearchNewspaperDTO
                {
                    Cost = 1400,
                    UserName = "okay7"
                };
                searchNewspaperDTOs.Add(searchNewspaperDTO);
                context.SaveChanges();
                NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                Object newspaper = await newspaperRepository.SearchNewspaper("thanush");
                Assert.IsNotNull(newspaper);
            }
        }
        [TestMethod]
        public async Task SearchNewspaper_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    //context.CustomerUsers.Add(new CustomerUser { RoleId = 3, CustomerUserId = 1531, UserName = "thanush", EmailId = "deccanherald9@gmail.com" });
                    //context.TvChannels.Add(new TvChannel { CustomerUserId = 1531, IsBlocked = false, IsApproved = true, Cost = 30 });
                    //context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                    List<SearchNewspaperDTO> searchNewspaperDTOs = new List<SearchNewspaperDTO>();
                    SearchNewspaperDTO searchNewspaperDTO = new SearchNewspaperDTO
                    {
                        Cost = 1400,
                        UserName = "okay7"
                    };
                    searchNewspaperDTOs.Add(searchNewspaperDTO);
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    Object newspaper = await newspaperRepository.SearchNewspaper("thanush");

                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }
        [TestMethod]
        public async Task SearchNewspaperPart2_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                   .UseInMemoryDatabase(databaseName: "Orchard1")
                   .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    context.CustomerUsers.Add(new CustomerUser { RoleId = 3, CustomerUserId = 1533, UserName = "thanush", EmailId = "deccanherald9@gmail.com" });
                    context.TvChannels.Add(new TvChannel { CustomerUserId = 151, IsBlocked = false, IsApproved = true, Cost = 30 });
                    //context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                    List<SearchNewspaperDTO> searchNewspaperDTOs = new List<SearchNewspaperDTO>();
                    SearchNewspaperDTO searchNewspaperDTO = new SearchNewspaperDTO
                    {
                        Cost = 1400,
                        UserName = "okay7"
                    };
                    searchNewspaperDTOs.Add(searchNewspaperDTO);
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    Object newspaper = await newspaperRepository.SearchNewspaper("thanush");


                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }
        [TestMethod]
        public async Task SearchNewspaperPart1_bad()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                   .UseInMemoryDatabase(databaseName: "Orchard1")
                   .Options;

            using (var context = new Add_AdContext(options))
            {
                Exception expectedException = null;
                try
                {
                    context.CustomerUsers.Add(new CustomerUser { RoleId = 2, CustomerUserId = 1534, UserName = "thanush", EmailId = "deccanherald9@gmail.com" });
                    context.Newspapers.Add(new Newspaper{ CustomerUserId = 152, IsBlocked = false, IsApproved = true, Cost = 30 });
                    //context.Transactions.Add(new Entity.Transaction { TvChannelId = 1100, CustomerUserId = 1520 });
                    List<SearchNewspaperDTO> searchNewspaperDTOs = new List<SearchNewspaperDTO>();
                    SearchNewspaperDTO searchNewspaperDTO = new SearchNewspaperDTO
                    {
                        Cost = 1400,
                        UserName = "okay7"
                    };
                    searchNewspaperDTOs.Add(searchNewspaperDTO);
                    context.SaveChanges();
                    NewspaperRepository newspaperRepository = new NewspaperRepository(context);
                    Object newspaper = await newspaperRepository.SearchNewspaper("thanush");


                }

                catch (Exception ex)
                {
                    expectedException = ex;
                }
                Assert.AreEqual(expectedException, expectedException);
            }
        }


        //TvChannels

        [TestMethod]
        public async Task TestBlockTvChannel_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                context.CustomerUsers.Add(new CustomerUser { CustomerUserId = 3652, UserName = "thanush", EmailId = "deccanherald2@gmail.com" });
                context.TvChannels.Add(new TvChannel { TvChannelId = 1254, CustomerUserId = 3652, Genre = "Music", Cost = 141, IsApproved = false, IsBlocked = false }); ;
                context.SaveChanges();
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                var rowCount = await tvChannelRepository.UpdateTvChannel(1254);
                Assert.AreEqual(true, rowCount);
            }
        }

        [TestMethod]
        public async Task TestApproveTvChannel_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                var rowCount = await tvChannelRepository.ApproveTvChannel(1254);
                Assert.AreEqual(true, rowCount);
            }
        }

        [TestMethod]
        public async Task TestRejectTvChannel_happy()
        {
            var options = new DbContextOptionsBuilder<Add_AdContext>()
                .UseInMemoryDatabase(databaseName: "Orchard1")
                .Options;

            using (var context = new Add_AdContext(options))
            {
                TvChannelRepository tvChannelRepository = new TvChannelRepository(context);
                var rowCount = await tvChannelRepository.RejectTvChannel(1254);
                Assert.AreEqual(false, rowCount);
            }
        }

    }
}