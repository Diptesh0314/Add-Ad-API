﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using Add_Ad.Entity;
using Add_Ad.Repositories;
using Add_Ad.Services;
using System.Threading.Tasks;
using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Repositories.DbOperations;

namespace Add_Ad.Testing.Add_Ad.ServiceLayer.Testing
{
    [TestClass]
    public class Add_Ad
    {
        //Test Method for Top Newspapers Happy Flow
        [TestMethod]
        public async Task TestTopNewspapers() {

            var topNewspapers = new List<TopNewspaper>{
                new TopNewspaper() { UserName = "TOI",Rating=5,Language="Hindi"},
                new TopNewspaper() { UserName="Hindustan Times",Rating=1,Language="English"},
                new TopNewspaper() { UserName="Bussiness Standard",Rating=2,Language="English"},
                new TopNewspaper() { UserName="Amar Ujala" ,Rating=4,Language="Hindi"}
            };

            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.ShowTopNewspapers()).ReturnsAsync(topNewspapers);
           // mock.Setup(foo => foo.ShowTopNewspapers()).Throws<Exception>();
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);

            var value = await newspaperServices.ShowTopNewspapers();

            Assert.AreEqual(topNewspapers.Count, value.Count);
           // mock.Verify(foo=>foo.ShowTopNewspapers());
        }

        [TestMethod]
        public async Task TestTopTvChannels()
        {

            var topTvChannels = new List<TopTvChannel>{
                new TopTvChannel() { UserName = "Colors",Rating=5,Language="Hindi",Genre="Entertainment"},
                new TopTvChannel() { UserName=  "Ten Sports",Rating=1,Language="English",Genre="Sports"},
                new TopTvChannel() { UserName="Star Sports",Rating=2,Language="English",Genre="Sports"},
                new TopTvChannel() { UserName="History" ,Rating=4,Language="Hindi",Genre="Education"}
            };

            var mock = new Mock<ITvChannelRepository>();

            mock.Setup(p => p.ShowTopTvChannels()).ReturnsAsync(topTvChannels);

            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);

            var value = await tvChannelServices.ShowTopTvChannels();

            Assert.AreEqual(topTvChannels.Count, value.Count);
        }
        [TestMethod]
        public async Task TestRegisterUser()
        {
            CustomerUserDTO customerUserDTO = new CustomerUserDTO();
            customerUserDTO.UserName = "Dipteshhh";
            customerUserDTO.EmailId = "xffxf@gmial.com";
            customerUserDTO.RoleId = 1;
            customerUserDTO.PassWord = "Hello5!kjdj";
            var mock = new Mock<ICustomerUserRepository>();
            mock.Setup(p => p.RegisterUser(customerUserDTO)).ReturnsAsync(32);
            CustomerUserServices customerUserServices = new CustomerUserServices(mock.Object);
            var value = await customerUserServices.RegisterUser(customerUserDTO);
            Assert.AreEqual(32, value);
            
        }
        [TestMethod]
        public async Task TestCheckEmailIfExist()
        {
            ForgotPasswordDto forgotPasswordDto = new ForgotPasswordDto();
            forgotPasswordDto.Email = "Thanush123@gmail.com";
            var mock = new Mock<ICustomerUserRepository>();
            mock.Setup(p => p.CheckEmailIfExist(forgotPasswordDto)).ReturnsAsync(1);
            CustomerUserServices customerUserServices = new CustomerUserServices(mock.Object);
            var value = await customerUserServices.CheckEmailIfExist(forgotPasswordDto);
            Assert.AreEqual(1, value);
        }
        [TestMethod]
        public async Task TestAuthenticateUser()
        {
            CustomerUserDTO customerUserDTO = new CustomerUserDTO();
            customerUserDTO.UserName = "HellloThere";
            customerUserDTO.EmailId = "Hellothere123@gmail.com";
            customerUserDTO.RoleId = 1;
            customerUserDTO.PassWord = "Diptesh#107";
            CustomerUserTokenDTO customerUserTokenDTO = new CustomerUserTokenDTO();
            customerUserTokenDTO.EmailId = "Hellothere123@gmail.com";
            customerUserTokenDTO.Token = "00395be6f03a33025649b60b0ac6901e8ade2d0af950199ebf2a171bafbd30d72d2c2f50008a4a471bad7c37ed79b6043bf71eb794b9954a9ee994058c1126bf";
            var mock = new Mock<ICustomerUserRepository>();
            mock.Setup(p => p.AuthenticateUser(customerUserDTO)).ReturnsAsync(customerUserTokenDTO);
            CustomerUserServices customerUserServices = new CustomerUserServices(mock.Object);
            var value = await customerUserServices.AuthenticateUser(customerUserDTO);
            Assert.AreEqual("00395be6f03a33025649b60b0ac6901e8ade2d0af950199ebf2a171bafbd30d72d2c2f50008a4a471bad7c37ed79b6043bf71eb794b9954a9ee994058c1126bf", value.Token);
        }
        [TestMethod]
        public async Task TestUpdateUser()
        {
            CustomerUserDTO customerUserDTO = new CustomerUserDTO();    
            customerUserDTO.UserName = "DipteshhhDas";
            customerUserDTO.EmailId = "abcd@gmial.com";
            customerUserDTO.RoleId = 1;
            customerUserDTO.PassWord = "Hello5!kjdj";
            var mock = new Mock<ICustomerUserRepository>();
            mock.Setup(p => p.UpdateUser(customerUserDTO)).ReturnsAsync(65);
            CustomerUserServices customerUserServices = new CustomerUserServices(mock.Object);
            var value = await customerUserServices.UpdateUser(customerUserDTO);
            Assert.AreEqual(65, value);
        }

        


        [TestMethod]
        public async Task TestUpdatePassword()
        {
            CustomerUserDTO customerUserDTO = new CustomerUserDTO();
            customerUserDTO.UserName = "CheckUpdatePassword";
            customerUserDTO.EmailId = "mnop@gmial.com";
            customerUserDTO.RoleId = 1;
            customerUserDTO.PassWord = "Hello5!kjdj";
            var mock = new Mock<ICustomerUserRepository>();
            mock.Setup(p => p.UpdatePassword(customerUserDTO)).ReturnsAsync(92);
            CustomerUserServices customerUserServices = new CustomerUserServices(mock.Object);
            var value = await customerUserServices.UpdatePassword(customerUserDTO);
            Assert.AreEqual(92, value);
        }
        [TestMethod]
        public async Task TestRegisterNewspaper()
        {
            Newspaper newspaper = new Newspaper();
            newspaper.CustomerUserId = 96;
            newspaper.Cost = 0;
            newspaper.Language = "Enlish";
            newspaper.Rating = 1200;
            newspaper.IsApproved = false;
            newspaper.IsBlocked = false;
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.RegisterNewspaper(newspaper)).ReturnsAsync(1);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value =await newspaperServices.RegisterNewspaper(newspaper);
            Assert.AreEqual(1, value);
            
        }
        [TestMethod]
        public void TestRegisterNewspaper_sad()
        {
            Newspaper newspaper = null;
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.RegisterNewspaper(newspaper)).Throws(new ArgumentNullException());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<NullReferenceException>(async () => await newspaperServices.RegisterNewspaper(newspaper));
            

        }
        [TestMethod]
        public async Task TestRegisterChanel()
        {
            TvChannel tvChannel = new TvChannel();
            tvChannel.Cost = 0;
            tvChannel.CustomerUserId = 94;
            tvChannel.Genre = "Kids";
            tvChannel.IsApproved = false;
            tvChannel.IsBlocked = false;
            tvChannel.Language = "English";
            tvChannel.Rating = 3;
            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.RegisterChanel(tvChannel)).ReturnsAsync(1);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = await tvChannelServices.RegisterChanel(tvChannel);
            Assert.AreEqual(1, value);

        }
        [TestMethod]
        public async Task TestGetAllChannels_sad()
        {
            var allChannels = new List<TvChannel>{
                new TvChannel() { Genre = "Kids",Rating=5,Language="Hindi",IsApproved=false,IsBlocked=true},
                new TvChannel() {Genre = "Music",Rating=3,Language= "English",IsApproved=false,IsBlocked=true},
            };
            var mock = new Mock<ITvChannelRepository>();


            mock.Setup(p => p.GetAllChannels()).ReturnsAsync(allChannels);

            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);

            var value = (List<TvChannel>)await tvChannelServices.GetAllChannels();

            Assert.AreNotEqual(1, value.Count);


        }
        [TestMethod]
        public async Task TestGetAllChannels()
        {
            var allChannels = new List<TvChannel>{
                new TvChannel() { Genre = "Kids",Rating=5,Language="Hindi"},
                new TvChannel() {Genre = "Music",Rating=3,Language="English"},
            };
            var mock = new Mock<ITvChannelRepository>();


            mock.Setup(p => p.GetAllChannels()).ReturnsAsync(allChannels);
            
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);

            var value = (List<TvChannel>)await tvChannelServices.GetAllChannels();

            Assert.AreEqual(allChannels.Count, value.Count);
           

        }
        
       
        //[TestMethod]
        //public async Task TestSearchRating()
        //{
        //    var searchedChannels = new List<SearchChannelDTO>{
        //        new SearchChannelDTO() { UserName = "Hungama",Cost=1500,Language="Hindi",Rating=5,TvChannelId=103,Genre="Kids"}
        //    };
        //    var mock = new Mock<ITvChannelRepository>();
        //    mock.Setup(p => p.SearchRating(5)).ReturnsAsync(searchedChannels);
        //    TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
        //    var value = (List<SearchChannelDTO>)await tvChannelServices.SearchRating(5);
        //    Assert.AreEqual(searchedChannels.Count, value.Count);
        //}
        [TestMethod]
        public async Task TestSearchGenre()
        {
            var searchedChannels = new List<SearchChannelDTO>{
                new SearchChannelDTO() { UserName = "Hungama",Cost=1500,Language="Hindi",Rating=5,TvChannelId=103,Genre="Kids"}
            };
            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.SearchGenre("Kids")).ReturnsAsync(searchedChannels);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = (List<SearchChannelDTO>)await tvChannelServices.SearchGenre("Kids");
            Assert.AreNotEqual(2, value.Count);
        }
        [TestMethod]
        public async Task TestGetAllNewsPapers_sad()
        {
            var searchedNewspaper = new List<Newspaper>{
                new Newspaper { CustomerUserId =110 ,Language="English",Cost=0,Rating=1200,IsApproved=false}
            };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.GetAllNewsPapers()).ReturnsAsync(searchedNewspaper);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (List<Newspaper>)await newspaperServices.GetAllNewsPapers();
            Assert.AreEqual(searchedNewspaper.Count, value.Count);
        }

        [TestMethod]
        public async Task TestGetAllNewsPapers()
        {
            var searchedNewspaper = new List<Newspaper>{
                new Newspaper { CustomerUserId =110 ,Language="English",Cost=0,Rating=1200}
            };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.GetAllNewsPapers()).ReturnsAsync(searchedNewspaper);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (List<Newspaper>)await newspaperServices.GetAllNewsPapers();
            Assert.AreEqual(searchedNewspaper.Count, value.Count);
        }
        //[TestMethod]
        //public async Task TestSearchNewspaper_sad()
        //{
        //    var searchedNewspaper = new List<SearchNewspaperDTO>{
        //        new SearchNewspaperDTO() { UserName = "TOI",Cost=1500,Language="Hindi",Rating=5,NewsPaperId=103}
        //    };
        //    var mock = new Mock<INewspaperRepository>();
        //    mock.Setup(p => p.SearchNewspaper("TOI")).ReturnsAsync(searchedNewspaper);
        //    NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
        //    var value = (List<SearchNewspaperDTO>)await newspaperServices.SearchNewspaper("TOI");
        //    Assert.AreNotEqual(searchedNewspaper.Count, value.Count);
        //}
        [TestMethod]
        public async Task TestSearchNewspaper()
        {
            var searchedNewspaper = new List<SearchNewspaperDTO>{
                new SearchNewspaperDTO() { UserName = "TOI",Cost=1500,Language="Hindi",Rating=5,NewsPaperId=103}
            };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.SearchNewspaper("TOI")).ReturnsAsync(searchedNewspaper);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (List<SearchNewspaperDTO>)await newspaperServices.SearchNewspaper("TOI");
            Assert.AreEqual(searchedNewspaper.Count, value.Count);
        }
        //[TestMethod]
        //public async Task TestSearchRatingNewspaper_sad()
        //{
        //    var searchedNewspaper = new List<SearchNewspaperDTO>{
        //        new SearchNewspaperDTO() { UserName = "TOI",Cost=1500,Language="Hindi",Rating=5,NewsPaperId=103}
        //    };
        //    var mock = new Mock<INewspaperRepository>();
        //    mock.Setup(p => p.SearchRating(5)).ReturnsAsync(searchedNewspaper);
        //    NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
        //    var value = (List<SearchNewspaperDTO>)await newspaperServices.SearchRating(5);
        //    Assert.AreEqual(searchedNewspaper.Count, value.Count);
        //}Methods
        [TestMethod]
        public async Task TestSearchRatingNewspaper()
        {
            var searchedNewspaper = new List<SearchNewspaperDTO>{
                new SearchNewspaperDTO() { UserName = "TOI",Cost=1500,Language="Hindi",Rating=5,NewsPaperId=103}
            };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.SearchRating(5)).ReturnsAsync(searchedNewspaper);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (List<SearchNewspaperDTO>)await newspaperServices.SearchRating(5);
            Assert.AreEqual(searchedNewspaper.Count, value.Count);
        }
        [TestMethod]
        public async Task TestAddRoles()
        {
            Role role = new Role();
            role.RoleId = 5;
            role.RoleType = "abc";
            var mock = new Mock<IRoleRepository>();
            mock.Setup(p => p.AddRoles(role)).ReturnsAsync(1);
            RoleServices roleServices = new RoleServices(mock.Object);
            var value = await roleServices.AddRoles(role);
            Assert.AreEqual(1, value);

        }
        [TestMethod]
        public void TestAllRoles_sad()
        {
            Role role = null;
            var mock = new Mock<IRoleRepository>();
            mock.Setup(p => p.AddRoles(role)).Throws(new ArgumentNullException());
            RoleServices roleServices = new RoleServices(mock.Object);

            Assert.ThrowsExceptionAsync<NullReferenceException>(async () => await roleServices.AddRoles(role));


        }
        [TestMethod]
        public void TestAllNewspaper_bad()
        {
            
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.GetAllNewsPapers()).Throws(new NoNewspaperFound());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);

            Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperServices.GetAllNewsPapers());


        }
        [TestMethod]
        public void TestSearchNewspaper_bad()
        {

            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.SearchNewspaper("Dainik Jaagran")).Throws(new NoNewspaperFound());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object); 
            Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperServices.SearchNewspaper("Dainik Jaagran"));


        }
        [TestMethod]
        public void TestSearchNewspaperRating_bad()
        {

            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.SearchRating(15)).Throws(new NoNewspaperFound());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<NoNewspaperFound>(async () => await newspaperServices.SearchRating(15));


        }
        [TestMethod]
        public void TestGetAllChannel_bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.GetAllChannels()).Throws(new NoTvChannelFound());
            TvChannelServices channelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelServices.GetAllChannels());


        }

        //[TestMethod]
        //public void TestSearchChannel_bad()
        //{

        //    var mock = new Mock<ITvChannelRepository>();
        //    mock.Setup(p => p.SearchChannel("Demo")).Throws(new NoTvChannelFound());
        //    TvChannelServices channelServices = new TvChannelServices(mock.Object);
        //    Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelServices.SearchChannel("Demo"));


        ////}
        [TestMethod]
        public void TestRatingChannel_bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.SearchRating(67)).Throws(new NoTvChannelFound());
            TvChannelServices channelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelServices.SearchRating(67));


        }
        [TestMethod]
        public void TestGenreChannel_bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.SearchGenre("Demo")).Throws(new NoTvChannelFound());
            TvChannelServices channelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<NoTvChannelFound>(async () => await channelServices.SearchGenre("Demo"));


        }

        [TestMethod]
        public async Task TestGetByEmail_Happy()
        {
            
            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.GetByEmail("diptesh308@outlook.com")).ReturnsAsync(tvChannel);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            TvChannel value =await tvChannelServices.GetByEmail("diptesh308@outlook.com");
            Assert.AreEqual(tvChannel.TvChannelId, value.TvChannelId);

        }
        [TestMethod]
        public async Task TestGetByEmail_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.GetByEmail("diptesh308@outlook.com")).ReturnsAsync(tvChannel);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            TvChannel value = await tvChannelServices.GetByEmail("diptesh308@outlook.com");
            Assert.AreNotEqual(109, value.TvChannelId);

        }
        [TestMethod]
        public void TestGetByEmail_Bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            mock.Setup(p => p.GetByEmail(null)).Throws(new Exception());
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelServices.GetByEmail(null));

        }

        [TestMethod]
        public async Task TestGetEmailTvChannel_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, 
             Genre = "News", IsApproved = false, 
             IsBlocked = false, Language = "English", TvChannelId = 5 };
            CustomerUser customerUser = new CustomerUser { CustomerUserId = 107, EmailId = "diptesh308@gmail.com" };
            mock.Setup(p => p.GetEmailTvChannel(5)).ReturnsAsync("diptesh308@gmail.com");
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            string value = await tvChannelServices.GetEmailTvChannel(5);
            Assert.AreEqual("diptesh308@gmail.com", value);

        }

        [TestMethod]
        public async Task TestGetEmailTvChannel_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();

            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            CustomerUser customerUser = new CustomerUser { CustomerUserId = 107, EmailId = "diptesh308@gmail.com" };
            mock.Setup(p => p.GetEmailTvChannel(5)).ReturnsAsync("diptesh308@gmail.com");
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            string value = await tvChannelServices.GetEmailTvChannel(4);
            Assert.AreNotEqual("diptesh308@gmail.com", value);

        }

        [TestMethod]
        public void TestGetEmailTvChannel_Bad()
        {

            var mock = new Mock<ITvChannelRepository>();

            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            CustomerUser customerUser = new CustomerUser { CustomerUserId = 107, EmailId = "diptesh308@gmail.com" };
            mock.Setup(p => p.GetEmailTvChannel(0)).Throws(new Exception());
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelServices.GetEmailTvChannel(0));
            

        }



        [TestMethod]
        public async Task TestUpdateChannelPrice_Happy()
        {
            var mock = new Mock<ITvChannelRepository>();            
            TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO = new TvChannelPriceUpdateDTO { Email = "diptesh308@outlook.com", Cost = 1600 };
            
            mock.Setup(p => p.UpdateChannelPrice(tvChannelPriceUpdateDTO)).ReturnsAsync(1);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            int value = await tvChannelServices.UpdateChannelPrice(tvChannelPriceUpdateDTO);
            Assert.AreEqual(1, value);

        }
        [TestMethod]
        public async Task TestUpdateChannelPrice_Sad()
        {
            var mock = new Mock<ITvChannelRepository>();
            TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO = new TvChannelPriceUpdateDTO { Email = "diptesh308@outlook.com", Cost = 1600 };

            mock.Setup(p => p.UpdateChannelPrice(tvChannelPriceUpdateDTO)).ReturnsAsync(1);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            int value = await tvChannelServices.UpdateChannelPrice(tvChannelPriceUpdateDTO);
            Assert.AreNotEqual(5, value);

        }

        [TestMethod]
        public void TestUpdateChannelPrice_bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO = null;
            mock.Setup(p => p.UpdateChannelPrice(tvChannelPriceUpdateDTO)).Throws(new TvChannelInsertionException());
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<TvChannelInsertionException>(async () => await tvChannelServices.UpdateChannelPrice(tvChannelPriceUpdateDTO));

        }

        [TestMethod]
        public async Task TestGetEmailById_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            CustomerUser customerUser = new CustomerUser { CustomerUserId = 107, EmailId = "diptesh308@gmail.com" };
            mock.Setup(p => p.GetEmailById(107)).ReturnsAsync("diptesh308@gmail.com");
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            string value = await tvChannelServices.GetEmailById(107);
            Assert.AreEqual("diptesh308@gmail.com", value);

        }

        [TestMethod]
        public async Task TestGetEmailById_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            CustomerUser customerUser = new CustomerUser { CustomerUserId = 107, EmailId = "diptesh308@gmail.com" };
            mock.Setup(p => p.GetEmailById(107)).ReturnsAsync("diptesh308@gmail.com");
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            string value = await tvChannelServices.GetEmailById(106);
            Assert.AreNotEqual("diptesh308@gmail.com", value);

        }

        [TestMethod]
        public async Task TestRejectTvChannel_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.RejectTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.RejectTvChannel(5);
            Assert.AreEqual(true, value);

        }

        [TestMethod]
        public async Task TestRejectTvChannel_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.RejectTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.RejectTvChannel(4);
            Assert.AreNotEqual(true, value);

        }



        [TestMethod]
        public void TestRejectTvChannel_Bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.RejectTvChannel(0)).Throws(new NoTvChannelFound()); ;
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelServices.RejectTvChannel(0));

        }



        [TestMethod]
        public async Task TestApproveTvChannel_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.ApproveTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.ApproveTvChannel(5);
            Assert.AreEqual(true, value);

        }

        [TestMethod]
        public async Task TestApproveTvChannel_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.ApproveTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.ApproveTvChannel(4);
            Assert.AreNotEqual(true, value);

        }



        [TestMethod]
        public void TestApproveTvChannel_Bad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.ApproveTvChannel(0)).Throws(new NoTvChannelFound()); ;
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await tvChannelServices.ApproveTvChannel(0));

        }

        [TestMethod]
        public async Task TestTransactionStatusConfirmation_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            Transaction transaction = new Transaction { CustomerUserId = 107, TransactionId = 60, AdDurationInPaper = 20, Cost = 50000, IsApproved = 0 };
            mock.Setup(p => p.TransactionStatusConfirmation(transaction)).ReturnsAsync(107);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = await tvChannelServices.TransactionStatusConfirmation(transaction);
            Assert.AreEqual(107, value);

        }

        [TestMethod]
        public async Task TestTransactionStatusConfirmation_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            Transaction transactionval = new Transaction { CustomerUserId = 108, TransactionId = 60, AdDurationInPaper = 20, Cost = 50000, IsApproved = 0 };
            Transaction transaction = new Transaction { CustomerUserId = 107, TransactionId = 60, AdDurationInPaper = 20, Cost = 50000, IsApproved = 0 };
            mock.Setup(p => p.TransactionStatusConfirmation(transaction)).ReturnsAsync(107);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = await tvChannelServices.TransactionStatusConfirmation(transactionval);
            Assert.AreNotEqual(transaction.CustomerUserId, value);

        }

        [TestMethod]
        public async Task TestUnblockTvChannel_Happy()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.UnblockTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.UnblockTvChannel(5);
            Assert.AreEqual(true, value);


        }

        [TestMethod]
        public async Task TestUnblockTvChannel_Sad()
        {

            var mock = new Mock<ITvChannelRepository>();
            TvChannel tvChannel = new TvChannel { CustomerUserId = 107, Rating = 3, Cost = 1600, Genre = "News", IsApproved = false, IsBlocked = false, Language = "English", TvChannelId = 5 };
            mock.Setup(p => p.UnblockTvChannel(5)).ReturnsAsync(true);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            bool value = await tvChannelServices.UnblockTvChannel(4);
            Assert.AreNotEqual(true, value);


        }
 


        [TestMethod]
        public async Task TestUpdateNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper {  CustomerUserId=2,Cost=20,IsBlocked=false,IsApproved=false,NewsPaperId=20,Rating=4,Language="English" };
            mock.Setup(p => p.UpdateNewspaper(20)).ReturnsAsync(true);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            bool value = await newspaperServices.UpdateNewspaper(20);
            Assert.AreEqual(true, value);


        }
        [TestMethod]
        public async Task TestUpdateNewspaper_Sad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.UpdateNewspaper(20)).ReturnsAsync(true);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            bool value = await newspaperServices.UpdateNewspaper(15);
            Assert.AreNotEqual(true, value);


        }

        [TestMethod]
        public void TestUpdateNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.UpdateNewspaper(0)).Throws(new SqlException());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<SqlException>(async () => await newspaperServices.UpdateNewspaper(0));

        }


       
        [TestMethod]
        public async Task TestUnblockNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = true, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.UnblockNewspaper(20)).ReturnsAsync(true);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            bool value = await newspaperServices.UnblockNewspaper(20);
            Assert.AreEqual(true, value);


        }


        [TestMethod]
        public void TestUnblockNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = true, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.UnblockNewspaper(0)).Throws(new SqlException());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<SqlException>(async () => await newspaperServices.UnblockNewspaper(0));

        }




        [TestMethod]
        public async Task TestApproveNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = true, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.ApproveNewspaper(20)).ReturnsAsync(true);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            bool value = await newspaperServices.ApproveNewspaper(20);
            Assert.AreEqual(true, value);


        }


        [TestMethod]
        public void TestApproveNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = true, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.ApproveNewspaper(0)).Throws(new SqlException());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<SqlException>(async () => await newspaperServices.ApproveNewspaper(0));

        }
        [TestMethod]
        public async Task TestRejectNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.RejectNewspaper(20)).ReturnsAsync(true);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            bool value = await newspaperServices.RejectNewspaper(20);
            Assert.AreEqual(true, value);


        }


        [TestMethod]
        public void TestRejectNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            mock.Setup(p => p.RejectNewspaper(0)).Throws(new SqlException());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<SqlException>(async () => await newspaperServices.RejectNewspaper(0));

        }

       
        [TestMethod]
        public async Task TestGetEmailNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetEmailNewspaper(20)).ReturnsAsync("diptesh308@gmail.com");
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            string value =await newspaperServices.GetEmailNewspaper(20);
            Assert.AreEqual("diptesh308@gmail.com", value);
        }

        [TestMethod]
        public void TestGetEmailNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetEmailNewspaper(0)).Throws(new Exception());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await newspaperServices.GetEmailNewspaper(0));
        }


        [TestMethod]
        public async Task TestGetByEmailNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetByEmail("diptesh308@gmail.com")).ReturnsAsync(newspaper);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Newspaper value = await newspaperServices.GetByEmail("diptesh308@gmail.com");
            Assert.AreEqual(20,value.NewsPaperId );
        }

        [TestMethod]
        public void TestGetByEmailNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetByEmail("")).Throws(new Exception());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await newspaperServices.GetByEmail(""));
        }


        [TestMethod]
        public async Task TestGetEmailOfNewspaper_Happy()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetEmailOfNewspaper(2)).ReturnsAsync("diptesh308@gmail.com");
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            string value = await newspaperServices.GetEmailOfNewspaper(2);
            Assert.AreEqual("diptesh308@gmail.com", value);
        }

        [TestMethod]
        public void TestGetEmailOfNewspaper_Bad()
        {

            var mock = new Mock<INewspaperRepository>();
            Newspaper newspaper = new Newspaper { CustomerUserId = 2, Cost = 20, IsBlocked = false, IsApproved = false, NewsPaperId = 20, Rating = 4, Language = "English" };
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 2, UserName = "abc" };
            mock.Setup(p => p.GetEmailOfNewspaper(0)).Throws(new Exception());
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            Assert.ThrowsExceptionAsync<Exception>(async () => await newspaperServices.GetEmailOfNewspaper(0));
        }

        [TestMethod]
        public async Task TestGetActiveNewspapers()
        {
            List<Newspaper> newspapers = new List<Newspaper>() { new Newspaper() { CustomerUserId = 11000, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = false } };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.GetActiveAllNewspapers()).ReturnsAsync(newspapers);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (List<Newspaper>)await newspaperServices.GetActiveAllNewspapers();
            Assert.AreEqual(newspapers.Count, value.Count);
        }

        [TestMethod]
        public async Task TestGetBlockNewspapers()
        {
            List<Newspaper> newspapers = new List<Newspaper>() { new Newspaper() { CustomerUserId = 1200, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = true } };
            var mock = new Mock<INewspaperRepository>();
            List<SearchNewspaperDTO> newspapersList = new List<SearchNewspaperDTO>();
            mock.Setup(p => p.GetBlockedNewspapers()).ReturnsAsync(newspapersList);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = await newspaperServices.GetBlockNewspapers();
            Assert.AreEqual(newspapersList.Count, value.Count);
        }

        [TestMethod]
        public async Task TestGetNotApprovedNewspapers()
        {
            List<Newspaper> newspapers = new List<Newspaper>() { new Newspaper() { CustomerUserId = 1256, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = true } };
            var mock = new Mock<INewspaperRepository>();
            List<SearchNewspaperDTO> newspapersList = new List<SearchNewspaperDTO>();
            mock.Setup(p => p.GetNotApprovedNewspapers()).ReturnsAsync(newspapersList);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = await newspaperServices.GetNotApprovedNewspapers();
            Assert.AreEqual(newspapersList.Count, value.Count);
        }

        [TestMethod]
        public async Task ApproveNewspaper_happy()
        {
            TransactionDTO newspaperTransactionDTO = new TransactionDTO { TransactionId = 121 };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.ApproveNewspaper(newspaperTransactionDTO)).ReturnsAsync(newspaperTransactionDTO.TransactionId);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (int?)await newspaperServices.ApproveNewspaper(newspaperTransactionDTO);
            Assert.AreEqual(newspaperTransactionDTO.TransactionId, value);
        }
        [TestMethod]
        public async Task TestGetNotApporvedTvChannels()
        {
            List<TvChannel> tvChannels1 = new List<TvChannel>() { new TvChannel() { CustomerUserId = 1226, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = true ,Genre="Musics"} };
            var mock = new Mock<ITvChannelRepository>();
            List<SearchChannelDTO> tvChannels = new List<SearchChannelDTO>();
            mock.Setup(p => p.GetNotApprovedTvChannels()).ReturnsAsync(tvChannels);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = await tvChannelServices.GetNotApprovedTvChannels();
            Assert.AreEqual(tvChannels.Count, value.Count);
        }

        [TestMethod]
        public async Task BlockNewspaper_happy()
        {
            TransactionDTO newspaperTransactionDTO = new TransactionDTO { TransactionId = 122 };
            var mock = new Mock<INewspaperRepository>();
            mock.Setup(p => p.BlockNewspaper(newspaperTransactionDTO)).ReturnsAsync(newspaperTransactionDTO.TransactionId);
            NewspaperServices newspaperServices = new NewspaperServices(mock.Object);
            var value = (int?)await newspaperServices.BlockNewspaper(newspaperTransactionDTO);
            Assert.AreEqual(newspaperTransactionDTO.TransactionId, value);
        }
        [TestMethod]
        public async Task TestGetUserId()
        {

            var mock = new Mock<ITransactionRepository>();
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 93, UserName = "abc" };
            mock.Setup(p => p.GetUserId("abc")).ReturnsAsync(93);
            TransactionServices transactionServices = new TransactionServices(mock.Object);
            int? value = await transactionServices.GetUserId("abc");
            Assert.AreEqual(93,value);


        }


        [TestMethod]
        public async Task TestAddTransactionChannel_Happy()
        {

            var mock = new Mock<ITransactionRepository>();
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 93, UserName = "abc",RoleId=3 };
            Transaction transaction = new Transaction { TransactionId = 123, CustomerUserId = 93, NewsPaperId = 0, Cost = 5700, TvChannelId = 19, AdDurationInPaper = 12, IsApproved = 0 };
            TransactionDTO transactionDTO = new TransactionDTO { customerUserId = 93, NewsPaperId = 0, TvChannelId = 19, Cost = 5700, UserName = "abc", AdDurationInPaper = 12 };
            mock.Setup(p => p.AddTransaction(transaction)).ReturnsAsync(transactionDTO);
            TransactionServices transactionServices = new TransactionServices(mock.Object);
            TransactionDTO value = await transactionServices.AddTransaction(transaction);
            Assert.AreEqual(19, value.TvChannelId);


        }

        [TestMethod]
        public async Task TestAddTransactionNewspaper_Happy()
        {

            var mock = new Mock<ITransactionRepository>();
            CustomerUser customerUser = new CustomerUser { EmailId = "diptesh308@gmail.com", CustomerUserId = 103, UserName = "abc", RoleId = 2};
            Transaction transaction = new Transaction { TransactionId = 123, CustomerUserId = 103, NewsPaperId = 7, Cost = 15, TvChannelId = 0, AdSizeInPaper=13, IsApproved = 0 };
            TransactionDTO transactionDTO = new TransactionDTO { customerUserId = 93, NewsPaperId = 7, TvChannelId = 0, Cost = 15, UserName = "abc", AdSizeInPaper = 13 };
            mock.Setup(p => p.AddTransaction(transaction)).ReturnsAsync(transactionDTO);
            TransactionServices transactionServices = new TransactionServices(mock.Object);
            TransactionDTO value = await transactionServices.AddTransaction(transaction);
            Assert.AreEqual(7, value.NewsPaperId);


        }







        [TestMethod]
        public async Task TestGetBlockedTvChannels()
        {
            List<TvChannel> tvChannels1 = new List<TvChannel>() { new TvChannel() { CustomerUserId = 12226, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = true, Genre = "Musics" } };
            var mock = new Mock<ITvChannelRepository>();
            List<SearchChannelDTO> tvChannels = new List<SearchChannelDTO>();
            mock.Setup(p => p.GetBlockedTvChannels()).ReturnsAsync(tvChannels);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            var value = await tvChannelServices.GetBlockedTvChannels();
            Assert.AreEqual(tvChannels.Count, value.Count);
        }

        [TestMethod]
        public async Task TestGetActiveTvChannel() {
            List<TvChannel> tvChannels1 = new List<TvChannel>() { new TvChannel() { CustomerUserId = 1126, Rating = 5, Cost = 1900, Language = "Hindi", IsApproved = true, IsBlocked = true, Genre = "Musics" } };
            var mock = new Mock<ITvChannelRepository>();
            List<SearchChannelDTO> tvChannels = new List<SearchChannelDTO>();
            mock.Setup(p => p.GetActiveTvChannel()).ReturnsAsync(tvChannels);
            TvChannelServices tvChannelServices = new TvChannelServices(mock.Object);
            List<SearchChannelDTO> value = (List<SearchChannelDTO>)await tvChannelServices.GetActiveTvChannel();
            Assert.AreEqual(tvChannels.Count, value.Count);
        }
    }
}
