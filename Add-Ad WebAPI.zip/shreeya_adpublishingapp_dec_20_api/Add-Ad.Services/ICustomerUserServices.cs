﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public interface ICustomerUserServices
    {
        public Task<int?> RegisterUser(CustomerUserDTO userDTO);
        public Task<CustomerUserTokenDTO> AuthenticateUser(CustomerUserDTO userVal);
        public Task<int?> CheckEmailIfExist(ForgotPasswordDto forgotPasswordDto);
        public Task<int?> UpdateUser(CustomerUserDTO userVal);
        public Task<int?> UpdatePassword(CustomerUserDTO userVal);
    }
}
