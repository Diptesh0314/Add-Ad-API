﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Add_Ad.Repositories.Migrations
{
    public partial class updateTransaction : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Newspapers_CustomerUsers_CustomerUserId",
                table: "Newspapers");

            migrationBuilder.DropForeignKey(
                name: "FK_TvChannels_CustomerUsers_CustomerUserId",
                table: "TvChannels");

            migrationBuilder.DropIndex(
                name: "IX_TvChannels_CustomerUserId",
                table: "TvChannels");

            migrationBuilder.DropIndex(
                name: "IX_Newspapers_CustomerUserId",
                table: "Newspapers");

            migrationBuilder.AlterColumn<int>(
                name: "AdSizeInPaper",
                table: "Transactions",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "AdDurationInPaper",
                table: "Transactions",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "NumberOfDays",
                table: "Transactions",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PageNumber",
                table: "Transactions",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NumberOfDays",
                table: "Transactions");

            migrationBuilder.DropColumn(
                name: "PageNumber",
                table: "Transactions");

            migrationBuilder.AlterColumn<int>(
                name: "AdSizeInPaper",
                table: "Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "AdDurationInPaper",
                table: "Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TvChannels_CustomerUserId",
                table: "TvChannels",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Newspapers_CustomerUserId",
                table: "Newspapers",
                column: "CustomerUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Newspapers_CustomerUsers_CustomerUserId",
                table: "Newspapers",
                column: "CustomerUserId",
                principalTable: "CustomerUsers",
                principalColumn: "CustomerUserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TvChannels_CustomerUsers_CustomerUserId",
                table: "TvChannels",
                column: "CustomerUserId",
                principalTable: "CustomerUsers",
                principalColumn: "CustomerUserId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
