﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public interface ITransactionServices
    {
        Task<int?> GetUserId(string name);
        Task<List<TransactionDTO>> GetTransaction(string email);
        Task<TransactionDTO> AddTransaction(Transaction transaction);
        Transaction CalculateCost(Transaction transaction);
    }
}
