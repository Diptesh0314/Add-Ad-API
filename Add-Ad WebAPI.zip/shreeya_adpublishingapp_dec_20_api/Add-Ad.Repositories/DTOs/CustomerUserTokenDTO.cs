﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class CustomerUserTokenDTO
    {
        public string EmailId { get; set; }
        public string Token { get; set; }
    }
}
