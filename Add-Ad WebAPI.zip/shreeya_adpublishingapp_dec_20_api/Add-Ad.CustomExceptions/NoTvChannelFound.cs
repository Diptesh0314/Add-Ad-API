﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.CustomExceptions
{
    public class NoTvChannelFound:Exception
    {
        public NoTvChannelFound()
        {

        }

        public NoTvChannelFound(string msg) : base(msg)
        {
        }
    }
}
