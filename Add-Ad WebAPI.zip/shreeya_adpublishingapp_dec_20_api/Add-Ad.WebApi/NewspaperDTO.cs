﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class NewspaperDTO
    {
    }
}
