﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NewspaperApprovinglAndBlockingController : ControllerBase
    {
        private readonly INewspaperServices _newspaperServices;
        public NewspaperApprovinglAndBlockingController(INewspaperServices newspaperServices)
        {
            _newspaperServices = newspaperServices;
        }
        [HttpPost("Approve")]
        public async Task<IActionResult> ApproveNewspaper(TransactionDTO newspaperTransactionDTO)
        {
            try
            {
                int? transactionId = await _newspaperServices.ApproveNewspaper(newspaperTransactionDTO);
                if (transactionId == 0)
                    return BadRequest("Some error occured");
                return Ok(newspaperTransactionDTO.IsApproved);
            }
            catch (SqlException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("GetPendingNewspapers/{email}")]
        public async Task<ActionResult> GetPendingNewspapers(string email)
        {
            try
            {
                return Ok(await _newspaperServices.GetPendingNewspapers(email));
            }
            catch (NoNewspaperFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("UpdateChannelPrice")]
        public async Task<IActionResult> UpdateChannelPrice(NewspaperPriceUpdateDTO newspaperPriceUpdateDTO)
        {
            try
            {
                int rowsAffected;
                rowsAffected = await _newspaperServices.UpdateNewspapersPrice(newspaperPriceUpdateDTO);
                return Ok(rowsAffected);
            }
            catch (NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (TvChannelInsertionException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("getByEmail/{email}")]
        public async Task<IActionResult> GetByEmail(string email)
        {
            Newspaper newspaper = await _newspaperServices.GetByEmail(email);
            return Ok(newspaper);
        }
        [HttpPost("GetEmailOfNewspaper")]
        public async Task<IActionResult> GetEmailOfNewspaper(TransactionDTO transaction)
        {
            try
            {
                string email = await _newspaperServices.GetEmailOfNewspaper(Convert.ToInt32(transaction.customerUserId));
                EmailDTO newspaperEmail = new EmailDTO();
                newspaperEmail.Email = email;
                return Ok(newspaperEmail);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

    }
}
