﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
   public  class TransactionHistoryDTO
    {
        public int TransactionId { get; set; }
        public string CompanyName { get; set; }
        public int IsApproved { get; set; }
        public double Cost { get; set; }
        public DateTime TransactionDate { get; set; }
        public DateTime ServiceDate { get; set; }
        public int? AdSizeInPaper { get; set; }
        public int? AdDurationInPaper { get; set; }
        public int? NumberOfDays { get; set; }
        public int? PageNumber { get; set; }

    }
}
