﻿using Add_Ad.Repositories.DTOs;
using EmailService;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Text;
using Add_Ad.Entity;

namespace Add_Ad.Testing.Add_Ad.DTO.Testing
{
    [TestClass]
    public class DTOTest
    {
        [TestMethod]
        public void EmailDTO_Happy()
        {
            EmailDTO email = new EmailDTO();
            email.Email = "diptesh308@gmail.com";
            Assert.AreEqual("diptesh308@gmail.com", email.Email);
        }
        [TestMethod]
        public void EmailDTO_Sad()
        {
            EmailDTO email = new EmailDTO();
            Assert.IsNull(email.Email);
        }
        [TestMethod]
        public void ForgotPasswordDTO_Happy()
        {
            ForgotPasswordDto forgotPasswordDto = new ForgotPasswordDto();
            forgotPasswordDto.ClientURI = "www.google.com";
           
            Assert.AreEqual("www.google.com", forgotPasswordDto.ClientURI);
        }
        [TestMethod]
        public void ForgotPasswordDTO_Sad()
        {
            ForgotPasswordDto forgotPasswordDto = new ForgotPasswordDto();
            Assert.IsNull(forgotPasswordDto.ClientURI);
        }
        [TestMethod]
        public void TvChannelDTO_CustId_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.CustomerUserId = 1;

            Assert.AreEqual(1, tvChannelDTO.CustomerUserId);
        }
        [TestMethod]
        public void TvChannelDTO_CustId_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();

            Assert.IsNull(tvChannelDTO.CustomerUserId);
        }
        [TestMethod]
        public void TvChannelDTOId_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.TvChannelId = 1;

            Assert.AreEqual(1, tvChannelDTO.TvChannelId);
        }
        [TestMethod]
        public void TvChannelDTOId_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();

            Assert.IsNull(tvChannelDTO.TvChannelId);
        }
        [TestMethod]
        public void TvChannelDTOGenre_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.Genre = "Kids";

            Assert.AreEqual("Kids", tvChannelDTO.Genre);
        }
        [TestMethod]
        public void TvChannelDTOGenre_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();

            Assert.IsNull(tvChannelDTO.Genre);
        }
        [TestMethod]
        public void TvChannelDTOLanguage_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.Language = "English";

            Assert.AreEqual("English", tvChannelDTO.Language);
        }
        [TestMethod]
        public void TvChannelDTOLanguage_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            

            Assert.AreEqual(null, tvChannelDTO.Language);
        }
        [TestMethod]
        public void TvChannelDTOIsApproved()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();


            Assert.IsFalse(tvChannelDTO.IsApproved);
            tvChannelDTO.IsApproved = true;
            Assert.IsTrue(tvChannelDTO.IsApproved);
        }
        [TestMethod]
        public void TvChannelDTO_IsBlocked() { 
            TvChannelDTO tvChannelDTO = new TvChannelDTO();


            Assert.IsFalse(tvChannelDTO.IsBlocked);
            tvChannelDTO.IsBlocked = true;
            Assert.IsTrue(tvChannelDTO.IsBlocked);
        }
        [TestMethod]
        public void TvChannelDTOCost_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.Cost = 250;

            Assert.AreEqual(250, tvChannelDTO.Cost);
        }
        [TestMethod]
        public void TvChannelDTOCost_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();


            Assert.AreEqual(0, tvChannelDTO.Cost);
        }
        [TestMethod]
        public void TvChannelDTORating_Happy()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();
            tvChannelDTO.Rating =3.5;

            Assert.AreEqual(3.5, tvChannelDTO.Rating);
        }
        [TestMethod]
        public void TvChannelDTORating_Sad()
        {
            TvChannelDTO tvChannelDTO = new TvChannelDTO();


            Assert.AreEqual(0, tvChannelDTO.Rating);
        }


        [TestMethod]
        public void NewspaperssDTO_CustId_Happy()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();
            newspaperssDTO.CustomerUserId = 1;

            Assert.AreEqual(1, newspaperssDTO.CustomerUserId);
        }
        [TestMethod]
        public void NewspaperssDTO_CustId_Sad()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();

            Assert.IsNull(newspaperssDTO.CustomerUserId);
        }
        [TestMethod]
        public void NewspaperssDTOId_Happy()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();
            newspaperssDTO.NewsPaperId = 1;

            Assert.AreEqual(1, newspaperssDTO.NewsPaperId);
        }
        [TestMethod]
        public void NewspaperssDTOId_Sad()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();

            Assert.IsNull(newspaperssDTO.NewsPaperId);
        }
        
        [TestMethod]
        public void NewspaperssDTOLanguage_Happy()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();
           newspaperssDTO.Language = "English";

            Assert.AreEqual("English", newspaperssDTO.Language);
        }
        [TestMethod]
        public void NewspaperssDTOLanguage_Sad()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();


            Assert.AreEqual(null, newspaperssDTO.Language);
        }
        [TestMethod]
        public void NewspaperssDTOIsApproved()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();


            Assert.IsFalse(newspaperssDTO.IsApproved);
            newspaperssDTO.IsApproved = true;
            Assert.IsTrue(newspaperssDTO.IsApproved);
        }
        [TestMethod]
        public void NewspaperssDTO_IsBlocked()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();


            Assert.IsFalse(newspaperssDTO.IsBlocked);
            newspaperssDTO.IsBlocked = true;
            Assert.IsTrue(newspaperssDTO.IsBlocked);
        }
        [TestMethod]
        public void NewspaperssDTOCost_Happy()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();
            newspaperssDTO.Cost = 250;

            Assert.AreEqual(250, newspaperssDTO.Cost);
        }
        [TestMethod]
        public void NewspaperssDTOCost_Sad()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();


            Assert.AreEqual(0, newspaperssDTO.Cost);
        }
        [TestMethod]
        public void NewspaperssDTORating_Happy()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();
           newspaperssDTO.Rating = 24000.5;

            Assert.AreEqual(24000.5, newspaperssDTO.Rating);
        }
        [TestMethod]
        public void NewspaperssDTORating_Sad()
        {
            NewspaperssDTO newspaperssDTO = new NewspaperssDTO();


            Assert.AreEqual(0, newspaperssDTO.Rating);
        }
        //[TestMethod]
        //public void MessageSubject_Happy()
        //{
        //    List<string> temp = new List<string>();
        //    Message msg = new Message(temp,"a","b");
        //    msg.Subject = "This";
        //    Assert.AreEqual("This", msg.Subject);

        //}
        //[TestMethod]
        //public void MessageSubject_Sad()
        //{
        //    List<string> temp = new List<string>();
        //    Message msg = new Message(temp, "a", "b");
        //    Assert.IsNull(null, msg.Subject);

        //}
        //[TestMethod]
        //public void MessageContent_Happy()
        //{
        //    List<string> temp = new List<string>();
        //    Message msg = new Message(temp, "a", "b");
        //    msg.Content = "This";
        //    Assert.AreEqual("This", msg.Content);

        //}
        //[TestMethod]
        //public void MessageContent_Sad()
        //{
        //    List<string> temp = new List<string>();
        //    Message msg = new Message(temp, "a", "b");
        //    Assert.IsNull(null, msg.Content);

        //}
        //[TestMethod]
        //public void EmailConfigurationFrom_Happy()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    emailConfiguration.From = "test";
        //    Assert.AreEqual("test", emailConfiguration.From);
        //}
        //[TestMethod]
        //public void EmailConfigurationFrom_Sad()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    Assert.AreEqual(null, emailConfiguration.From);
        //}
        //[TestMethod]
        //public void EmailConfigurationSMTP_Happy()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    emailConfiguration.SmtpServer = "test";
        //    Assert.AreEqual("test", emailConfiguration.SmtpServer);
        //}
        //[TestMethod]
        //public void EmailConfigurationSMTP_Sad()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    Assert.AreEqual(null, emailConfiguration.SmtpServer);
        //}
        //[TestMethod]
        //public void EmailConfigurationport_Happy()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    emailConfiguration.Port = 40;
        //    Assert.AreEqual(40, emailConfiguration.Port);
        //}
        //[TestMethod]
        //public void EmailConfigurationport_Sad()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    Assert.AreEqual(0, emailConfiguration.Port);
        //}

        //[TestMethod]
        //public void EmailConfigurationUserName_Happy()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    emailConfiguration.UserName = "Diptesh";
        //    Assert.AreEqual("Diptesh", emailConfiguration.UserName);
        //}
        //[TestMethod]
        //public void EmailConfigurationUserName_Sad()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    Assert.AreEqual(null, emailConfiguration.UserName);
        //}
        //[TestMethod]
        //public void EmailConfigurationPassword_Happy()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    emailConfiguration.Password = "Hello#107";
        //    Assert.AreEqual("Hello#107", emailConfiguration.Password);
        //}
        //[TestMethod]
        //public void EmailConfigurationPassword_Sad()
        //{
        //    EmailConfiguration emailConfiguration = new EmailConfiguration();
        //    Assert.AreEqual(null, emailConfiguration.Password);
        //}

        [TestMethod]
        public void TransactionTransactionId_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.TransactionId = 12;
            Assert.AreEqual(12, transaction.TransactionId);
        }
        [TestMethod]
        public void TransactionTransactionId_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(0, transaction.TransactionId);
        }
        [TestMethod]
        public void TransactionTvChannelId_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.TvChannelId = 12;
            Assert.AreEqual(12, transaction.TvChannelId);
        }
        [TestMethod]
        public void TransactionTvChannelId_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.TvChannelId);
        }
        [TestMethod]
        public void TransactionNewsPaperId_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.NewsPaperId = 12;
            Assert.AreEqual(12, transaction.NewsPaperId);
        }
        [TestMethod]
        public void TransactionNewsPaperId_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.NewsPaperId);
        }
        [TestMethod]
        public void TransactionCustomerUserId_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.CustomerUserId = 12;
            Assert.AreEqual(12, transaction.CustomerUserId);
        }
        [TestMethod]
        public void TransactionCustomerUserId_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.CustomerUserId);
        }
        //[TestMethod]
        //public void TransactionTransactionDate_Happy()
        //{
        //    Transaction transaction = new Transaction();
        //    transaction.TransactionDate = DateTime.Now;
        //    Assert.AreEqual(DateTime.Now, transaction.TransactionDate);
        //}
        //[TestMethod]
        //public void TransactionTransactionDate_Sad()
        //{
        //    Transaction transaction = new Transaction();
        //    Assert.AreEqual(null, transaction.TransactionDate);
        //}
        [TestMethod]
        public void TransactionCost_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.Cost = 12;
            Assert.AreEqual(12, transaction.Cost);
        }
        [TestMethod]
        public void TransactionCost_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(0, transaction.Cost);
        }
        [TestMethod]
        public void TransactionIsApproved_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.IsApproved = 1;
            Assert.AreEqual(1, transaction.IsApproved);
        }
        [TestMethod]
        public void TransactionIsApproved_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(0, transaction.IsApproved);
        }
        [TestMethod]
        public void TransactionAdSizeInPaper_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.AdSizeInPaper = 1;
            Assert.AreEqual(1, transaction.AdSizeInPaper);

        }

        [TestMethod]
        public void TransactionNumberOfDays_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.NumberOfDays = 1;
            Assert.AreEqual(1, transaction.NumberOfDays);
        }
        [TestMethod]
        public void TransactionNumberOfDays_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.NumberOfDays);

        }

        [TestMethod]
        public void TransactionPageNumber_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.PageNumber = 1;
            Assert.AreEqual(1, transaction.PageNumber);
        }
        [TestMethod]
        public void TransactionPageNumber_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.PageNumber);

        }

        //[TestMethod]
        //public void TransactionAdSizeInPaper_Sad()
        //{
        //    Transaction transaction = new Transaction();
        //    Assert.AreEqual(0, transaction.AdSizeInPaper);
        //}
        [TestMethod]
        public void TransactionAdDurationInPaper_Happy()
        {
            Transaction transaction = new Transaction();
            transaction.AdDurationInPaper = 1;
            Assert.AreEqual(1, transaction.AdDurationInPaper);

        }
        //[TestMethod]
        //public void TransactionAdDurationInPaper_Sad()
        //{
        //    Transaction transaction = new Transaction();
        //    Assert.AreEqual(0, transaction.AdDurationInPaper);
        //}
        [TestMethod]
        public void TransactionCustomerUser_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.CustomerUser);
        }
        [TestMethod]
        public void TransactionNewspaper_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.Newspaper);
        }
        [TestMethod]
        public void TransactionTvChannel_Sad()
        {
            Transaction transaction = new Transaction();
            Assert.AreEqual(null, transaction.TvChannel);
        }
        [TestMethod]
        public void CustomerUserRoleId_Happy()
        {
            CustomerUser customerUser = new CustomerUser();
            customerUser.RoleId = 12;
            Assert.AreEqual(12, customerUser.RoleId);
        }
        [TestMethod]
        public void CustomerUserRoleId_Sad()
        {
            CustomerUser customerUser = new CustomerUser();
            Assert.AreEqual(null, customerUser.RoleId);
        }
        [TestMethod]
        public void CustomerUserRole_Sad()
        {
            CustomerUser customerUser = new CustomerUser();
            Assert.AreEqual(null, customerUser.Role);
        }

        [TestMethod]
        public void TransactionHistoryDTOTransactionId_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.TransactionId = 1;
            Assert.AreEqual(1, transactionHistoryDTO.TransactionId);
        }
        [TestMethod]
        public void TransactionHistoryDTOTransactionId_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(0, transactionHistoryDTO.TransactionId);
        }
        [TestMethod]
        public void TransactionHistoryDTOCompanyName_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.CompanyName = "Mindtree";
            Assert.AreEqual("Mindtree", transactionHistoryDTO.CompanyName);
        }
        [TestMethod]
        public void TransactionHistoryDTOCompanyName_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(null, transactionHistoryDTO.CompanyName);
        }
        [TestMethod]
        public void TransactionHistoryDTOIsApproved_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.IsApproved = 1;
            Assert.AreEqual(1, transactionHistoryDTO.IsApproved);
        }
        [TestMethod]
        public void TransactionHistoryDTOIsApproved_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(0, transactionHistoryDTO.IsApproved);
        }

        [TestMethod]
        public void TransactionHistoryDTOCost_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.Cost = 1;
            Assert.AreEqual(1, transactionHistoryDTO.Cost);
        }
        [TestMethod]
        public void TransactionHistoryDTOCost_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(0, transactionHistoryDTO.Cost);
        }

        [TestMethod]
        public void TransactionHistoryDTOAdSizeInPaper_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.AdSizeInPaper = 1;
            Assert.AreEqual(1, transactionHistoryDTO.AdSizeInPaper);
        }
        [TestMethod]
        public void TransactionHistoryDTOAdSizeInPaper_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(null, transactionHistoryDTO.AdSizeInPaper);
        }

        [TestMethod]
        public void TransactionHistoryDTOAdDurationInPaper_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.AdDurationInPaper = 1;
            Assert.AreEqual(1, transactionHistoryDTO.AdDurationInPaper);
        }
        [TestMethod]
        public void TransactionHistoryDTOAdDurationInPaper_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(null, transactionHistoryDTO.AdDurationInPaper);
        }

        [TestMethod]
        public void TransactionHistoryDTONumberOfDays_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.NumberOfDays = 1;
            Assert.AreEqual(1, transactionHistoryDTO.NumberOfDays);
        }
        [TestMethod]
        public void TransactionHistoryDTONumberOfDays_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(null, transactionHistoryDTO.NumberOfDays);
        }

        [TestMethod]
        public void TransactionHistoryDTOPageNumber_Happy()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            transactionHistoryDTO.PageNumber = 1;
            Assert.AreEqual(1, transactionHistoryDTO.PageNumber);
        }
        [TestMethod]
        public void TransactionHistoryDTOPageNumber_Sad()
        {
            TransactionHistoryDTO transactionHistoryDTO = new TransactionHistoryDTO();
            Assert.AreEqual(null, transactionHistoryDTO.PageNumber);
        }



        [TestMethod]
        public void TransactionDTOcustomerUserId_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.customerUserId = 1;
            Assert.AreEqual(1, transactionDTO.customerUserId);
        }
        [TestMethod]
        public void TransactionDTOcustomerUserId_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.customerUserId);
        }

        [TestMethod]
        public void TransactionDTOtransactionId_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.TransactionId = 1;
            Assert.AreEqual(1, transactionDTO.TransactionId);
        }
        [TestMethod]
        public void TransactionDTOtransactionId_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.TransactionId);
        }

        [TestMethod]
        public void TransactionDTOTvChannelId_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.TvChannelId = 1;
            Assert.AreEqual(1, transactionDTO.TvChannelId);
        }
        [TestMethod]
        public void TransactionDTOTvChannelId_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.TvChannelId);
        }

        [TestMethod]
        public void TransactionDTONewsPaperId_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.NewsPaperId = 1;
            Assert.AreEqual(1, transactionDTO.NewsPaperId);
        }
        [TestMethod]
        public void TransactionDTONewsPaperId_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.NewsPaperId);
        }

        [TestMethod]
        public void TransactionDTOUserName_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.UserName = "Diptesh";
            Assert.AreEqual("Diptesh", transactionDTO.UserName);
        }
        [TestMethod]
        public void TransactionDTOUserName_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.UserName);
        }

        [TestMethod]
        public void TransactionDTOCompanyName_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.CompanyName = "Mindtree";
            Assert.AreEqual("Mindtree", transactionDTO.CompanyName);
        }
        [TestMethod]
        public void TransactionDTOCompanyName_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(null, transactionDTO.CompanyName);
        }

        [TestMethod]
        public void TransactionDTOAdDurationInPaper_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.AdDurationInPaper = 1;
            Assert.AreEqual(1, transactionDTO.AdDurationInPaper);
        }
        [TestMethod]
        public void TransactionDTOAdDurationInPaper_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.AdDurationInPaper);
        }

        [TestMethod]
        public void TransactionDTOIsApproved_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.IsApproved = 1;
            Assert.AreEqual(1, transactionDTO.IsApproved);
        }
        [TestMethod]
        public void TransactionDTOIsApproved_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.IsApproved);
        }
        [TestMethod]
        public void TransactionDTOCost_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.Cost = 1;
            Assert.AreEqual(1, transactionDTO.Cost);
        }
        [TestMethod]
        public void TransactionDTOCost_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.Cost);
        }

        [TestMethod]
        public void TransactionDTOAdSizeInPaper_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.AdSizeInPaper = 1;
            Assert.AreEqual(1, transactionDTO.AdSizeInPaper);
        }
        [TestMethod]
        public void TransactionDTOAdSizeInPaper_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.AdSizeInPaper);
        }

        [TestMethod]
        public void TransactionDTOPageNumber_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.PageNumber = 1;
            Assert.AreEqual(1, transactionDTO.PageNumber);
        }
        [TestMethod]
        public void TransactionDTOPageNumber_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.PageNumber);
        }
        [TestMethod]
        public void TransactionDTONumberOfDays_Happy()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            transactionDTO.NumberOfDays = 1;
            Assert.AreEqual(1, transactionDTO.NumberOfDays);
        }
        [TestMethod]
        public void TransactionDTONumberOfDays_Sad()
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            Assert.AreEqual(0, transactionDTO.NumberOfDays);
        }

        [TestMethod]
        public void NewspaperPriceUpdateDTOEmail_Happy()
        {
            NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
            newspaperPriceUpdateDTO.Email = "diptesh@gmail.com";
            Assert.AreEqual("diptesh@gmail.com", newspaperPriceUpdateDTO.Email);
        }
        [TestMethod]
        public void NewspaperPriceUpdateDTOEmail_Sad()
        {
            NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
            Assert.AreEqual(null, newspaperPriceUpdateDTO.Email);
        }

        [TestMethod]
        public void NewspaperPriceUpdateDTOCost_Happy()
        {
            NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
            newspaperPriceUpdateDTO.Cost = 1;
            Assert.AreEqual(1, newspaperPriceUpdateDTO.Cost);
        }
        [TestMethod]
        public void NewspaperPriceUpdateDTOCost_Sad()
        {
            NewspaperPriceUpdateDTO newspaperPriceUpdateDTO = new NewspaperPriceUpdateDTO();
            Assert.AreEqual(0, newspaperPriceUpdateDTO.Cost);
        }



    }
}
