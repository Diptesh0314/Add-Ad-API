﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TvChannelController : ControllerBase
    {
        private readonly ITvChannelServices _tvChannelServices;

        public TvChannelController(ITvChannelServices tvChannelServices)
        {
            _tvChannelServices = tvChannelServices;
        }

        /// <summary>
        /// This Controller is used to display all Channels
        /// </summary>
        /// <returns>Returns OK success response</returns>
        [HttpGet]
        public async Task<ActionResult> GetAllChannels()
        {
            try
            {
                return Ok(await _tvChannelServices.GetAllChannels());
            }
            catch (NoTvChannelFound e)
            {
                return BadRequest(e.Message);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        } 

        /// <summary>
        /// This Controller is used to Search based on Genre
        /// </summary>
        /// <param name="genre"></param>
        /// <returns>Returns OK success response</returns>
        [HttpGet("SearchGenre/{genre}")]
        public async Task<ActionResult> SearchGenre(string genre)
        {
            try
            {
                return Ok(await _tvChannelServices.SearchGenre(genre));
            }
            catch (NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// This Controller is used to Search based on Rating
        /// </summary>
        /// <param name="rating"></param>
        /// <returns>Returns OK success response</returns>
        [HttpGet("SearchRating/{rating}")]
        public async Task<ActionResult> SearchRating(int rating)
        {
            try
            {
                return Ok(await _tvChannelServices.SearchRating(rating));
            }
            catch (NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// This Controller is used to register the Channel details
        /// </summary>
        /// <param name="channelDTO"></param>
        /// <returns>Returns OK success response or BadRequest based on the number of rows affected</returns>
        [HttpPost]
        public async Task<IActionResult> RegisterChanel(TvChannelDTO channelDTO)
        {
            try
            {
                TvChannel channel = new TvChannel();
                channel.CustomerUserId = channelDTO.CustomerUserId;
                channel.Genre = channelDTO.Genre;
                channel.Language = channelDTO.Language;
                channel.Rating = (int)channelDTO.Rating;
                int rowsAffected = 0;
                rowsAffected = await _tvChannelServices.RegisterChanel(channel);
                if (rowsAffected == 0)
                    return BadRequest();
                else
                    return Ok();
            }
            catch (TvChannelInsertionException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// This Controller shows the Top Tv Channels
        /// </summary>
        /// <returns>Returns OK success response if Tv Channels exists if not returns BadRequest</returns>
        [HttpGet("ShowTopTvChannels")]
        public async Task<IActionResult> ShowTopTvChannels()
        {
            try
            {
                return Ok(await _tvChannelServices.ShowTopTvChannels());
            }
            catch (NoTvChannelFound e)
            {
                return BadRequest(e.Message);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetActiveTvChannel")]

        public async Task<IActionResult> GetActiveTvChannel()
        {

            try
            {
                return Ok(await _tvChannelServices.GetActiveTvChannel());
            }
            catch (NoTvChannelFound e)
            {
                return BadRequest(e.Message);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPut("UpdateTvChannel")]
        public async Task<IActionResult> UpdateTvChannel(SearchChannelDTO tvChannel)
        {

            try
            {
                return Ok(await _tvChannelServices.UpdateTvChannel(Convert.ToInt32(tvChannel.TvChannelId)));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetBlockedTvChannels")]
        public async Task<IActionResult> GetBlockedTvChannels()
        {

            try
            {
                return Ok(await _tvChannelServices.GetBlockedTvChannels());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetNotApprovedTvChannels")]
        public async Task<IActionResult> GetNotApprovedTvChannels()
        {

            try
            {
                return Ok(await _tvChannelServices.GetNotApprovedTvChannels());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPut("UnblockTvChannel")]
        public async Task<IActionResult> UnblockTvChannel(SearchChannelDTO tvChannel)
        {

            try
            {
                return Ok(await _tvChannelServices.UnblockTvChannel(Convert.ToInt32(tvChannel.TvChannelId)));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPut("ApproveTvChannel")]

        public async Task<IActionResult> ApproveTvChannel(SearchChannelDTO tvChannel) {

            try {
                return Ok(await _tvChannelServices.ApproveTvChannel(Convert.ToInt32(tvChannel.TvChannelId)));
            }
            catch (SqlException e) {
                return BadRequest(e.Message);
            } catch (Exception e) {
                return BadRequest(e.Message);
            }
        }
        /// <summary>
        /// UpdateChannelPrice updates the price of the tvchannel cost
        /// </summary>
        /// <param name="tvChannelPriceUpdateDTO"></param>
        /// <returns>Returns number of rows affected in database(Type=int)</returns>
        [HttpPut("UpdateChannelPrice")]
        public async Task<IActionResult> UpdateChannelPrice(TvChannelPriceUpdateDTO tvChannelPriceUpdateDTO)
        {
            try
            {
                int rowsAffected;
                rowsAffected = await _tvChannelServices.UpdateChannelPrice(tvChannelPriceUpdateDTO);
                return Ok(rowsAffected);
            }
            catch(NoTvChannelFound ex)
            {
                return BadRequest(ex.Message);
            }
            catch(TvChannelInsertionException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("getByEmail/{email}")]
        public async Task<IActionResult> GetByEmail(string email)
        {
            TvChannel tvChannel =await _tvChannelServices.GetByEmail(email);
            return Ok(tvChannel);
        }
        [HttpPost("GetEmailTvChannel")]
        public async Task<IActionResult> GetEmailTvChannel(SearchChannelDTO tvChannel)
        {
            try
            {
                string email = await _tvChannelServices.GetEmailTvChannel(Convert.ToInt32(tvChannel.TvChannelId));
                EmailDTO tvChannelEmail = new EmailDTO();
                tvChannelEmail.Email = email;
                return Ok(tvChannelEmail);
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
           
        }

        [HttpPut("RejectTvChannel")]
        public async Task<IActionResult> RejectTvChannel(SearchChannelDTO tvChannel) {

            try
            {
                return Ok(await _tvChannelServices.RejectTvChannel(Convert.ToInt32(tvChannel.TvChannelId)));
            }
            catch (SqlException e)
            {
                return BadRequest(e.Message);
            }
            catch (Exception e) {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("TransactionStatusConfirmation")]
        public async Task<IActionResult> TransactionStatusConfirmation(Transaction transaction)
        {
            try
            {
                int? transactionId = await _tvChannelServices.TransactionStatusConfirmation(transaction);
                if (transactionId == 0)
                    return BadRequest("Some error occured");
                return Ok(transaction.IsApproved);
            }
            catch (SqlException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetPendingTransactionRequests/{email}")]
        public async Task<ActionResult> GetPendingTransactionRequests(string email)
        {
            List<TransactionDTO> transactionsList;
            try
            {
                transactionsList = await _tvChannelServices.GetPendingTransactionRequests(email);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            if (transactionsList.Count != 0)
            {
                return Ok(transactionsList);
            }
            else
            {
                return Ok(null);
            }
        }


        [HttpGet("GetEmail/{id}")]
        public async Task<ActionResult> GetEmailById(int? Id)
        {
            int id = Id ?? 0;
            string email;
            try
            {
                email = await _tvChannelServices.GetEmailById(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            if (email != null)
            {
                return Ok(email);
            }
            else
            {
                return Ok(null);
            }
        }

    }
}