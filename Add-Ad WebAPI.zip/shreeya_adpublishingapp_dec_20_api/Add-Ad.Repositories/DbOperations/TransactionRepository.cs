﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly Add_AdContext _add_AdContext;

        public TransactionRepository(Add_AdContext add_AdContext)
        {
            _add_AdContext = add_AdContext;
        }

        public TransactionDTO TransactionToTransactionDTO(Transaction transaction, TransactionDTO transactionDTO)
        {
            transactionDTO.TransactionId = transaction.TransactionId;
            transactionDTO.Cost = transaction.Cost;
            transactionDTO.IsApproved = transaction.IsApproved;
            transactionDTO.NumberOfDays = transaction.NumberOfDays ?? 0;
            transactionDTO.PageNumber = transaction.PageNumber ?? 0;

            transactionDTO.ServiceDate = transaction.ServiceDate;
            transactionDTO.TransactionDate = transaction.TransactionDate;

            return transactionDTO;
        }

        public async Task<List<TransactionDTO>> GetTransaction(string email)
        {
            CustomerUser user = _add_AdContext.CustomerUsers.FirstOrDefault(p => p.EmailId == email);
            int id = user.CustomerUserId ?? 0;
            List<Transaction> transactions = await _add_AdContext.Transactions.Where( p=> p.CustomerUserId==id ).ToListAsync();
            List<TransactionDTO> transactionDTOs = new List<TransactionDTO>();
            foreach (Transaction transaction in transactions)
            {
                TransactionDTO transactionDTO = new TransactionDTO();

                
                transactionDTO.TvChannelId = transaction.TvChannelId;
                transactionDTO.NewsPaperId = transaction.NewsPaperId;
               
                if (transaction.NewsPaperId != null)
                {
                    Newspaper newspaper = await _add_AdContext.Newspapers.FirstOrDefaultAsync(p => p.NewsPaperId == transaction.NewsPaperId);
                    CustomerUser NewspaperUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(o => o.CustomerUserId == newspaper.CustomerUserId);
                    transactionDTO.CompanyName = NewspaperUser.UserName;
                    transactionDTO.AdSizeInPaper = transaction.AdSizeInPaper ?? 0;
                }
                else if(transaction.TvChannelId != null)
                {
                    TvChannel tvChannel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(p => p.TvChannelId == transaction.TvChannelId);
                    CustomerUser ChannelUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(o => o.CustomerUserId == tvChannel.CustomerUserId);
                    transactionDTO.CompanyName = ChannelUser.UserName;
                    transactionDTO.AdDurationInPaper = transaction.AdDurationInPaper ?? 0;
                }
                transactionDTO = TransactionToTransactionDTO(transaction, transactionDTO);
                transactionDTOs.Add(transactionDTO);

            }
            transactionDTOs.Reverse();
            return transactionDTOs;
        }

        public async Task<int?> GetUserId(string name)
        {
            CustomerUser user = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(p=> p.UserName.Equals(name));
            return user.CustomerUserId;
        }
        public async Task<TransactionDTO> AddTransaction(Transaction transaction)
        {
            TransactionDTO transactionDTO = new TransactionDTO();
            if (transaction.NewsPaperId != 0)
            {
                transaction.TvChannelId = null;
                transaction.Newspaper = await _add_AdContext.Newspapers.FirstOrDefaultAsync(n => n.NewsPaperId == transaction.NewsPaperId);
                transactionDTO.NewsPaperId = transaction.NewsPaperId;
                CustomerUser ChannelUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(u => u.CustomerUserId == transaction.Newspaper.CustomerUserId);
                transactionDTO.CompanyName = ChannelUser.UserName;
                transactionDTO.AdSizeInPaper = transaction.AdSizeInPaper ?? 0;
            }
            else
            {
                transaction.NewsPaperId = null;
                transaction.TvChannel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(t => t.TvChannelId == transaction.TvChannelId);
                transactionDTO.TvChannelId = transaction.TvChannelId;
                CustomerUser ChannelUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(u => u.CustomerUserId == transaction.TvChannel.CustomerUserId);
                transactionDTO.CompanyName = ChannelUser.UserName;
                transactionDTO.AdDurationInPaper = transaction.AdDurationInPaper ?? 0;
            }

            await _add_AdContext.Transactions.AddAsync(transaction);
            await _add_AdContext.SaveChangesAsync();

            transactionDTO = TransactionToTransactionDTO(transaction, transactionDTO);

            if (transaction.TransactionId != 0)
            {   
                return transactionDTO;
            }
            return null;
        }
    }
}
