﻿using Add_Ad.CustomExceptions;
using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Repositories.TokenInterfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories
{
    /// <summary>
    /// Class Handle to Customer User Operations
    /// </summary>
    public class CustomerUserRepository : ICustomerUserRepository
    {
        private readonly Add_AdContext _add_AdContext;
        private readonly ITokenCustomerService _tokenservice;
        public CustomerUserRepository()
        {

        }
        public CustomerUserRepository(Add_AdContext add_AdContext)
        {
            _add_AdContext = add_AdContext;
            
        }
        public CustomerUserRepository(Add_AdContext add_AdContext, ITokenCustomerService tokenservice)
        {
            _add_AdContext = add_AdContext;
            _tokenservice = tokenservice;
        }
        /// <summary>
        /// This function hashes the password,and saves data as CustomerUser Object 
        /// And retrieves the newly created auto incremented CustomerUserId
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns>   Returns newly created CustomerUserId </returns>
        public async Task<int?> RegisterUser(CustomerUserDTO userDTO)
        {
            int? newCustomerId;
            CustomerUser customerUser = await UserExists(userDTO.EmailId);
            CustomerUser customerNameUser = await UsernameExists(userDTO.UserName);
            if (customerUser != null || customerNameUser != null)
                throw new UserAlreadyExistsException("User Already Exists");
            else
            {
                try
                {
                    using var hmac = new HMACSHA512();
                    var user = new CustomerUser
                    {
                        EmailId = userDTO.EmailId,
                        UserName = userDTO.UserName,
                        RoleId = userDTO.RoleId,
                        PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(userDTO.PassWord)),
                        PasswordSalt = hmac.Key
                    };
                    _add_AdContext.CustomerUsers.Add(user);
                    await _add_AdContext.SaveChangesAsync();
                    CustomerUser tempCustomer = await _add_AdContext.CustomerUsers.SingleOrDefaultAsync(x => x.EmailId == user.EmailId);
                    newCustomerId = tempCustomer.CustomerUserId;
                    return newCustomerId;
                }
                catch(Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                
            }
            
        }
        /// <summary>
        /// UserExists function Checks if given Email exist in Database or not
        /// </summary>
        /// <param name="EmailId">Type=string</param>
        /// <returns>if exist then return The CustomerUser Object else return null</returns>
       
        public async Task<CustomerUser> UserExists(string EmailId)
        {
            return await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(x => x.EmailId == EmailId);
        }
        /// <summary>
        /// UserNameExists function Checks if given UserName exist in Database or not
        /// 
        /// </summary>
        /// <param name="userName">type=string</param>
        /// <returns>if exist then return The CustomerUser Object else return null</returns>
        public async Task<CustomerUser>UsernameExists(string userName)
        {
            return await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(x => x.UserName == userName.ToLower());
        }
        /// <summary>
        /// This method is used to authenticate the user
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns>Returns the EmailId and Token as CustomerUserDTO object</returns>
        public async Task<CustomerUserTokenDTO> AuthenticateUser(CustomerUserDTO userDTO)
        {
            CustomerUser user = await UserExists(userDTO.EmailId);
            if (user == null)
                return null;
            if (user.RoleId == 2)
            {
                Newspaper newspaper = await _add_AdContext.Newspapers.FirstOrDefaultAsync(n => n.CustomerUserId == user.CustomerUserId);
                if (newspaper.IsApproved == false)
                    return null;
            }


            if(user.RoleId==3)
            {
                TvChannel tvChannel = await _add_AdContext.TvChannels.FirstOrDefaultAsync(t => t.CustomerUserId == user.CustomerUserId);
                if (tvChannel.IsApproved == false)
                    return null;
            }
            using var hmac = new HMACSHA512(user.PasswordSalt);

            var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(userDTO.PassWord));

            for (int i = 0; i < computedHash.Length; i++)
            {
                if (computedHash[i] != user.PasswordHash[i])
                {
                    return null;
                }
            }

            return new CustomerUserTokenDTO
            {
                EmailId = user.EmailId,
                Token = _tokenservice.CreateToken(user)
            };
        }
        /// <summary>
        /// This method calls UserExists(string EmailId) which check the existence of the email.
        /// </summary>
        /// <param name="forgotPasswordDto"></param>
        /// <returns>Returns 0 if customer's email does not exist and 1 if customer's email exist</returns>
        public async Task<int?> CheckEmailIfExist(ForgotPasswordDto forgotPasswordDto)
        {
            try
            {
                CustomerUser customerUser = await UserExists(forgotPasswordDto.Email);
                if (customerUser != null)
                    return customerUser.CustomerUserId;
                else
                    return 1;
            }
            catch(Exception ex)
            {
                throw new SqlException("Some error occured", ex);
            }
            
        }
        /// <summary>
        /// When the user clicks the link in the mail to reset password, this method is called which updates the existing users password with the new password.
        /// </summary>
        /// <param name="userVal"></param>
        /// <returns>Returns 0 if customer's email does not exist and CustomerUserId if email exists </returns>
        public async Task<int?> UpdatePassword(CustomerUserDTO userVal)
        {
            try
            {
                CustomerUser customerUser = await UserExists(userVal.EmailId);
                if (customerUser == null||customerUser.CustomerUserId!=userVal.Token)
                    return 0;
                using var hmac = new HMACSHA512();
                var user = new CustomerUser
                {
                    PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(userVal.PassWord)),
                    PasswordSalt = hmac.Key
                };

                //_add_AdContext.CustomerUsers.Add(user);
                var userDetail = await _add_AdContext.CustomerUsers.FirstAsync(a => a.EmailId == userVal.EmailId);
                userDetail.PasswordHash = user.PasswordHash;
                userDetail.PasswordSalt = user.PasswordSalt;
                await _add_AdContext.SaveChangesAsync();
                return customerUser.CustomerUserId;
            }
            catch (Exception ex)
            {
                throw new SqlException("Some error occured", ex);
            }

        }

        private async Task<CustomerUser> UserIdExists(int token)
        {
            return await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(x => x.CustomerUserId == token);
        }

        /// <summary>
        /// This method updates the existing users password with the new password
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns>Returns CustomerUserId if email exists </returns>
        public async Task<int?> UpdateUser(CustomerUserDTO userDTO)
        {
            try
            {
                CustomerUser customerUser = await UserExists(userDTO.EmailId);
                if (customerUser == null)
                    return 0;
                using var hmac = new HMACSHA512();
                customerUser.PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(userDTO.PassWord));
                customerUser.PasswordSalt = hmac.Key;
                await _add_AdContext.SaveChangesAsync();
                return customerUser.CustomerUserId;
            }
            catch (Exception ex)
            {
                throw new SqlException("Some error occured", ex);
            }

        }
    }
}
