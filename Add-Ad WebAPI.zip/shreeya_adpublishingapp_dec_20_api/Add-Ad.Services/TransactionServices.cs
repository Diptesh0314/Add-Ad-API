﻿using Add_Ad.Entity;
using Add_Ad.Repositories;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public class TransactionServices: ITransactionServices
    {
        private readonly ITransactionRepository _transactionRepository;

        public TransactionServices(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }

        public async Task<List<TransactionDTO>> GetTransaction(string email)
        {
            return await _transactionRepository.GetTransaction(email);
        }

        public async Task<int?> GetUserId(string name)
        {
            return await _transactionRepository.GetUserId(name); 
        }

        public Task<TransactionDTO> AddTransaction(Transaction transaction)
        {
            return _transactionRepository.AddTransaction(transaction);
        }

        public Transaction CalculateCost(Transaction transaction)
        {
            double? totalCost;

            if(transaction.AdSizeInPaper != null)
                totalCost = transaction.Cost * transaction.AdSizeInPaper;

            else
                totalCost = transaction.Cost * transaction.AdDurationInPaper;

            totalCost *= transaction.NumberOfDays;
            transaction.Cost = (int)totalCost;

            return transaction;
        }
    }
}
