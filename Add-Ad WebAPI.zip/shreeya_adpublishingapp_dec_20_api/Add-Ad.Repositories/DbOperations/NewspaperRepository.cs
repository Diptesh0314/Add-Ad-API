using Add_Ad.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;

namespace Add_Ad.Repositories
{
    /// <summary>
    /// Class used to Handle to Newspaper Operations
    /// </summary>
    public class NewspaperRepository : INewspaperRepository
    {
        public readonly Add_AdContext _add_AdContext;

        public NewspaperRepository(Add_AdContext add_AdContext)
        {
            _add_AdContext = add_AdContext;
        }

        /// <summary>
        ///  This method will show the list of top 4 newspapers based on their ratings
        /// </summary>
        /// <returns> returns the list of top newspapers</returns>
        public async Task<List<TopNewspaper>> ShowTopNewspapers()
        {
            List<TopNewspaper> topNewspapers = new List<TopNewspaper>();
            try
            {
                var topNewspapersData = await Task.Run(() => (from Newspapers in _add_AdContext.Newspapers
                                                              join CustomerUser in _add_AdContext.CustomerUsers
                                                              on Newspapers.CustomerUserId equals CustomerUser.CustomerUserId
                                                              where (Newspapers.IsApproved == true && Newspapers.IsBlocked == false)
                                                              orderby Newspapers.Rating descending
                                                              select new
                                                              {
                                                                  CustomerUser.UserName,
                                                                  Newspapers.Rating,
                                                                  Newspapers.Language,
                                                              }).Take(4).ToListAsync());



                foreach (var topNewspapersIterator in topNewspapersData)
                {

                    TopNewspaper topNewspaper = new TopNewspaper();

                    topNewspaper.UserName = topNewspapersIterator.UserName;
                    topNewspaper.Rating = topNewspapersIterator.Rating;
                    topNewspaper.Language = topNewspapersIterator.Language;


                    topNewspapers.Add(topNewspaper);

                }

                if (topNewspapers.Count == 0)
                {
                    throw new NoNewspaperFound("Some error Occurred");
                }
            }
            catch (NoNewspaperFound ex)
            {
                throw new NoNewspaperFound(ex.Message);
            }

            return topNewspapers;
        }
        /// <summary>
        /// This method will register the new newspaper in the database
        /// </summary>
        /// <param name="newspaper"></param>
        /// <returns>returns non zero non negative value which indicates that data has been registered</returns>
        public async Task<int> RegisterNewspaper(Newspaper newspaper)
        {
            if (newspaper == null)
                throw new ArgumentNullException("Null value");
            try
            {
                int rowsAffected = 0;
                _add_AdContext.Newspapers.Add(newspaper);
                rowsAffected = await _add_AdContext.SaveChangesAsync();
                if (rowsAffected == 0)
                    throw new NewspaperInsertionException("Insertion failed,something went wrong");
                return rowsAffected;
            }
            catch (NewspaperInsertionException ex)
            {
                throw new NewspaperInsertionException(ex.Message);
            }


        }
        /// <summary>
        /// this method gets all the news papers present in the repository
        /// </summary>
        /// <returns> list of all the newspapers</returns>
        public async Task<object> GetAllNewsPapers()
        {
            try
            {
                List<SearchNewspaperDTO> newspapersList = new List<SearchNewspaperDTO>();
                var newspaperList = await (from newspapers in _add_AdContext.Newspapers
                                           join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals
                                               customerUsers.CustomerUserId
                                           where (newspapers.IsBlocked == false && newspapers.IsApproved == true && newspapers.Cost>0)
                                           orderby newspapers.Rating descending
                                           select new
                                           {
                                               customerUsers.UserName,
                                               newspapers.Cost,
                                               newspapers.Language,
                                               newspapers.Rating,
                                               newspapers.NewsPaperId
                                           }).ToListAsync();
                //List<Newspaper> newspapers = await _add_AdContext.Newspapers.ToListAsync();
                newspapersList = EntityToDto(newspapersList, newspaperList);
                if (newspaperList == null)
                {
                    throw new NoNewspaperFound("No Newspaper is Present");
                }

                return newspapersList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        
        /// <summary>
        /// it will search for a perticular newspaper 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>searched newspaper</returns>
        public async Task<object> SearchNewspaper(string name)
        {
            try
            {
                List<SearchNewspaperDTO> newspapersList = new List<SearchNewspaperDTO>();
                List<SearchChannelDTO> tvChannelList = new List<SearchChannelDTO>();
                int? roleId = 0;
                int? customerUserId = 0;
                int count = 0;
                List<CustomerUser> customers = await _add_AdContext.CustomerUsers.ToListAsync();
                foreach (CustomerUser customer in customers)
                {
                    if (customer.UserName.Equals(name, StringComparison.InvariantCultureIgnoreCase))
                    {
                        customerUserId = customer.CustomerUserId;
                        roleId = customer.RoleId;

                        count++;
                   
                    }
                }
                if (roleId == 2)
                {
                    var newspaperList = await (from newspapers in _add_AdContext.Newspapers join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals customerUsers.CustomerUserId where( newspapers.CustomerUserId == customerUserId && newspapers.IsBlocked == false && newspapers.IsApproved == true && newspapers.Cost > 0) select new { customerUsers.UserName, newspapers.Cost, newspapers.Language, newspapers.Rating, newspapers.NewsPaperId }).ToListAsync();

                    newspapersList = EntityToDto(newspapersList, newspaperList);
                    if (newspaperList.Count == 0)
                    {
                        throw new NoNewspaperFound("No newspaper is present");
                    }
                    return newspapersList;

                }
                else if (roleId == 3)
                {
         var searchChannels = await (from channels in _add_AdContext.TvChannels join customerUsers in _add_AdContext.CustomerUsers on channels.CustomerUserId equals customerUsers.CustomerUserId where (channels.CustomerUserId == customerUserId && channels.IsBlocked == false && channels.IsApproved == true && channels.Cost>0) select new { customerUsers.UserName, channels.Cost, channels.Language, channels.Rating, channels.TvChannelId, channels.Genre }).ToListAsync();

                    tvChannelList = EntityToDto(tvChannelList, searchChannels);
                    if (tvChannelList.Count == 0)
                    {
                        throw new NoNewspaperFound("No tv channel present");
                    }
                    return tvChannelList;
                }
                else {
                    throw new NoNewspaperFound("No Newspaper is Present");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Searches for the newspapers with the perticular rating
        /// </summary>
        /// <param name="rating"></param>
        /// <returns>returns the list of newspapers with that perticular</returns>
        public async Task<object> SearchRating(int rating)
        {
            try
            {

                List<SearchNewspaperDTO> newspapersList = new List<SearchNewspaperDTO>();

                var newspaperList = await (from newspapers in _add_AdContext.Newspapers join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals customerUsers.CustomerUserId where newspapers.Rating == rating && newspapers.IsBlocked == false && newspapers.IsApproved == true select new { customerUsers.UserName, newspapers.Cost, newspapers.Language, newspapers.Rating, newspapers.NewsPaperId }).ToListAsync();

                if (newspaperList == null)
                {
                    throw new NoNewspaperFound("No Newspaper is Present");
                }
                newspapersList = EntityToDto(newspapersList, newspaperList);
                return newspapersList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// this method returns all the newspapers
        /// </summary>
        /// <returns>list of newspapers</returns>
        public async Task<List<Newspaper>> AllNews()
        {
            List<Newspaper> newspapers = await Task.Run(() => _add_AdContext.Newspapers.ToList());
            return newspapers;
        }

        /// <summary>
        /// Get All Active Newspapers
        /// </summary>
        /// <returns>List of Active All Newspapers</returns>
        public async Task<object> GetActiveAllNewspapers()
        {
            try
            {

                List<SearchNewspaperDTO> allNewspapers = new List<SearchNewspaperDTO>();

                var activeNewspapers = await (from newspapers in _add_AdContext.Newspapers join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals customerUsers.CustomerUserId where (newspapers.IsApproved==true && newspapers.IsBlocked==false) select new { customerUsers.UserName, newspapers.Cost, newspapers.Language, newspapers.Rating, newspapers.NewsPaperId }).ToListAsync();

                allNewspapers = EntityToDto(allNewspapers, activeNewspapers);

                if (allNewspapers.Count == 0)
                {
                    throw new NoNewspaperFound("");
                }

                return allNewspapers;
            }
            catch (NoNewspaperFound)
            {
                throw new NoNewspaperFound("No Newspaper Found");
            }
        }

        public async Task<bool> UpdateNewspaper(int newspaperId)
        {


            try
            {
                var newsPaper = await (from newspaper in _add_AdContext.Newspapers where newspaper.NewsPaperId == newspaperId select newspaper).SingleOrDefaultAsync();

                newsPaper.IsBlocked = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    throw new SqlException("No Row Added");
                }
                else
                {
                    return true;
                }


            }
            catch (SqlException )
            {
                throw new SqlException("Some Error Occurred");
            }
        }

        public async Task<List<SearchNewspaperDTO>> GetBlockedNewspapers()
        {
            try
            {

                List<SearchNewspaperDTO> allNewspapers = new List<SearchNewspaperDTO>();

                var activeNewspapers = await (from newspapers in _add_AdContext.Newspapers join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals customerUsers.CustomerUserId where newspapers.IsBlocked == true select new { customerUsers.UserName, newspapers.Cost, newspapers.Language, newspapers.Rating, newspapers.NewsPaperId }).ToListAsync();

                allNewspapers = EntityToDto(allNewspapers, activeNewspapers);
                return allNewspapers;
            }
            catch (Exception )
            {
                throw new Exception("Some Error Occuured");
            }
        }

        public async Task<List<SearchNewspaperDTO>> GetNotApprovedNewspapers()
        {
            try
            {

                List<SearchNewspaperDTO> allNewspapers = new List<SearchNewspaperDTO>();

                var activeNewspapers = await (from newspapers in _add_AdContext.Newspapers join customerUsers in _add_AdContext.CustomerUsers on newspapers.CustomerUserId equals customerUsers.CustomerUserId where (newspapers.IsApproved == false && newspapers.IsBlocked == false) select new { customerUsers.UserName, newspapers.Cost, newspapers.Language, newspapers.Rating, newspapers.NewsPaperId }).ToListAsync();

                allNewspapers = EntityToDto(allNewspapers, activeNewspapers);
                return allNewspapers;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<bool> UnblockNewspaper(int newspaperId)
        {


            try
            {
                var newsPaper = await (from newspaper in _add_AdContext.Newspapers where newspaper.NewsPaperId == newspaperId select newspaper).SingleOrDefaultAsync();

                newsPaper.IsBlocked = false;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    throw new SqlException("Some Error Occurred");
                }
                else
                {
                    return true;
                }


            }
            catch (SqlException )
            {
                throw new SqlException("No Row Added");
            }
        }

        public async Task<bool> ApproveNewspaper(int newspaperId)
        {
            try
            {
                var newsPaper = await (from newspaper in _add_AdContext.Newspapers where newspaper.NewsPaperId == newspaperId select newspaper).SingleOrDefaultAsync();

                newsPaper.IsApproved = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    throw new SqlException("");
                }
                else
                {
                    return true;
                }


            }
            catch (SqlException )
            {
                throw new SqlException("Some error Occurred");
            }
        }

        public async Task<bool> RejectNewspaper(int newspaperId)
        {

            try
            {
                var newsPaper = await (from newspaper in _add_AdContext.Newspapers where newspaper.NewsPaperId == newspaperId select newspaper).SingleOrDefaultAsync();
                newsPaper.IsBlocked = true;

                int rowAffected = await _add_AdContext.SaveChangesAsync();

                if (rowAffected == 0)
                {
                    throw new SqlException("");
                }
                else
                {
                    return true;
                }


            }
            catch (SqlException)
            {
                throw new SqlException("Some error Occurred");
            }
        }

        public async Task<int?> ApproveNewspaper(TransactionDTO newspaperTransactionDTO)
        {
            try
            {
                var newspaperDetail = await _add_AdContext.Transactions.FirstAsync(a => a.TransactionId == newspaperTransactionDTO.TransactionId);
                newspaperDetail.IsApproved = newspaperTransactionDTO.IsApproved;
                await _add_AdContext.SaveChangesAsync();
                return newspaperDetail.TransactionId;
            }
            catch (Exception ex)
            {
                throw new SqlException("Some error occured", ex);
            }
        }
        
        public async Task<int?> BlockNewspaper(TransactionDTO newspaperTransactionDTO)
        {
            try
            {
                var newspaperDetail = await _add_AdContext.Transactions.FirstAsync(a => a.TransactionId == newspaperTransactionDTO.TransactionId);
                newspaperDetail.IsApproved = 0;
                await _add_AdContext.SaveChangesAsync();
                return newspaperDetail.TransactionId;
            }
            catch (Exception ex)
            {
                throw new SqlException("Some error occured", ex);
            }
        }
        public async Task<object> GetPendingNewspapers(string email)
        {
            try
            {
                CustomerUser customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(c => c.EmailId == email);
                Newspaper newspaper= await _add_AdContext.Newspapers.FirstOrDefaultAsync(t => t.CustomerUserId == customerUser.CustomerUserId);
                List<Transaction> newspapersTransactionsList = await _add_AdContext.Transactions.Where(t => t.NewsPaperId ==newspaper.NewsPaperId && t.IsApproved == 0).ToListAsync();
                newspapersTransactionsList.AddRange(await _add_AdContext.Transactions.Where(t => t.NewsPaperId == newspaper.NewsPaperId && t.IsApproved == 1).ToListAsync());
                newspapersTransactionsList.AddRange(await _add_AdContext.Transactions.Where(t => t.NewsPaperId == newspaper.NewsPaperId && t.IsApproved == -1).ToListAsync());

                List<TransactionDTO> transactionDTOs = new List<TransactionDTO>();
                foreach (var transaction in newspapersTransactionsList)
                {
                    TransactionDTO transactionDTO = new TransactionDTO
                    {
                        TransactionId = transaction.TransactionId,
                        customerUserId = transaction.CustomerUserId,
                        Cost = transaction.Cost,
                        TransactionDate = transaction.TransactionDate,
                        ServiceDate = transaction.ServiceDate,
                        AdSizeInPaper = transaction.AdSizeInPaper ?? 0,
                        PageNumber = transaction.PageNumber ?? 0,
                        NumberOfDays = transaction.NumberOfDays ?? 0,
                        IsApproved = transaction.IsApproved,
                    };
                    if (transaction.CustomerUserId != null)
                    {
                        var user = await _add_AdContext.CustomerUsers.FindAsync(transaction.CustomerUserId);
                        transactionDTO.UserName = user.UserName;
                        transactionDTOs.Add(transactionDTO);
                    }
                    
                }

                return transactionDTOs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }



        public async Task<string> GetEmailNewspaper(int newspaperId)
        {
            try
            {
                Newspaper newspaper = await _add_AdContext.Newspapers.FindAsync(newspaperId);
                CustomerUser customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(t => t.CustomerUserId == newspaper.CustomerUserId);
                return customerUser.EmailId;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<int> UpdateChannelPrice(NewspaperPriceUpdateDTO newspaperPriceUpdateDTO)
        {
            int rowsAffected;
            CustomerUser user = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(u => u.EmailId == newspaperPriceUpdateDTO.Email);
            Newspaper newspaper = await _add_AdContext.Newspapers.FirstOrDefaultAsync(t => t.CustomerUserId == user.CustomerUserId);
            if (newspaper == null)
                return -1;
            try
            {
                newspaper.Cost = Math.Round((double)newspaperPriceUpdateDTO.Cost, 2);
                _add_AdContext.Newspapers.Update(newspaper);
                rowsAffected = await _add_AdContext.SaveChangesAsync();
                if (rowsAffected == 0)
                    throw new TvChannelInsertionException("Cost Updation failed");
                return rowsAffected;
            }
            catch
            {
                throw new Exception("Something went wrong");
            }

        }
        public async Task<Newspaper> GetByEmail(string email)
        {
            try
            {
                CustomerUser customerUser = new CustomerUser();
                Newspaper newspaper = new Newspaper();
                customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(e => e.EmailId == email);
                newspaper = await _add_AdContext.Newspapers.FirstOrDefaultAsync(t => t.CustomerUserId == customerUser.CustomerUserId);
                return newspaper;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public async Task<string> GetEmailOfNewspaper(int customerUserId)
        {
            try
            {
                CustomerUser customerUser = new CustomerUser();
                Transaction transaction = await _add_AdContext.Transactions.FirstOrDefaultAsync(e => e.CustomerUserId== customerUserId);
                customerUser = await _add_AdContext.CustomerUsers.FirstOrDefaultAsync(t => t.CustomerUserId== transaction.CustomerUserId);
                return customerUser.EmailId;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public List<SearchChannelDTO> EntityToDto(List<SearchChannelDTO> ChannelDto, dynamic channelsList)
        {
            foreach (var channel in channelsList)
            {
                SearchChannelDTO channelDTO = new SearchChannelDTO();
                channelDTO.UserName = channel.UserName;
                channelDTO.TvChannelId = channel.TvChannelId;
                channelDTO.Rating = channel.Rating;
                channelDTO.Language = channel.Language;
                channelDTO.Genre = channel.Genre;
                channelDTO.Cost = channel.Cost;
                ChannelDto.Add(channelDTO);
            }
            return ChannelDto;
        }
        public List<SearchNewspaperDTO> EntityToDto(List<SearchNewspaperDTO> newspapersList, dynamic newspaperList)
        {
            foreach (var newspaper in newspaperList)
            {
                SearchNewspaperDTO newspaperDTO = new SearchNewspaperDTO();
                newspaperDTO.UserName = newspaper.UserName;
                newspaperDTO.NewsPaperId = newspaper.NewsPaperId;
                newspaperDTO.Rating = newspaper.Rating;
                newspaperDTO.Language = newspaper.Language;
                newspaperDTO.Cost = newspaper.Cost;
                newspapersList.Add(newspaperDTO);
            }
            return newspapersList;
        }


    }
}
