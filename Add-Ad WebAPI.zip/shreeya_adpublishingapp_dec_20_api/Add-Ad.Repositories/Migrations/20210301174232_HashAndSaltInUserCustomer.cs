﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Add_Ad.Repositories.Migrations
{
    public partial class HashAndSaltInUserCustomer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Password",
                table: "CustomerUsers");

            migrationBuilder.AddColumn<byte[]>(
                name: "PasswordHash",
                table: "CustomerUsers",
                type: "varbinary(max)",
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "PasswordSalt",
                table: "CustomerUsers",
                type: "varbinary(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PasswordHash",
                table: "CustomerUsers");

            migrationBuilder.DropColumn(
                name: "PasswordSalt",
                table: "CustomerUsers");

            migrationBuilder.AddColumn<string>(
                name: "Password",
                table: "CustomerUsers",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
