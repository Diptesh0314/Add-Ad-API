﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.CustomExceptions
{
    public class SqlException:Exception
    {
        public SqlException()
        {

        }
        public SqlException(string message) : base(message)
        {

        }
        public SqlException(string message,Exception ex) : base(message,ex)
        {

        }
    }
}
