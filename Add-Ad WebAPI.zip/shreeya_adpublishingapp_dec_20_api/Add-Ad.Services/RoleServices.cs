﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DbOperations;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Services
{
    public class RoleServices : IRoleServices
    {
        private readonly IRoleRepository _roleRepository;
        public RoleServices(IRoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }
        public async Task<int> AddRoles(Role role)
        {
           int rowsAffected=await _roleRepository.AddRoles(role);

            return rowsAffected;
        }
    }
}
