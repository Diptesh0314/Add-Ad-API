﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class NewspaperssDTO
    {
        public int? NewsPaperId { get; set; }
        public int? CustomerUserId { get; set; }
        public string Language { get; set; }
        public bool IsApproved { get; set; }
        public bool IsBlocked { get; set; }
        public double Cost { get; set; }
        public double Rating { get; set; }
    }
}
