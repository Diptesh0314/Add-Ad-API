﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Add_Ad.Entity
{
    public class Transaction
    {
        [Key]
        public int TransactionId { get; set; }
        public int? TvChannelId { get; set; }
        public int? NewsPaperId { get; set; }
        public int? CustomerUserId { get; set; }
        public DateTime ServiceDate { get; set; }
        public DateTime TransactionDate { get; set; }
        public double Cost { get; set; }
        public int IsApproved { get; set; }//??
        public int? AdSizeInPaper { get; set; }
        public int? AdDurationInPaper { get; set; }
        public int? NumberOfDays { get; set; }
        public int? PageNumber { get; set; }

        [ForeignKey("CustomerUserId")]
        public CustomerUser CustomerUser { get; set; }

        [ForeignKey("NewsPaperId")]
        public Newspaper Newspaper { get; set; }

        [ForeignKey("TvChannelId")]
        public TvChannel TvChannel { get; set; }

        public static implicit operator List<object>(Transaction v)
        {
            throw new NotImplementedException();
        }
    }
}
