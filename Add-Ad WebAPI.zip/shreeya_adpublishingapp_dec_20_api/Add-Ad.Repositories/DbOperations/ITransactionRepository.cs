﻿using Add_Ad.Entity;
using Add_Ad.Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.Repositories
{
    public interface ITransactionRepository
    {
        public Task<int?> GetUserId(string name);
        public Task<List<TransactionDTO>> GetTransaction(string name);
        public Task<TransactionDTO> AddTransaction(Transaction transaction);
        public TransactionDTO TransactionToTransactionDTO(Transaction transaction, TransactionDTO transactionDTO);
    }
}
