﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Add_Ad.Repositories.DTOs
{
    public class TransactionDTO
    {
        //transactionId!:Number;
        //tvChannelId!:Number;
        //newspaperId!:Number;
        //customerUserId!:Number;
        //cost!:Number;
        //size!:Number;
        //page!:Number;
        //duration!:Number;
        //numberOfDays!:Number;
        //isApproved!:Number;
        public int? customerUserId { get; set; }
        public int? TransactionId { get; set; }
        public int? TvChannelId { get; set; }
        public int? NewsPaperId { get; set; }
        public string UserName { get; set; }
        public string CompanyName { get; set; }
        public int AdDurationInPaper { get; set; }
        public int IsApproved { get; set; }
        public double Cost { get; set; }
        public int AdSizeInPaper { get; set; }
        public int PageNumber { get; set; }
        public int NumberOfDays { get; set; }
        public DateTime TransactionDate { get; set; }
        public DateTime ServiceDate { get; set; }

    }
}
