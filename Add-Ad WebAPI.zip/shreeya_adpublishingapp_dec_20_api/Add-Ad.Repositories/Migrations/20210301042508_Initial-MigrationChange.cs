﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Add_Ad.Repositories.Migrations
{
    public partial class InitialMigrationChange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CustomerUser_Role_RoleId",
                table: "CustomerUser");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Role",
                table: "Role");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CustomerUser",
                table: "CustomerUser");

            migrationBuilder.RenameTable(
                name: "Role",
                newName: "Roles");

            migrationBuilder.RenameTable(
                name: "CustomerUser",
                newName: "CustomerUsers");

            migrationBuilder.RenameIndex(
                name: "IX_CustomerUser_RoleId",
                table: "CustomerUsers",
                newName: "IX_CustomerUsers_RoleId");

            migrationBuilder.RenameIndex(
                name: "IX_CustomerUser_EmailId",
                table: "CustomerUsers",
                newName: "IX_CustomerUsers_EmailId");

            migrationBuilder.AlterColumn<int>(
                name: "RoleId",
                table: "CustomerUsers",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Roles",
                table: "Roles",
                column: "RoleId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CustomerUsers",
                table: "CustomerUsers",
                column: "CustomerUserId");

            migrationBuilder.CreateTable(
                name: "Newspapers",
                columns: table => new
                {
                    NewsPaperId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerUserId = table.Column<int>(type: "int", nullable: true),
                    Language = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsApproved = table.Column<bool>(type: "bit", nullable: false),
                    IsBlocked = table.Column<bool>(type: "bit", nullable: false),
                    Cost = table.Column<double>(type: "float", nullable: false),
                    Rating = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Newspapers", x => x.NewsPaperId);
                    table.ForeignKey(
                        name: "FK_Newspapers_CustomerUsers_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "CustomerUsers",
                        principalColumn: "CustomerUserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TvChannels",
                columns: table => new
                {
                    TvChannelId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerUserId = table.Column<int>(type: "int", nullable: true),
                    Genre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Language = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsApproved = table.Column<bool>(type: "bit", nullable: false),
                    IsBlocked = table.Column<bool>(type: "bit", nullable: false),
                    Cost = table.Column<double>(type: "float", nullable: false),
                    Rating = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TvChannels", x => x.TvChannelId);
                    table.ForeignKey(
                        name: "FK_TvChannels_CustomerUsers_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "CustomerUsers",
                        principalColumn: "CustomerUserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Transactions",
                columns: table => new
                {
                    TransactionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TvChannelId = table.Column<int>(type: "int", nullable: true),
                    NewsPaperId = table.Column<int>(type: "int", nullable: true),
                    CustomerUserId = table.Column<int>(type: "int", nullable: true),
                    TransactionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Cost = table.Column<double>(type: "float", nullable: false),
                    IsApproved = table.Column<int>(type: "int", nullable: false),
                    AdSizeInPaper = table.Column<int>(type: "int", nullable: false),
                    AdDurationInPaper = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Transactions", x => x.TransactionId);
                    table.ForeignKey(
                        name: "FK_Transactions_CustomerUsers_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "CustomerUsers",
                        principalColumn: "CustomerUserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Transactions_Newspapers_NewsPaperId",
                        column: x => x.NewsPaperId,
                        principalTable: "Newspapers",
                        principalColumn: "NewsPaperId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Transactions_TvChannels_TvChannelId",
                        column: x => x.TvChannelId,
                        principalTable: "TvChannels",
                        principalColumn: "TvChannelId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Newspapers_CustomerUserId",
                table: "Newspapers",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_CustomerUserId",
                table: "Transactions",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_NewsPaperId",
                table: "Transactions",
                column: "NewsPaperId");

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_TvChannelId",
                table: "Transactions",
                column: "TvChannelId");

            migrationBuilder.CreateIndex(
                name: "IX_TvChannels_CustomerUserId",
                table: "TvChannels",
                column: "CustomerUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerUsers_Roles_RoleId",
                table: "CustomerUsers",
                column: "RoleId",
                principalTable: "Roles",
                principalColumn: "RoleId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CustomerUsers_Roles_RoleId",
                table: "CustomerUsers");

            migrationBuilder.DropTable(
                name: "Transactions");

            migrationBuilder.DropTable(
                name: "Newspapers");

            migrationBuilder.DropTable(
                name: "TvChannels");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Roles",
                table: "Roles");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CustomerUsers",
                table: "CustomerUsers");

            migrationBuilder.RenameTable(
                name: "Roles",
                newName: "Role");

            migrationBuilder.RenameTable(
                name: "CustomerUsers",
                newName: "CustomerUser");

            migrationBuilder.RenameIndex(
                name: "IX_CustomerUsers_RoleId",
                table: "CustomerUser",
                newName: "IX_CustomerUser_RoleId");

            migrationBuilder.RenameIndex(
                name: "IX_CustomerUsers_EmailId",
                table: "CustomerUser",
                newName: "IX_CustomerUser_EmailId");

            migrationBuilder.AlterColumn<int>(
                name: "RoleId",
                table: "CustomerUser",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Role",
                table: "Role",
                column: "RoleId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CustomerUser",
                table: "CustomerUser",
                column: "CustomerUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerUser_Role_RoleId",
                table: "CustomerUser",
                column: "RoleId",
                principalTable: "Role",
                principalColumn: "RoleId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
