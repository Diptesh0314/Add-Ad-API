﻿using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerUserController : ControllerBase
    {
        private readonly ICustomerUserServices _customerUserServices;

        public CustomerUserController(ICustomerUserServices customerUserServices)
        {
            _customerUserServices = customerUserServices;
        }
        /// <summary>
        /// This RegisterUser function calls service function to pass CustomerDTO object
        /// </summary>
        /// <param name="userVal">Type=CustomerUserDTO</param>
        /// <returns>return CustomerUserId if registraion gets successful else return
        /// bad request if the Registration fails</returns>
        [HttpPost]
        public async Task<IActionResult> RegisterUser(CustomerUserDTO userVal)
        {
            try
            {
                int? newCustomerId = await _customerUserServices.RegisterUser(userVal);
                if (newCustomerId == 0)
                    return BadRequest("UserName is taken");
                return Ok(newCustomerId);

            }
            catch(UserAlreadyExistsException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }


        }

        [HttpPost("login")]
        public async Task<IActionResult> AuthenticateUser(CustomerUserDTO userVal)
        {
            CustomerUserTokenDTO user = await _customerUserServices.AuthenticateUser(userVal);
            if (user == null)
                return BadRequest("Invalid Username or password");
            return Ok(user);
        }
        [HttpPost("update")]
        public async Task<IActionResult> UpdateUser(CustomerUserDTO userVal)
        {
            int? newCustomerId = await _customerUserServices.UpdateUser(userVal);
            return Ok(newCustomerId);

        }



        [Authorize]
        [HttpGet("testing")]
        public IActionResult Testing()
        {
            string msg = "token working";
            return Ok(msg);
        }
    }
}
