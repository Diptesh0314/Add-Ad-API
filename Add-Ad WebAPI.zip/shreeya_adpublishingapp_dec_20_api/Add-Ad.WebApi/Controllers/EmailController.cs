﻿using Add_Ad.CustomExceptions;
using Add_Ad.Repositories.DTOs;
using Add_Ad.Services;
using EmailService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Add_Ad.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly ICustomerUserServices _customerUserServices;

        public EmailController(ICustomerUserServices customerUserServices, IEmailSender emailSender)
        {
            _customerUserServices = customerUserServices;
            _emailSender = emailSender;
        }

        private readonly IEmailSender _emailSender;

        [HttpPost("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordDto forgotPasswordDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();
            try
            {
                int? newCustomerId = await _customerUserServices.CheckEmailIfExist(forgotPasswordDto);
                if (newCustomerId == 1)
                    return BadRequest("Your Entered Email is not registered");
                ////
                string key = "01234567890123456789012345678901"; // 32 bytes key, corresponds to AES-256
                string email = forgotPasswordDto.Email;
                string encryptedEmail = EncryptString(key, email);
                string token = newCustomerId.ToString();
                string encryptedToken = EncryptString(key, token);
                Console.WriteLine(encryptedToken);

                ///
                var param = new Dictionary<string, string>
                {
                    {"token", encryptedToken },
                    {"value", encryptedEmail }
                };
                var callback = QueryHelpers.AddQueryString(forgotPasswordDto.ClientURI, param);
                //var callback = QueryHelpers.AddQueryString(forgotPasswordDto.ClientURI, "email", forgotPasswordDto.Email);
                var message = new Message(new string[] { forgotPasswordDto.Email }, "Reset password token", callback);
                await _emailSender.SendEmailAsync(message);

                return Ok();
            }
            catch (SqlException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public static string EncryptString(string key, string plainText)
        {
            byte[] iv = new byte[16];
            byte[] array;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                aes.Padding = PaddingMode.PKCS7;
                aes.Mode = CipherMode.CBC;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(plainText);
                        }

                        array = memoryStream.ToArray();
                    }
                }
            }

            return Convert.ToBase64String(array);
        }

        //----------------
        //Send mails upon registraion
        [HttpPost("SendMail")]
        public async Task<IActionResult> SendMail(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Add-Ad Registraion", "Your registraion request has been submitted for approval, as soon as it is approved you can login to Add-Ad...");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendBlockEmailTvChannel")]
        public async Task<IActionResult> SendBlockEmailTvChannel(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Blocking Your Channel", "Dear Customer , \nYour Channel is Temporarly Blocked from Add-Ad due to Policy Violation.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendBlockEmailNewspaper")]
        public async Task<IActionResult> SendBlockEmailNewspaper(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Blocking Your Newspaper", "Dear Customer , \nYour Newspaper is Temporarly Blocked from Add-Ad due to Policy Violation.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendUnblockEmailNewspaper")]
        public async Task<IActionResult> SendUnblockEmailNewspaper(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "UnBlocking Your Newspaper", "Dear Customer , \nYour Newspaper is UnBlocked from Add-Ad \nEnjoy Services from Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendUnblockEmailTvChannel")]
        public async Task<IActionResult> SendUnblockEmailTvChannel(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "UnBlocking Your TvChannel", "Dear Customer , \nYour TvChannel is UnBlocked from Add-Ad \nEnjoy Services from Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendApproveEmailTvChannel")]
        public async Task<IActionResult> SendApproveEmailTvChannel(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Approved Your TvChannel Request", "Dear Customer , \nYour TvChannel is Aprroved for services on Add-Ad \nEnjoy Services from Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendApproveEmailNewspaper")]
        public async Task<IActionResult> SendApproveEmailNewspaper(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Approved Your Newspaper Request", "Dear Customer , \nYour Newspaper is Aprroved for services on Add-Ad \nEnjoy Services from Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendRejectEmailTvChannel")]
        public async Task<IActionResult> SendRejectEmailTvChannel(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Reject Your TvChannel Request", "Dear Customer , \nYour TvChannel is Rejected for services on Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendRejectEmailNewspaper")]
        public async Task<IActionResult> SendRejectEmailNewspaper(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Reject Your Newspaper Request", "Dear Customer , \nYour Newspaper is Rejected for services on Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("SendBlocked")]
        public async Task<IActionResult> SendAdBlockedMail(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Ad Blocked", "Dear Customer , \nYour Advertisement is blocked for services on Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("SendApproval")]
        public async Task<IActionResult> SendAdApprovalMail(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Ad Approved", "Dear Customer Congratulations!! , \nYour Advertisement is approved for services on Add-Ad.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendTransactionApproval")]
        public async Task<IActionResult> SendTransactionApproval(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Transaction approved", "Dear Customer Congratulations!!, \nYour transaction is approved.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendTransactionRejection")]
        public async Task<IActionResult> SendTransactionRejection(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Transaction rejected", "Dear Customer , \nYour Advertisement is blocked.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("BookAd")]
        public async Task<IActionResult> BookAd(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Ad Booked", "Dear Customer , \nYour Advertisement is booked successfully, wait for admin approval.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpPost("SendTransactionNewspaperApproval")]
        public async Task<IActionResult> SendTransactionNewspaperApproval(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Transaction approved", "Dear Customer Congratulations!!, \nYour Newspaper advertisement is approved.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SendTransactionNewspaperRejection")]
        public async Task<IActionResult> SendTransactionNewspaperRejection(EmailDTO email)
        {
            try
            {
                var message = new Message(new string[] { email.Email }, "Transaction rejected", "Dear Customer , \nYour Newspaper advertisement is blocked.\nRegards,\nAdmin\nAdd-Ad");
                await _emailSender.SendEmailAsync(message);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}