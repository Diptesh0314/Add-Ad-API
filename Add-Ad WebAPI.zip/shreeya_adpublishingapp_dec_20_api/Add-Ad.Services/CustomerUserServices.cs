﻿using Add_Ad.Repositories;
using System;
using System.Threading.Tasks;
using Add_Ad.Repositories.DTOs;

namespace Add_Ad.Services
{
    /// <summary>
    /// Customer User Services Responsible for all 
    /// operations on CustomerUser
    /// </summary>
    public class CustomerUserServices:ICustomerUserServices
    {
        private readonly ICustomerUserRepository _customerUserRepository;

        public CustomerUserServices(ICustomerUserRepository customerUserRepository)
        {
            _customerUserRepository = customerUserRepository;
        }
        public async Task<int?> RegisterUser(CustomerUserDTO userDTO)
        {
            int? newCustomerUserId =await _customerUserRepository.RegisterUser(userDTO);
            return newCustomerUserId;

        }
        public async Task<CustomerUserTokenDTO> AuthenticateUser(CustomerUserDTO userDTO)
        {
            CustomerUserTokenDTO userToken = await _customerUserRepository.AuthenticateUser(userDTO);
            return userToken;
        }

        public async Task<int?> CheckEmailIfExist(ForgotPasswordDto forgotPasswordDto)
        {
            int? newCustomerUserId = await _customerUserRepository.CheckEmailIfExist(forgotPasswordDto);
            return newCustomerUserId;

        }

        public async Task<int?> UpdateUser(CustomerUserDTO userDTO)
        {
            int? newCustomerUserId = await _customerUserRepository.UpdateUser(userDTO);
            return newCustomerUserId;
        }
        public async Task<int?> UpdatePassword(CustomerUserDTO userVal)
        {
            int? newCustomerUserId = await _customerUserRepository.UpdatePassword(userVal);
            return newCustomerUserId;
        }
    }
}
